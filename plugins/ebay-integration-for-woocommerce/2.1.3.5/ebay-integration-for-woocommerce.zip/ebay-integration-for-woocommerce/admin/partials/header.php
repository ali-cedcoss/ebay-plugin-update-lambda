<?php
// If this file is called directly, abort.
if ( ! defined( 'ABSPATH' ) ) {
	die;
}
$user_id = isset( $_GET['user_id'] ) ? sanitize_text_field( $_GET['user_id'] ) : '';

$shopDetails = ced_ebay_get_shop_data( $user_id );
if ( ! empty( $shopDetails ) ) {
		$siteID              = $shopDetails['site_id'];
				$getLocation = $shopDetails['location'];
}
if ( isset( $_GET['section'] ) ) {

	$section = isset( $_GET['section'] ) ? sanitize_text_field( $_GET['section'] ) : '';
}

?>
<div class="ced_ebay_loader">
	<img src="<?php echo esc_attr( CED_EBAY_URL ) . 'admin/images/loading.gif'; ?>" width="50px" height="50px" class="ced_ebay_loading_img" >
</div>
<div id="ced_ebay_blockMessage"></div>

<div class=" wrap ced-ebay-v2-wrap">
<div class="ced-ebay-v2-admin-field ced-ebay-v2-admin-menu">
					<ul class="ced-ebay-v2-admin-tabs">
					<li>
			<a href="<?php echo esc_attr( admin_url( 'admin.php?page=ced_ebay&section=accounts-view&user_id=' . $user_id . '&site_id=' . $siteID . '&ver=' . $this->version ) ); ?>" class="
								<?php
								if ( 'accounts-view' == $section ) {
									echo 'active';}
								?>
			"><?php esc_attr_e( 'Account Settings', 'ebay-integration-for-woocommerce' ); ?></a>
		</li>
		<li>
			<a href="<?php echo esc_attr( admin_url( 'admin.php?page=ced_ebay&section=settings-view&user_id=' . $user_id . '&site_id=' . $siteID . '&ver=' . $this->version ) ); ?>" class="
								<?php
								if ( 'settings-view' == $section ) {
									echo 'active';}
								?>
			"><?php esc_attr_e( 'General Settings', 'ebay-integration-for-woocommerce' ); ?></a>
		</li>
		<li>
			<a class="
			<?php
			if ( 'category-mapping-view' == $section ) {
				echo 'active';}
			?>
			" href="<?php echo esc_attr( admin_url( 'admin.php?page=ced_ebay&section=category-mapping-view&user_id=' . $user_id . '&site_id=' . $siteID . '&ver=' . $this->version ) ); ?>"><?php esc_attr_e( 'Category Mapping', 'ebay-integration-for-woocommerce' ); ?></a>
		</li>
		<li>
			<a class="
			<?php
			if ( 'profiles-view' == $section ) {
				echo 'active';}
			?>
			" href="<?php echo esc_attr( admin_url( 'admin.php?page=ced_ebay&section=profiles-view&user_id=' . $user_id . '&site_id=' . $siteID . '&ver=' . $this->version ) ); ?>"><?php esc_attr_e( 'Profile', 'ebay-integration-for-woocommerce' ); ?></a>
		</li>
		<li>
			<a class="
			<?php
			if ( 'products-view' == $section ) {
				echo 'active';}
			?>
			" href="<?php echo esc_attr( admin_url( 'admin.php?page=ced_ebay&section=products-view&user_id=' . $user_id . '&site_id=' . $siteID . '&ver=' . $this->version ) ); ?>"><?php esc_attr_e( 'Products', 'ebay-integration-for-woocommerce' ); ?></a>
		</li>
		<li>
		<a class="
		<?php
		if ( 'status-feed' == $section ) {
			echo 'active';
		}
		?>
		" href="<?php echo esc_attr( admin_url( 'admin.php?page=ced_ebay&section=status-feed&user_id=' . $user_id . '&site_id=' . $siteID . '&ver=' . $this->version . '&type=all_entries' ) ); ?>"><span style="color: #ef8137;font-weight:bold !important;">NEW! </span><?php esc_attr_e( 'Bulk Upload Feed', 'ebay-integration-for-woocommerce' ); ?></a>
		</li>
		<li>
		<a class="
		<?php
		if ( 'import-products' == $section ) {
			echo 'active';
		}
		?>
		" href="<?php echo esc_attr( admin_url( 'admin.php?page=ced_ebay&section=import-products&user_id=' . $user_id . '&site_id=' . $siteID . '&ver=' . $this->version ) ); ?>"><?php esc_attr_e( 'Import Products', 'ebay-integration-for-woocommerce' ); ?></a>
		</li>
		<li>
		<a class="
		<?php
		if ( 'marketing-view' == $section ) {
			echo 'active';
		}
		?>
		" href="<?php echo esc_attr( admin_url( 'admin.php?page=ced_ebay&section=marketing-view&user_id=' . $user_id . '&site_id=' . $siteID . '&ver=' . $this->version ) ); ?>"><?php esc_attr_e( 'Marketing', 'ebay-integration-for-woocommerce' ); ?></a>
		</li>
		<li>
			<a class="
			<?php
			if ( 'orders-view' == $section ) {
				echo 'active';}
			?>
			" href="<?php echo esc_attr( admin_url( 'admin.php?page=ced_ebay&section=orders-view&user_id=' . $user_id . '&site_id=' . $siteID . '&ver=' . $this->version ) ); ?>"><?php esc_attr_e( 'Orders', 'ebay-integration-for-woocommerce' ); ?></a>
		</li>
					</ul>
</div>

				</div>
				<div class="success-admin-notices is-dismissible"></div>
