<?php
// If this file is called directly, abort.
if ( ! defined( 'ABSPATH' ) ) {
	die;
}
$shop_name = isset( $_GET['user_id'] ) ? sanitize_text_field( $_GET['user_id'] ) : '';
$shop_data = ced_ebay_get_shop_data( $shop_name );
if ( ! empty( $shop_data ) ) {
	$siteID      = $shop_data['site_id'];
	$token       = $shop_data['access_token'];
	$getLocation = $shop_data['location'];
}

$countries_list = array(
	'Domestic_Channel Islands'    => 'Channel Islands',
	'Domestic_Isle of Wight'      => 'Isle of Wight',
	'Domestic_Isle of Man'        => 'Isle of Man',
	'Domestic_Scilly Isles'       => 'Scilly Isles',
	'Domestic_Scottish Highlands' => 'Scottish Highlands',
	'Domestic_Scottish Islands'   => 'Scottish Islands',
	'Domestic_Northern Ireland'   => 'Northern Ireland',
	'AF'                          => 'Afghanistan',
	'AL'                          => 'Albania',
	'DZ'                          => 'Algeria',
	'AS'                          => 'American Samoa',
	'AD'                          => 'Andorra',
	'AO'                          => 'Angola',
	'AI'                          => 'Anguilla',
	'AQ'                          => 'Antarctica',
	'AG'                          => 'Antigua and Barbuda',
	'AR'                          => 'Argentina',
	'AM'                          => 'Armenia',
	'AW'                          => 'Aruba',
	'AU'                          => 'Australia',
	'AT'                          => 'Austria',
	'AZ'                          => 'Azerbaijan',
	'BS'                          => 'Bahamas (the)',
	'BH'                          => 'Bahrain',
	'BD'                          => 'Bangladesh',
	'BB'                          => 'Barbados',
	'BY'                          => 'Belarus',
	'BE'                          => 'Belgium',
	'BZ'                          => 'Belize',
	'BJ'                          => 'Benin',
	'BM'                          => 'Bermuda',
	'BT'                          => 'Bhutan',
	'BO'                          => 'Bolivia (Plurinational State of)',
	'BQ'                          => 'Bonaire, Sint Eustatius and Saba',
	'BA'                          => 'Bosnia and Herzegovina',
	'BW'                          => 'Botswana',
	'BV'                          => 'Bouvet Island',
	'BR'                          => 'Brazil',
	'IO'                          => 'British Indian Ocean Territory (the)',
	'BN'                          => 'Brunei Darussalam',
	'BG'                          => 'Bulgaria',
	'BF'                          => 'Burkina Faso',
	'BI'                          => 'Burundi',
	'CV'                          => 'Cabo Verde',
	'KH'                          => 'Cambodia',
	'CM'                          => 'Cameroon',
	'CA'                          => 'Canada',
	'KY'                          => 'Cayman Islands (the)',
	'CF'                          => 'Central African Republic (the)',
	'TD'                          => 'Chad',
	'CL'                          => 'Chile',
	'CN'                          => 'China',
	'CX'                          => 'Christmas Island',
	'CC'                          => 'Cocos (Keeling) Islands (the)',
	'CO'                          => 'Colombia',
	'KM'                          => 'Comoros (the)',
	'CD'                          => 'Congo (the Democratic Republic of the)',
	'CG'                          => 'Congo (the)',
	'CK'                          => 'Cook Islands (the)',
	'CR'                          => 'Costa Rica',
	'HR'                          => 'Croatia',
	'CU'                          => 'Cuba',
	'CW'                          => 'Curaçao',
	'CY'                          => 'Cyprus',
	'CZ'                          => 'Czechia',
	'CI'                          => "Côte d'Ivoire",
	'DK'                          => 'Denmark',
	'DJ'                          => 'Djibouti',
	'DM'                          => 'Dominica',
	'DO'                          => 'Dominican Republic (the)',
	'EC'                          => 'Ecuador',
	'EG'                          => 'Egypt',
	'SV'                          => 'El Salvador',
	'GQ'                          => 'Equatorial Guinea',
	'ER'                          => 'Eritrea',
	'EE'                          => 'Estonia',
	'SZ'                          => 'Eswatini',
	'ET'                          => 'Ethiopia',
	'FK'                          => 'Falkland Islands (the) [Malvinas]',
	'FO'                          => 'Faroe Islands (the)',
	'FJ'                          => 'Fiji',
	'FI'                          => 'Finland',
	'FR'                          => 'France',
	'GF'                          => 'French Guiana',
	'PF'                          => 'French Polynesia',
	'TF'                          => 'French Southern Territories (the)',
	'GA'                          => 'Gabon',
	'GM'                          => 'Gambia (the)',
	'GE'                          => 'Georgia',
	'DE'                          => 'Germany',
	'GH'                          => 'Ghana',
	'GI'                          => 'Gibraltar',
	'GR'                          => 'Greece',
	'GL'                          => 'Greenland',
	'GD'                          => 'Grenada',
	'GP'                          => 'Guadeloupe',
	'GU'                          => 'Guam',
	'GT'                          => 'Guatemala',
	'GG'                          => 'Guernsey',
	'GN'                          => 'Guinea',
	'GW'                          => 'Guinea-Bissau',
	'GY'                          => 'Guyana',
	'HT'                          => 'Haiti',
	'HM'                          => 'Heard Island and McDonald Islands',
	'VA'                          => 'Holy See (the)',
	'HN'                          => 'Honduras',
	'HK'                          => 'Hong Kong',
	'HU'                          => 'Hungary',
	'IS'                          => 'Iceland',
	'IN'                          => 'India',
	'ID'                          => 'Indonesia',
	'IR'                          => 'Iran (Islamic Republic of)',
	'IQ'                          => 'Iraq',
	'IE'                          => 'Ireland',
	'IM'                          => 'Isle of Man',
	'IL'                          => 'Israel',
	'IT'                          => 'Italy',
	'JM'                          => 'Jamaica',
	'JP'                          => 'Japan',
	'JE'                          => 'Jersey',
	'JO'                          => 'Jordan',
	'KZ'                          => 'Kazakhstan',
	'KE'                          => 'Kenya',
	'KI'                          => 'Kiribati',
	'KP'                          => "Korea (the Democratic People's Republic of)",
	'KR'                          => 'Korea (the Republic of)',
	'KW'                          => 'Kuwait',
	'KG'                          => 'Kyrgyzstan',
	'LA'                          => "Lao People's Democratic Republic (the)",
	'LV'                          => 'Latvia',
	'LB'                          => 'Lebanon',
	'LS'                          => 'Lesotho',
	'LR'                          => 'Liberia',
	'LY'                          => 'Libya',
	'LI'                          => 'Liechtenstein',
	'LT'                          => 'Lithuania',
	'LU'                          => 'Luxembourg',
	'MO'                          => 'Macao',
	'MG'                          => 'Madagascar',
	'MW'                          => 'Malawi',
	'MY'                          => 'Malaysia',
	'MV'                          => 'Maldives',
	'ML'                          => 'Mali',
	'MT'                          => 'Malta',
	'MH'                          => 'Marshall Islands (the)',
	'MQ'                          => 'Martinique',
	'MR'                          => 'Mauritania',
	'MU'                          => 'Mauritius',
	'YT'                          => 'Mayotte',
	'MX'                          => 'Mexico',
	'FM'                          => 'Micronesia (Federated States of)',
	'MD'                          => 'Moldova (the Republic of)',
	'MC'                          => 'Monaco',
	'MN'                          => 'Mongolia',
	'ME'                          => 'Montenegro',
	'MS'                          => 'Montserrat',
	'MA'                          => 'Morocco',
	'MZ'                          => 'Mozambique',
	'MM'                          => 'Myanmar',
	'NA'                          => 'Namibia',
	'NR'                          => 'Nauru',
	'NP'                          => 'Nepal',
	'NL'                          => 'Netherlands (the)',
	'NC'                          => 'New Caledonia',
	'NZ'                          => 'New Zealand',
	'NI'                          => 'Nicaragua',
	'NE'                          => 'Niger (the)',
	'NG'                          => 'Nigeria',
	'NU'                          => 'Niue',
	'NF'                          => 'Norfolk Island',
	'MP'                          => 'Northern Mariana Islands (the)',
	'NO'                          => 'Norway',
	'OM'                          => 'Oman',
	'PK'                          => 'Pakistan',
	'PW'                          => 'Palau',
	'PS'                          => 'Palestine, State of',
	'PA'                          => 'Panama',
	'PG'                          => 'Papua New Guinea',
	'PY'                          => 'Paraguay',
	'PE'                          => 'Peru',
	'PH'                          => 'Philippines (the)',
	'PN'                          => 'Pitcairn',
	'PL'                          => 'Poland',
	'PT'                          => 'Portugal',
	'PR'                          => 'Puerto Rico',
	'QA'                          => 'Qatar',
	'MK'                          => 'Republic of North Macedonia',
	'RO'                          => 'Romania',
	'RU'                          => 'Russian Federation (the)',
	'RW'                          => 'Rwanda',
	'RE'                          => 'Réunion',
	'BL'                          => 'Saint Barthélemy',
	'SH'                          => 'Saint Helena, Ascension and Tristan da Cunha',
	'KN'                          => 'Saint Kitts and Nevis',
	'LC'                          => 'Saint Lucia',
	'MF'                          => 'Saint Martin (French part)',
	'PM'                          => 'Saint Pierre and Miquelon',
	'VC'                          => 'Saint Vincent and the Grenadines',
	'WS'                          => 'Samoa',
	'SM'                          => 'San Marino',
	'ST'                          => 'Sao Tome and Principe',
	'SA'                          => 'Saudi Arabia',
	'SN'                          => 'Senegal',
	'RS'                          => 'Serbia',
	'SC'                          => 'Seychelles',
	'SL'                          => 'Sierra Leone',
	'SG'                          => 'Singapore',
	'SX'                          => 'Sint Maarten (Dutch part)',
	'SK'                          => 'Slovakia',
	'SI'                          => 'Slovenia',
	'SB'                          => 'Solomon Islands',
	'SO'                          => 'Somalia',
	'ZA'                          => 'South Africa',
	'GS'                          => 'South Georgia and the South Sandwich Islands',
	'SS'                          => 'South Sudan',
	'ES'                          => 'Spain',
	'LK'                          => 'Sri Lanka',
	'SD'                          => 'Sudan (the)',
	'SR'                          => 'Suriname',
	'SJ'                          => 'Svalbard and Jan Mayen',
	'SE'                          => 'Sweden',
	'CH'                          => 'Switzerland',
	'SY'                          => 'Syrian Arab Republic',
	'TW'                          => 'Taiwan',
	'TJ'                          => 'Tajikistan',
	'TZ'                          => 'Tanzania, United Republic of',
	'TH'                          => 'Thailand',
	'TL'                          => 'Timor-Leste',
	'TG'                          => 'Togo',
	'TK'                          => 'Tokelau',
	'TO'                          => 'Tonga',
	'TT'                          => 'Trinidad and Tobago',
	'TN'                          => 'Tunisia',
	'TR'                          => 'Turkey',
	'TM'                          => 'Turkmenistan',
	'TC'                          => 'Turks and Caicos Islands (the)',
	'TV'                          => 'Tuvalu',
	'UG'                          => 'Uganda',
	'UA'                          => 'Ukraine',
	'AE'                          => 'United Arab Emirates (the)',
	'GB'                          => 'United Kingdom of Great Britain and Northern Ireland (the)',
	'UM'                          => 'United States Minor Outlying Islands (the)',
	'US'                          => 'United States of America (the)',
	'UY'                          => 'Uruguay',
	'UZ'                          => 'Uzbekistan',
	'VU'                          => 'Vanuatu',
	'VE'                          => 'Venezuela (Bolivarian Republic of)',
	'VN'                          => 'Viet Nam',
	'VG'                          => 'Virgin Islands (British)',
	'VI'                          => 'Virgin Islands (U.S.)',
	'WF'                          => 'Wallis and Futuna',
	'EH'                          => 'Western Sahara',
	'YE'                          => 'Yemen',
	'ZM'                          => 'Zambia',
	'ZW'                          => 'Zimbabwe',
	'AX'                          => 'Åland Islands',
);
if ( isset( $_POST['ced_ebay_shipping_nonce'] ) && wp_verify_nonce( sanitize_text_field( $_POST['ced_ebay_shipping_nonce'] ), 'ced_ebay_shipping_page_nonce' ) ) {
	if ( isset( $_POST['saveShippingPolicies'] ) ) {
		$sanitized_array         = filter_input_array( INPUT_POST, FILTER_UNSAFE_RAW );
		$domesticShippingDetails = isset( $sanitized_array['shippingdetails']['domesticShippingService'] ) ? ( $sanitized_array['shippingdetails']['domesticShippingService'] ) : array();

		$intlShippingDetails                 = isset( $sanitized_array['shippingdetails']['internationalShippingService'] ) ? ( $sanitized_array['shippingdetails']['internationalShippingService'] ) : array();
		$domesticShippingDetails['services'] = array_filter( $domesticShippingDetails['services'] );
		$intlShippingDetails['services']     = array_filter( $intlShippingDetails['services'] );
		$intlShippingDetails['services']     = array_values( $intlShippingDetails['services'] );
		$domesticShippingDetails['services'] = array_values( $domesticShippingDetails['services'] );
		$shippingDetails                     = ( $sanitized_array['shippingdetails'] );

		if ( is_array( $shippingDetails ) && ! empty( $shippingDetails ) ) {
			$details['shippingDetails'] = array(
				'domesticShippingService'      => $domesticShippingDetails,
				'internationalShippingService' => $intlShippingDetails,
				'serviceType'                  => $shippingDetails['serviceType'],
				'postal_code'                  => $shippingDetails['postal_code'],
				'exclusion_list'               => $shippingDetails['exclusion_list'],
			);

			if ( isset( $shippingDetails['shippingweightminor'] ) ) {
				$details['shippingDetails']['shippingweightminor'] = $shippingDetails['shippingweightminor'];
			}

			if ( isset( $shippingDetails['shippingweightmajor'] ) ) {
				$details['shippingDetails']['shippingweightmajor'] = $shippingDetails['shippingweightmajor'];
			}
			if ( isset( $shippingDetails['domesticPackagingCost'] ) ) {
				$details['shippingDetails']['domesticPackagingCost'] = $shippingDetails['domesticPackagingCost'];
			}
			if ( isset( $shippingDetails['internationalPackagingCost'] ) ) {
				$details['shippingDetails']['internationalPackagingCost'] = $shippingDetails['internationalPackagingCost'];
			}

			$template_name = $shippingDetails['template_name'];
			global $wpdb;
			$table_name = $wpdb->prefix . 'ced_ebay_shipping';
			if ( isset( $_GET['template_id'] ) ) {
				$edit_id = sanitize_text_field( $_GET['template_id'] );
				$wpdb->update(
					$table_name,
					array(
						'shipping_name' => $template_name,
						'user_id'       => $shop_name,
						'shipping_data' => json_encode( $details ),
					),
					array( 'id' => $edit_id ),
					array( '%s' )
				);
			} else {
				$wpdb->insert(
					$table_name,
					array(
						'shipping_name' => $template_name,
						'user_id'       => $shop_name,
						'shipping_data' => json_encode( $details ),
					),
					array( '%s' )
				);

				$edit_id = $wpdb->insert_id;
			}
		}
		header( 'Location: ' . get_admin_url() . 'admin.php?page=ced_ebay&section=accounts-view&part=shipping&user_id=' . $shop_name );
		exit();
	}
}
if ( isset( $_GET['template_id'] ) ) {
	$edit_id = isset( $_GET['template_id'] ) ? sanitize_text_field( $_GET['template_id'] ) : '';
	$user_id = isset( $_GET['user_id'] ) ? sanitize_text_field( $_GET['user_id'] ) : '';

	global $wpdb;

	$template_data = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM `{$wpdb->prefix}ced_ebay_shipping` WHERE `id`=%d AND `user_id`=%s", $edit_id, $user_id ), 'ARRAY_A' );

	if ( is_array( $template_data ) ) {
		$template_data = isset( $template_data[0] ) ? $template_data[0] : $template_data;
	}
	$savedShippingDetails = isset( $template_data['shipping_data'] ) ? json_decode( $template_data['shipping_data'], true ) : array();

	$savedShippingDetails = $savedShippingDetails['shippingDetails'];
}
$class = '';
if ( isset( $_GET['process'] ) && 'template_edit' == $_GET['process'] ) {
	$class = 'ced-ebay-popup-show';
}
?>
<div id="ced-ebay-popup" class="<?php echo esc_attr( $class ); ?> overlay">
	<div class="ced-ebay-popup-wrap">
	<a class="ced_ebay_site_shipping_template_close" href="#">&times;</a>

		<div class="ced-ebay-popup-content">

<div class="ced_ebay_site_new_shipping_template_wrapper">

	<div class="ced_ebay_site_shipping_template_table_wrapper">

		<form method="post">
		<table class="ced_ebay_site_shipping_template_table">

			<tbody>
				<tr>
					<th><?php esc_attr_e( 'Shipping Template Name', 'ced-umb-ebay' ); ?></th>
					<td>
						<?php
						$template_name = '';
						if ( isset( $template_data['shipping_name'] ) ) {
							$template_name = $template_data['shipping_name'];
						}
						?>
						<input type="text" name = "shippingdetails[template_name]" value = "<?php echo esc_attr( $template_name ); ?>">
					</td>
				</tr>
				<tr>
					<th><?php esc_attr_e( 'Service Type', 'ced-umb-ebay' ); ?></th>
					<td class="manage-column">
						<select id="ced_ebay_shipping_service_type" name="shippingdetails[serviceType]">
							<?php
							$flateChecked = '';
							if ( isset( $savedShippingDetails['serviceType'] ) ) {
								if ( 'Flat' == $savedShippingDetails['serviceType'] ) {
									$flateChecked = 'selected';
								}
							}
							$calculatedChecked = '';
							if ( isset( $savedShippingDetails['serviceType'] ) ) {
								if ( 'Calculated' == $savedShippingDetails['serviceType'] ) {
									$calculatedChecked = 'selected';
								}
							}
							?>
							<option <?php echo esc_attr( $flateChecked ); ?> value="Flat"><?php esc_attr_e( 'Flat', 'ced-umb-ebay' ); ?></option>
							<option <?php echo esc_attr( $calculatedChecked ); ?> value="Calculated"><?php esc_attr_e( 'Calculated', 'ced-umb-ebay' ); ?></option>
						</select>
					</td>
				</tr>
				<tr class="ced_ebay_shipping_postal_code">
					<th><?php esc_attr_e( 'Postal Code', 'ced-umb-ebay' ); ?></th>
					<td class="manage-column">
						<?php
						$postal_code = '';
						if ( isset( $savedShippingDetails['postal_code'] ) ) {
							$postal_code = $savedShippingDetails['postal_code'];
						}
						?>
						<input type="text" name = "shippingdetails[postal_code]" value = "<?php echo esc_attr( $postal_code ); ?>">
					</td>
				</tr>
				<tr class="ced_ebay_shipping_postal_code">
					<th><?php esc_attr_e( 'Exclude Countries', 'ced-umb-ebay' ); ?></th>
					<td class="manage-column">
						<?php
						$exclusion_list = array();
						if ( isset( $savedShippingDetails['exclusion_list'] ) ) {
							$selected       = '';
							$exclusion_list = $savedShippingDetails['exclusion_list'];
						}
						?>
						<select name="shippingdetails[exclusion_list][]" class="ced_ebay_exclusion_countries_selection" multiple="multiple">
						<option value="null"> -- select -- </option>
						<optgroup label="Domestic">
							<option
							<?php
							if ( in_array( 'Domestic_Channel Islands', $exclusion_list ) ) {
								echo 'selected';
							}
							?>
							value="Domestic_Channel Islands">Channel Islands</option>
							<option
							<?php
							if ( in_array( 'Domestic_Isle of Wight', $exclusion_list ) ) {
								echo 'selected';
							}
							?>
							value="Domestic_Isle of Wight">Isle of Wight</option>
							<option
							<?php
							if ( in_array( 'Domestic_Isle of Man', $exclusion_list ) ) {
								echo 'selected';
							}
							?>
							value="Domestic_Isle of Man">Isle of Man</option>
							<option
							<?php
							if ( in_array( 'Domestic_Scilly Isles', $exclusion_list ) ) {
								echo 'selected';
							}
							?>
							value="Domestic_Scilly Isles">Scilly Isles</option>
							<option
							<?php
							if ( in_array( 'Domestic_Scottish Highlands', $exclusion_list ) ) {
								echo 'selected';
							}
							?>
							value="Domestic_Scottish Highlands">Scottish Highlands</option>
							<option
							<?php
							if ( in_array( 'Domestic_Scottish Islands', $exclusion_list ) ) {
								echo 'selected';
							}
							?>
							value="Domestic_Scottish Islands">Scottish Islands</option>
							<option
							<?php
							if ( in_array( 'Domestic_Northern Ireland', $exclusion_list ) ) {
								echo 'selected';
							}
							?>
							value="Domestic_Northern Ireland">Northern Ireland</option>
						<optgroup label="International">
							<?php
							foreach ( $countries_list as $key => $exclusion_country ) {
								if ( strpos( $key, 'Domestic_' ) !== false ) {
									continue;
								}
								?>
								<option
								<?php
								if ( in_array( 'International_' . $key, $exclusion_list ) ) {
									echo 'selected';
								}
								?>
								value="<?php echo 'International_' . esc_attr( $key ); ?>"><?php echo esc_attr( $exclusion_country ); ?></option>
								<?php
							}
							?>
						</select>
					</td>
				</tr>
				<?php
				// if( isset( $savedShippingDetails['serviceType'] ) && $savedShippingDetails['serviceType'] == "Calculated" )
				// {
				$shippingweightmajor = isset( $savedShippingDetails['shippingweightmajor'] ) ? $savedShippingDetails['shippingweightmajor'] : '';
				$shippingweightminor = isset( $savedShippingDetails['shippingweightminor'] ) ? $savedShippingDetails['shippingweightminor'] : '';
				?>
				<tr class="ced_ebay_shipping_weight_range_row">
				<th>Package Weight Range <span style="color:red;">(Only numberic)</span></th>
					<td class="manage-column ced_ebay_ship_weight_minor">
						<input type="text" placeholder="Package Min. Weight" value="<?php echo esc_attr( $shippingweightminor ); ?>" name = "shippingdetails[shippingweightminor]">
					</td>
					<td class="manage-column ced_ebay_ship_weight_major">
						<input type="text" placeholder="Package Max. Weight" value="<?php echo esc_attr( $shippingweightmajor ); ?>" name = "shippingdetails[shippingweightmajor]" value = "">
					</td>
					<td>
						<h3><?php echo esc_html( get_option( 'woocommerce_weight_unit' ) ); ?></h3>
					</td>
				</tr>
				<?php
				// }
				if ( isset( $savedShippingDetails['serviceType'] ) && 'Calculated' == $savedShippingDetails['serviceType'] ) {
					$domesticPackagingCost      = isset( $savedShippingDetails['domesticPackagingCost'] ) ? $savedShippingDetails['domesticPackagingCost'] : '';
					$internationalPackagingCost = isset( $savedShippingDetails['internationalPackagingCost'] ) ? $savedShippingDetails['internationalPackagingCost'] : '';
					?>

					<tr class="ced-ebay-domestic-handling-cost-row">
						<th><?php esc_attr_e( 'Domestic Package Handling Cost', 'ced-umb-ebay' ); ?></th>
						<td>
							<input type="text" placeholder="<?php esc_attr_e( 'Package Handling Cost', 'ced-umb-ebay' ); ?>" name = "shippingdetails[domesticPackagingCost]" value="<?php echo esc_attr( $domesticPackagingCost ); ?>">
						</td>
					</tr>
					<tr class="ced-ebay-international-handling-cost-row">
						<th><?php esc_attr_e( 'International Package Handling Cost', 'ced-umb-ebay' ); ?></th>
						<td>
							<input type="text" placeholder="<?php esc_attr_e( 'Package Handling Cost', 'ced-umb-ebay' ); ?>" name = "shippingdetails[internationalPackagingCost]" value="<?php echo esc_attr( $internationalPackagingCost ); ?>">
						</td>
					</tr>
					<?php
				}
				$selected = '';
				require_once CED_EBAY_DIRPATH . 'admin/ebay/lib/ebayUpload.php';

				$shippingDetails = array();
				if ( '' != $token && null != $token ) {
					$mainXml            = '<?xml version="1.0" encoding="utf-8"?>
					<GeteBayDetailsRequest xmlns="urn:ebay:apis:eBLBaseComponents">
					<RequesterCredentials>
					<eBayAuthToken>' . $token . '</eBayAuthToken>
					</RequesterCredentials>
					<DetailName>ShippingCarrierDetails</DetailName>
					<DetailName>ShippingServiceDetails</DetailName>
					</GeteBayDetailsRequest> ';
					$ebayUploadInstance = EbayUpload::get_instance( $siteID, $token );
					$mode_of_operation  = get_option( 'ced_ebay_mode_of_operation', '' );
					if ( 'sandbox' == $mode_of_operation ) {
						$shippingDetails = $ebayUploadInstance->get_shipping_return_service_for_site( $mainXml );
					} else {
						$shippingDetails = $ebayUploadInstance->get_shipping_return_service_for_site( $mainXml );
					}
				}
				?>

			</tbody>
			<tbody>
				<?php
				if ( is_array( $shippingDetails ) && ! empty( $shippingDetails ) && isset( $shippingDetails['ShippingServiceDetails'] ) ) {
					if ( isset( $savedShippingDetails['domesticShippingService'] ) ) {
						foreach ( $savedShippingDetails['domesticShippingService']['services'] as $key1 => $value1 ) {
							?>
							<tr class="ced_ebay_domestic_shipping_service_row">
								<th><?php esc_attr_e( 'Domestic Shipping Service', 'ced-umb-ebay' ); ?></th>
								<td class="manage-column umb_ebay_shipping-service-based-on-site">
									<select name="shippingdetails[domesticShippingService][services][]">
										<option value="">--Select--</option>
										<?php
										if ( 'Success' == $shippingDetails['Ack'] || 'Warning' == $shippingDetails['Ack'] ) {
											foreach ( $shippingDetails['ShippingServiceDetails'] as $key => $service ) {
												if ( isset( $service['ValidForSellingFlow'] ) && 'true' === $service['ValidForSellingFlow'] && ! isset( $service['InternationalService'] ) ) {
													if ( isset( $value1 ) && $value1 == $service['ShippingService'] ) {
														$selected = 'selected';
													}
													?>
													<option
													<?php
													if ( ! empty( $service['ServiceType'] ) ) {
														if ( is_array( $service['ServiceType'] ) && count( $service['ServiceType'] ) == 2 ) {
															$serviceType = 'Flat, Calculated';
														} else {
															$serviceType = $service['ServiceType'];
														}
													}
													if ( 'selected' == $selected ) {
														echo 'selected';}
													?>
													 value="<?php echo esc_attr( $service['ShippingService'] ); ?>"><?php echo esc_attr( $service['Description'] . ' ( ' . $serviceType . ' )' ); ?></option>
													<?php
													$selected = '';
												}
											}
										}
										?>
									</select>
								</td>
								<?php
								if ( isset( $savedShippingDetails['serviceType'] ) && 'Calculated' != $savedShippingDetails['serviceType'] ) {
									?>
									<td class="manage-column ced_ebay_dom_ship_cost">
										<?php
										$shippingCost = '';
										if ( isset( $savedShippingDetails['domesticShippingService']['shippingcost'][ $key1 ] ) ) {
											$shippingCost = $savedShippingDetails['domesticShippingService']['shippingcost'][ $key1 ];
										}
										?>
										<input type="text" placeholder="<?php esc_attr_e( 'Shipping Cost', 'ced-umb-ebay' ); ?>" name = "shippingdetails[domesticShippingService][shippingcost][]" value = "<?php echo esc_attr( $shippingCost ); ?>">
									</td>
									<td class="manage-column ced_ebay_dom_add_ship_cost">
										<?php
										$shippingaddCost = '';
										if ( isset( $savedShippingDetails['domesticShippingService']['shippingaddcost'][ $key1 ] ) ) {
											$shippingaddCost = $savedShippingDetails['domesticShippingService']['shippingaddcost'][ $key1 ];
										}
										?>
										<input type="text" placeholder="<?php esc_attr_e( 'Add. Cost', 'ced-umb-ebay' ); ?>" name = "shippingdetails[domesticShippingService][shippingaddcost][]" value = "<?php echo esc_attr( $shippingaddCost ); ?>">
									</td>
									<?php
								}
								?>
							</tr>
							<?php
						}
					}
					?>
					<tr class="ced_ebay_domestic_shipping_service_row">
						<th><?php esc_attr_e( 'Domestic Shipping Service', 'ced-umb-ebay' ); ?></th>
						<td   class="manage-column umb_ebay_shipping-service-based-on-site">
							<select name="shippingdetails[domesticShippingService][services][]">
								<option value="">--Select--</option>
								<?php
								foreach ( $shippingDetails['ShippingServiceDetails'] as $key => $service ) {
									if ( isset( $service['ValidForSellingFlow'] ) && 'true' === $service['ValidForSellingFlow'] && ! isset( $service['InternationalService'] ) ) {
										if ( ! empty( $service['ServiceType'] ) ) {
											if ( is_array( $service['ServiceType'] ) && count( $service['ServiceType'] ) == 2 ) {
												$serviceType = 'Flat, Calculated';
											} else {
												$serviceType = $service['ServiceType'];
											}
										}
										?>
										<option value="<?php echo esc_attr( $service['ShippingService'] ); ?>"><?php echo esc_attr( $service['Description'] . ' ( ' . $serviceType . ' )' ); ?></option>
										<?php
									}
								}
								?>
							</select>
						</td>
						<?php
						if ( ! isset( $savedShippingDetails['serviceType'] ) || ( isset( $savedShippingDetails['serviceType'] ) && 'Calculated' != $savedShippingDetails['serviceType'] ) ) {
							?>
							<td class="manage-column ced_ebay_dom_ship_cost">
								<input type="text" placeholder="<?php esc_attr_e( 'Shipping Cost', 'ced-umb-ebay' ); ?>" name = "shippingdetails[domesticShippingService][shippingcost][]">
							</td>
							<td class="manage-column ced_ebay_dom_add_ship_cost">
								<input type="text" placeholder="<?php esc_attr_e( 'Add. Cost', 'ced-umb-ebay' ); ?>" name = "shippingdetails[domesticShippingService][shippingaddcost][]" value = "">
							</td>
							<!-- <td></td> -->
							<?php
						}
						?>
						<td>
							<input type="button" class="ced_ebay_add_domestic_shipping_service_row button button-primary" value="Add More"></input>
							<input type="button" class="ced_ebay_remove_domestic_shipping_row_button button button-primary" style="display:none;" value="Remove"></input>
						</td>
					</tr>
					<tr></tr>
					<?php
				} else {
					?>
					<tr>
						<td>
							<?php
							if ( empty( $shippingDetails ) ) {
								esc_attr_e( 'Please Select the Location of Store to select shipping templates', 'ced-umb-ebay' );
							} elseif ( 'Success' != $shippingDetails['Ack'] ) {
								esc_attr_e( 'Please try again later. Internal Error to the Api', 'ced-umb-ebay' );
							}
							?>
						</td>

					</tr>
					<?php
				}
				?>
				<?php
				if ( is_array( $shippingDetails ) && ! empty( $shippingDetails ) && isset( $shippingDetails['ShippingServiceDetails'] ) ) {
					if ( isset( $savedShippingDetails['internationalShippingService'] ) ) {
						$key1 = 0;
						foreach ( $savedShippingDetails['internationalShippingService']['services'] as $key1 => $value1 ) {
							?>
							<tr class="ced_ebay_international_shipping_service_row">
								<th><?php esc_attr_e( 'International Shipping Service', 'ced-umb-ebay' ); ?></th>
								<td   class="manage-column umb_ebay_shipping-service-based-on-site" >
									<select name="shippingdetails[internationalShippingService][services][]">
										<option value="">--Select--</option>
										<?php
										if ( 'Success' == $shippingDetails['Ack'] || 'Warning' == $shippingDetails['Ack'] ) {
											foreach ( $shippingDetails['ShippingServiceDetails'] as $key => $service ) {
												if ( isset( $service['ValidForSellingFlow'] ) && 'true' === $service['ValidForSellingFlow'] && isset( $service['InternationalService'] ) ) {
													if ( isset( $value1 ) && $value1 == $service['ShippingService'] ) {
														$selected = 'selected';
													}
													?>
													<option
													<?php
													if ( ! empty( $service['ServiceType'] ) ) {
														if ( is_array( $service['ServiceType'] ) && count( $service['ServiceType'] ) == 2 ) {
															$serviceType = 'Flat, Calculated';
														} else {
															$serviceType = $service['ServiceType'];
														}
													}
													if ( 'selected' == $selected ) {
														echo 'selected';}
													?>
													 value="<?php echo esc_attr( $service['ShippingService'] ); ?>"><?php echo esc_attr( $service['Description'] . ' ( ' . $serviceType . ' )' ); ?></option>
													<?php
													$selected = '';
												}
											}
										}
										?>
									</select>
								</td>
								<?php
								if ( isset( $savedShippingDetails['serviceType'] ) && 'Calculated' != $savedShippingDetails['serviceType'] ) {
									?>
									<td class="manage-column ced_ebay_intl_ship_cost">
										<?php
										$shippingCost = '';
										if ( isset( $savedShippingDetails['internationalShippingService']['shippingcost'][ $key1 ] ) ) {
											$shippingCost = $savedShippingDetails['internationalShippingService']['shippingcost'][ $key1 ];
										}
										?>
										<input type="text" placeholder="<?php esc_attr_e( 'Shipping Cost', 'ced-umb-ebay' ); ?>" name = "shippingdetails[internationalShippingService][shippingcost][]" value = "<?php echo esc_attr( $shippingCost ); ?>">
									</td>
									<td class="manage-column ced_ebay_intl_add_ship_cost">
										<?php
										$shippingaddCost = '';
										if ( isset( $savedShippingDetails['internationalShippingService']['shippingaddcost'][ $key1 ] ) ) {
											$shippingaddCost = $savedShippingDetails['internationalShippingService']['shippingaddcost'][ $key1 ];
										}
										?>
										<input type="text" placeholder="<?php esc_attr_e( 'Add. Cost', 'ced-umb-ebay' ); ?>" name = "shippingdetails[internationalShippingService][shippingaddcost][]" value = "<?php echo esc_attr( $shippingaddCost ); ?>">
									</td>
									<?php
								}
								?>
								<td>
									<select multiple="multiple" class="select_location ced_etsy_ship_to_locations" name="shippingdetails[internationalShippingService][locations][<?php echo esc_attr( $key1 ); ?>][]" data-placeholder="Select locations">
										<option value="CN"
										<?php
										if ( isset( $savedShippingDetails['internationalShippingService']['locations'][ $key1 ] ) && is_array( $savedShippingDetails['internationalShippingService']['locations'][ $key1 ] ) && in_array( 'CN', $savedShippingDetails['internationalShippingService']['locations'][ $key1 ] ) ) {
																echo 'selected';}
										?>
										>China</option>
										<option value="RU"
										<?php
										if ( isset( $savedShippingDetails['internationalShippingService']['locations'][ $key1 ] ) && is_array( $savedShippingDetails['internationalShippingService']['locations'][ $key1 ] ) && in_array( 'RU', $savedShippingDetails['internationalShippingService']['locations'][ $key1 ] ) ) {
																echo 'selected';}
										?>
										>Russian Federation</option>
										<option value="CA"
										<?php
										if ( isset( $savedShippingDetails['internationalShippingService']['locations'][ $key1 ] ) && is_array( $savedShippingDetails['internationalShippingService']['locations'][ $key1 ] ) && in_array( 'CA', $savedShippingDetails['internationalShippingService']['locations'][ $key1 ] ) ) {
																echo 'selected';}
										?>
										>Canada</option>
										<option value="BR"
										<?php
										if ( isset( $savedShippingDetails['internationalShippingService']['locations'][ $key1 ] ) && is_array( $savedShippingDetails['internationalShippingService']['locations'][ $key1 ] ) && in_array( 'BR', $savedShippingDetails['internationalShippingService']['locations'][ $key1 ] ) ) {
																echo 'selected';}
										?>
										>Brazil</option>
										<option value="DE"
										<?php
										if ( isset( $savedShippingDetails['internationalShippingService']['locations'][ $key1 ] ) && is_array( $savedShippingDetails['internationalShippingService']['locations'][ $key1 ] ) && in_array( 'DE', $savedShippingDetails['internationalShippingService']['locations'][ $key1 ] ) ) {
																echo 'selected';}
										?>
										>Germany</option>
										<option value="FR"
										<?php
										if ( isset( $savedShippingDetails['internationalShippingService']['locations'][ $key1 ] ) && is_array( $savedShippingDetails['internationalShippingService']['locations'][ $key1 ] ) && in_array( 'FR', $savedShippingDetails['internationalShippingService']['locations'][ $key1 ] ) ) {
																echo 'selected';}
										?>
										>France</option>
										<option value="Europe"
										<?php
										if ( isset( $savedShippingDetails['internationalShippingService']['locations'][ $key1 ] ) && is_array( $savedShippingDetails['internationalShippingService']['locations'][ $key1 ] ) && in_array( 'Europe', $savedShippingDetails['internationalShippingService']['locations'][ $key1 ] ) ) {
																echo 'selected';}
										?>
										>Europe</option>
										<option value="GB"
										<?php
										if ( isset( $savedShippingDetails['internationalShippingService']['locations'][ $key1 ] ) && is_array( $savedShippingDetails['internationalShippingService']['locations'][ $key1 ] ) && in_array( 'GB', $savedShippingDetails['internationalShippingService']['locations'][ $key1 ] ) ) {
																echo 'selected';}
										?>
										>United Kingdom</option>
										<option value="Americas"
										<?php
										if ( isset( $savedShippingDetails['internationalShippingService']['locations'][ $key1 ] ) && is_array( $savedShippingDetails['internationalShippingService']['locations'][ $key1 ] ) && in_array( 'Americas', $savedShippingDetails['internationalShippingService']['locations'][ $key1 ] ) ) {
																echo 'selected';}
										?>
										>N. and S. America</option>
										<option value="Asia"
										<?php
										if ( isset( $savedShippingDetails['internationalShippingService']['locations'][ $key1 ] ) && is_array( $savedShippingDetails['internationalShippingService']['locations'][ $key1 ] ) && in_array( 'Asia', $savedShippingDetails['internationalShippingService']['locations'][ $key1 ] ) ) {
																echo 'selected';}
										?>
										>Asia</option>
										<option value="AU"
										<?php
										if ( isset( $savedShippingDetails['internationalShippingService']['locations'][ $key1 ] ) && is_array( $savedShippingDetails['internationalShippingService']['locations'][ $key1 ] ) && in_array( 'AU', $savedShippingDetails['internationalShippingService']['locations'][ $key1 ] ) ) {
																echo 'selected';}
										?>
										>Australia</option>
										<option value="MX"
										<?php
										if ( isset( $savedShippingDetails['internationalShippingService']['locations'][ $key1 ] ) && is_array( $savedShippingDetails['internationalShippingService']['locations'][ $key1 ] ) && in_array( 'MX', $savedShippingDetails['internationalShippingService']['locations'][ $key1 ] ) ) {
																echo 'selected';}
										?>
										>Mexico</option>
										<option value="Worldwide"
										<?php
										if ( isset( $savedShippingDetails['internationalShippingService']['locations'][ $key1 ] ) && is_array( $savedShippingDetails['internationalShippingService']['locations'][ $key1 ] ) && in_array( 'Worldwide', $savedShippingDetails['internationalShippingService']['locations'][ $key1 ] ) ) {
																echo 'selected';}
										?>
										>Worldwide</option>
										<option value="JP"
										<?php
										if ( isset( $savedShippingDetails['internationalShippingService']['locations'][ $key1 ] ) && is_array( $savedShippingDetails['internationalShippingService']['locations'][ $key1 ] ) && in_array( 'JP', $savedShippingDetails['internationalShippingService']['locations'][ $key1 ] ) ) {
																echo 'selected';}
										?>
										>Japan</option>
									</select>
								</td>
							</tr>
							<?php
						}
					}
					?>
					<?php
					if ( isset( $key1 ) && $key1 > 0 ) {
						++$key1;
					} else {
						$key1 = 0;
					}
					?>
					<tr class="ced_ebay_international_shipping_service_row">
						<th><?php esc_attr_e( 'International Shipping Service', 'ced-umb-ebay' ); ?></th>
						<td   class="manage-column umb_ebay_shipping-service-based-on-site">
							<select name="shippingdetails[internationalShippingService][services][]">
								<option value="">--Select--</option>
								<?php
								foreach ( $shippingDetails['ShippingServiceDetails'] as $key => $service ) {
									if ( isset( $service['ValidForSellingFlow'] ) && 'true' === $service['ValidForSellingFlow'] && isset( $service['InternationalService'] ) ) {
										if ( ! empty( $service['ServiceType'] ) ) {
											if ( is_array( $service['ServiceType'] ) && count( $service['ServiceType'] ) == 2 ) {
												$serviceType = 'Flat, Calculated';
											} else {
												$serviceType = $service['ServiceType'];
											}
										}
										?>
										<option value="<?php echo esc_attr( $service['ShippingService'] ); ?>"><?php echo esc_attr( $service['Description'] . ' ( ' . $serviceType . ' )' ); ?></option>
										<?php
									}
								}
								?>
							</select>
						</td>
						<?php
						if ( ! isset( $savedShippingDetails['serviceType'] ) || ( isset( $savedShippingDetails['serviceType'] ) && 'Calculated' != $savedShippingDetails['serviceType'] ) ) {
							?>
							<td class="ced_ebay_intl_ship_cost">
								<input type="text" placeholder="<?php esc_attr_e( 'Shipping Cost', 'ced-umb-ebay' ); ?>" name = "shippingdetails[internationalShippingService][shippingcost][]">
							</td>
							<td class="ced_ebay_intl_add_ship_cost">
								<input type="text" placeholder="<?php esc_attr_e( 'Add. Cost', 'ced-umb-ebay' ); ?>" name = "shippingdetails[internationalShippingService][shippingaddcost][]" value = "">
							</td>
							<?php
						}
						?>
						<td>
							<select multiple="multiple" class="select_location ced_etsy_ship_to_locations" name="shippingdetails[internationalShippingService][locations][<?php echo esc_attr( $key1 ); ?>][]" data-placeholder="Select locations">
								<option value="CN">China</option>
								<option value="RU">Russian Federation</option>
								<option value="CA">Canada</option>
								<option value="BR">Brazil</option>
								<option value="DE">Germany</option>
								<option value="FR">France</option>
								<option value="Europe">Europe</option>
								<option value="GB">United Kingdom</option>
								<option value="Americas">N. and S. America</option>
								<option value="Asia">Asia</option>
								<option value="AU">Australia</option>
								<option value="MX">Mexico</option>
								<option value="Worldwide">Worldwide</option>
								<option value="JP">Japan</option>
							</select>
						</td>
						<td>
							<input type="button" data-add = <?php echo esc_attr( $key1 ); ?> class="ced_ebay_add_intl_shipping_service_row button button-primary" value="Add More"></input>
							<input type="button" data-add = <?php echo esc_attr( $key1 ); ?> class="ced_ebay_remove_intl_shipping_service_row button button-primary" style="display:none;" value="Remove"></input>

						</td>
					</tr>
					<?php
				}
				?>

		</tbody>

	</table>
<?php wp_nonce_field( 'ced_ebay_shipping_page_nonce', 'ced_ebay_shipping_nonce' ); ?>
	<!-- <p class="ced_umb_ebay_button_right">
		<input class="button button-ced_umb_ebay" value="<?php esc_attr_e( 'Save Details', 'ced-umb-ebay' ); ?>" name="saveShippingPolicies" type="submit">
	</p> -->
	<div class="ced_ebay_shipping_button_wrap">
	<input name="saveShippingPolicies" class="button button-primary button-large"  value="Save Template" type="submit">
	</div>

</form>
</div>
	</div>
</div>
</div>
</div>
<script>
	jQuery(document).ready(function() {
	jQuery(".ced_ebay_exclusion_countries_selection").selectWoo();
});
</script>
