<?php
// If this file is called directly, abort.
if ( ! defined( 'ABSPATH' ) ) {
	die;
}
$shop_name = isset( $_GET['user_id'] ) ? sanitize_text_field( $_GET['user_id'] ) : '';
$shop_data = ced_ebay_get_shop_data( $shop_name );
if ( ! empty( $shop_data ) ) {
	$siteID      = $shop_data['site_id'];
	$token       = $shop_data['access_token'];
	$getLocation = $shop_data['location'];
}
if ( isset( $_POST['ced_ebay_payment_nonce'] ) && wp_verify_nonce( sanitize_text_field( $_POST['ced_ebay_payment_nonce'] ), 'ced_ebay_payment_page_nonce' ) ) {
	if ( isset( $_POST['ced_ebay_site_settings_save_payment_button'] ) ) {
		$sanitized_array                        = filter_input_array( INPUT_POST, FILTER_UNSAFE_RAW );
		$ced_ebay_site_selected_payment_options = isset( $sanitized_array['ced_ebay_site_selected_payment_options'] ) ? ( $sanitized_array['ced_ebay_site_selected_payment_options'] ) : array();
		$email                                  = isset( $sanitized_array['ced_ebay_site_email_address'] ) ? ( $sanitized_array['ced_ebay_site_email_address'] ) : '';
		if ( ! empty( $ced_ebay_site_selected_payment_options ) ) {
			update_option( 'ced_umb_ebay_site_selected_payment_methods_' . $shop_name, $ced_ebay_site_selected_payment_options );
			if ( 'PayPal' == $ced_ebay_site_selected_payment_options[0] ) {
				if ( ! empty( $email ) ) {
					update_option( 'ced_ebay_site_email_address_' . $shop_name, $email );
				} else {
					?>
						<div class="notice notice-error is-dismissible">
				<p><?php echo esc_html( 'Please enter a valid PayPal Email Address!' ); ?></p>
			</div>
						<?php
				}
			}
		} else {
			?>
				<div class="notice notice-error is-dismissible">
				<p><?php echo esc_html( 'Please select atleast one Payment Method before proceeding' ); ?></p>
			</div>
			<?php
		}
	}
}

$payment_methods = array();
$payment_methods = get_option( 'ced_umb_ebay_site_payment_methods_' . $shop_name, array() );

$selected_payment_methods = array();
$selected_payment_methods = get_option( 'ced_umb_ebay_site_selected_payment_methods_' . $shop_name, array() );
if ( ! is_array( $selected_payment_methods ) ) {
	$selected_payment_methods = array();
}
$email = get_option( 'ced_ebay_site_email_address_' . $shop_name, '' );

if ( empty( $payment_methods ) ) {
	if ( ! empty( $token ) ) {
		require_once CED_EBAY_DIRPATH . 'admin/ebay/lib/ebayUpload.php';
		$ebayUploadInstance            = EbayUpload::get_instance( $siteID, $token );
		$mainXml                       = '<?xml version="1.0" encoding="utf-8"?>
						<GetCategoryFeaturesRequest xmlns="urn:ebay:apis:eBLBaseComponents">
						  <RequesterCredentials>
						    <eBayAuthToken>' . $token . '</eBayAuthToken>
						  </RequesterCredentials>
						  <DetailLevel>ReturnAll</DetailLevel>
						  <AllFeaturesForCategory>true</AllFeaturesForCategory>
						</GetCategoryFeaturesRequest>';
		$site_specific_payment_methods = $ebayUploadInstance->get_sitespecific_payment_methods( $mainXml );
		if ( is_array( $site_specific_payment_methods ) && ! empty( $site_specific_payment_methods ) ) {
			if ( isset( $site_specific_payment_methods['SiteDefaults'] ) ) {
				$payment_methods = $site_specific_payment_methods['SiteDefaults']['PaymentMethod'];
				update_option( 'ced_umb_ebay_site_payment_methods_' . $shop_name, $payment_methods );
			}
		}
	}
}
?>

<div class="ced_ebay_site_payment_option_wrapper">
	<?php
	if ( ! empty( $payment_methods ) ) {
		?>
		<div class="ced_ebay_site_payment_options">
			<h1 style="font-size:18px;">If you are using eBay Manage Payments option you can leave this section blank.</h1>
			<form action="" method="post">
				<?php
				foreach ( $payment_methods as $key => $value ) {
					$selected = '';
					if ( in_array( $value, $selected_payment_methods ) ) {
						$selected = 'checked';
					}
					?>
					<div class="ced_ebay_site_payment_option">
					<div class="checkbox">
		<input id="<?php echo esc_attr( $value ); ?>" type="checkbox" name="ced_ebay_site_selected_payment_options[]"  value="<?php echo esc_attr( $value ); ?>" <?php echo esc_attr( $selected ); ?> class="checkbox__input">
		<label for="<?php echo esc_attr( $value ); ?>" class="checkbox__label"><?php echo esc_attr( $value ); ?></label>
	</div>

					</div>
					<?php
				}
				?>
				<label>Paypal Email Address</label><input type="text" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$" name="ced_ebay_site_email_address" class="ced_email_address_field" value="<?php echo esc_attr( $email ); ?>">
				<?php wp_nonce_field( 'ced_ebay_payment_page_nonce', 'ced_ebay_payment_nonce' ); ?>
				<footer>
				<input type="submit" name="ced_ebay_site_settings_save_payment_button" class="ced_ebay_button button button-primary" id="ced_ebay_site_settings_save_payment_button" value="Save Details">

				</footer>
			</form>
		</div>
		<?php
	}
	?>
</div>
