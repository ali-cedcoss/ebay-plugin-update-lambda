<?php

// phpinfo();
// die;
// If this file is called directly, abort.
if ( ! defined( 'ABSPATH' ) ) {
	die;
}

if ( empty( get_option( 'ced_ebay_user_access_token' ) ) ) {
	wp_redirect( get_admin_url() . 'admin.php?page=ced_ebay' );
}

$file = CED_EBAY_DIRPATH . 'admin/partials/header.php';
if ( file_exists( $file ) ) {
	require_once $file;
}

if ( ! class_exists( 'WP_List_Table' ) ) {
	require_once ABSPATH . 'wp-admin/includes/class-wp-list-table.php';
}

class EBayListProducts extends WP_List_Table {


	public function __construct() {
		parent::__construct(
			array(
				'singular' => __( 'ced-ebay-product', 'ebay-integration-for-woocommerce' ), // singular name of the listed records
				'plural'   => __( 'ced-ebay-products', 'ebay-integration-for-woocommerce' ), // plural name of the listed records
				'ajax'     => true, // does this table support ajax?
			)
		);

	}

	/**
	 *
	 * Function for preparing data to be displayed
	 */

	public function prepare_items() {

		global $wpdb;
		$user_id = isset( $_GET['user_id'] ) ? sanitize_text_field( $_GET['user_id'] ) : '';

		if ( isset( $_POST['ced_ebay_view_entries_product_section'] ) && wp_verify_nonce( sanitize_text_field( $_POST['ced_ebay_view_entries_product_section'] ), 'ced_ebay_view_entries_product_section_nonce' ) ) {
			$per_page_preference = ! empty( $_POST['ced_ebay_view_entries_prod_section_input'] ) ? sanitize_text_field( $_POST['ced_ebay_view_entries_prod_section_input'] ) : 0;
			if ( is_numeric( $per_page_preference ) ) {
				update_option( 'ced_ebay_product_section_per_page_' . $user_id, $per_page_preference );
			} else {
				?>
						 <div class="notice notice-error">
							<p>Invalid input. Only numbers are allowed.</p>
			</div>
				<?php
			}
		}

		$per_page = ! empty( get_option( 'ced_ebay_product_section_per_page_' . $user_id ) ) ? get_option( 'ced_ebay_product_section_per_page_' . $user_id ) : 50;

		$post_type = 'product';
		$columns   = $this->get_columns();
		$hidden    = array();
		$sortable  = $this->get_sortable_columns();

		// Column headers
		$this->_column_headers = array( $columns, $hidden, $sortable );

		$current_page = $this->get_pagenum();
		if ( 1 < $current_page ) {
			$offset = $per_page * ( $current_page - 1 );
		} else {
			$offset = 0;
		}
		$this->items = self::ced_ebay_get_product_details( $per_page, $current_page, $post_type );
		$count       = self::get_count( $per_page, $current_page );
		// Set the pagination
		$this->set_pagination_args(
			array(
				'total_items' => $count,
				'per_page'    => $per_page,
				'total_pages' => ceil( $count / $per_page ),
			)
		);
		// echo '<pre>';print_r($this);die;

		if ( ! $this->current_action() ) {
			// $this->items = self::ced_ebay_get_product_details( $per_page, $current_page ,$post_type  );
			$this->renderHTML();
		} else {
			$this->process_bulk_action();
		}
	}

	/**
	 *
	 * Function for get product data
	 */
	public function ced_ebay_get_product_details( $per_page = '', $page_number = '', $post_type = '' ) {
		$product_data = array();
		$filterFile   = CED_EBAY_DIRPATH . 'admin/partials/products-filters.php';
		if ( file_exists( $filterFile ) ) {
			require_once $filterFile;
		}
		$user_id = isset( $_GET['user_id'] ) ? sanitize_text_field( $_GET['user_id'] ) : '';

		$instanceOf_FilterClass = new FilterClass();

		$args = $this->GetFilteredData( $per_page, $page_number );

		if ( ! empty( $args ) && isset( $args['tax_query'] ) || isset( $args['meta_query'] ) || isset( $args['s'] ) ) {
			$args = $args;
		} elseif ( ! isset( $args['prodID'] ) && ! isset( $args['search_by_sku'] ) && ! isset( $args['profileID'] ) ) {
			$args = array(
				'post_type'      => $post_type,
				'post_status'    => 'publish',
				'posts_per_page' => $per_page,
				'paged'          => $page_number,
			);
		} elseif ( isset( $args['search_by_sku'] ) ) {
			$args = array(
				'post_type'           => 'product',
				'post_status'         => 'publish',
				'ignore_sticky_posts' => 1,
				'meta_key'            => '_sku',
				'meta_value'          => $args['search_by_sku'],
				'meta_compare'        => 'LIKE',
			);
		}
		if ( isset( $args['prodID'] ) ) {
			$prod           = new stdClass();
			$prod->ID       = $args['prodID'];
			$product_data[] = $prod->ID;
		} elseif ( isset( $args['profileID'] ) ) {
			$cat_args = array(
				'taxonomy'   => 'product_cat',
				'hide_empty' => false,
				'meta_query' => array(

					'key'     => 'ced_ebay_profile_id_' . $user_id,
					'value'   => $args['profileID'],
					'compare' => 'LIKE',

				),
			);
			$filtered_categories = get_terms( $cat_args );

			if ( ! empty( $filtered_categories ) ) {
				$product_terms_ids = array();
				$product_terms     = '';
				foreach ( $filtered_categories as $key => $value ) {
					if ( ! empty( $value->term_id ) ) {
						$product_term_ids[] = $value->term_id;
					}
				}
				if ( is_array( $product_term_ids ) && ! empty( $product_term_ids ) ) {
					$product_terms = implode( ',', $product_term_ids );
				}

				if ( ! empty( $product_terms ) ) {
					if ( ! empty( $args['meta_query'] ) ) {
						$loop = new WP_Query(
							array(
								'post_type'      => 'product',
								'post_status'    => 'publish',
								'posts_per_page' => ! empty( get_option( 'ced_ebay_product_section_per_page_' . $user_id, true ) ) ? get_option( 'ced_ebay_product_section_per_page_' . $user_id, true ) : 10,
								'paged'          => $page_number,
								'tax_query'      => array(
									array(
										'taxonomy'         => 'product_cat',
										'terms'            => $product_term_ids,
										'include_children' => false,
										'operator'         => 'IN',
									),
								),
								'meta_query'     => $args['meta_query'],
							)
						);
					} else {
						$loop = new WP_Query(
							array(
								'post_type'      => 'product',
								'post_status'    => 'publish',
								'posts_per_page' => ! empty( get_option( 'ced_ebay_product_section_per_page_' . $user_id, true ) ) ? get_option( 'ced_ebay_product_section_per_page_' . $user_id, true ) : 10,
								'paged'          => $page_number,
								'tax_query'      => array(
									array(
										'taxonomy'         => 'product_cat',
										'terms'            => $product_term_ids,
										'include_children' => false,
										'operator'         => 'IN',
									),
								),
							)
						);
					}

					if ( $loop->have_posts() ) {
						update_option( 'ced_ebay_profile_filter_count_' . $user_id, $loop->found_posts );
						$product_data = wp_list_pluck( $loop->posts, 'ID' );
					}
				}
			}
		} else {
			$loop         = new WP_Query( $args );
			$product_data = wp_list_pluck( $loop->posts, 'ID' );
		}

		$woo_categories = get_terms( 'product_cat', array( 'hide_empty' => false ) );
		$woo_products   = array();
		if ( is_array( $product_data ) && ! empty( $product_data ) ) {

			foreach ( $product_data as $key => $value ) {
				$get_product_data = wc_get_product( $value );
				// check if $get_product_data is a valid product or not
				if ( ! $get_product_data instanceof WC_Product ) {
					continue;
				}
				$get_product_data = $get_product_data->get_data();
				if ( ! empty( $get_product_data['category_ids'] ) ) {
					rsort( $get_product_data['category_ids'] );
				}
				if ( ! empty( $args['profileID'] ) ) {
					foreach ( $get_product_data['category_ids'] as $key_cat => $cat_id ) {
						if ( ! empty( get_term_meta( $cat_id, 'ced_ebay_profile_id_' . $user_id, true ) ) && ( get_term_meta( $cat_id, 'ced_ebay_profile_id_' . $user_id, true ) ) == $args['profileID'] ) {
							$woo_products[ $key ]['category_id'][] = $cat_id;

						}
					}
				} else {
					$woo_products[ $key ]['category_id'] = isset( $get_product_data['category_ids'] ) ? $get_product_data['category_ids'] : '';

				}

				$woo_products[ $key ]['id']           = $value;
				$woo_products[ $key ]['name']         = $get_product_data['name'];
				$woo_products[ $key ]['stock']        = $get_product_data['stock_quantity'];
				$woo_products[ $key ]['stock_status'] = $get_product_data['stock_status'];
				$woo_products[ $key ]['sku']          = $get_product_data['sku'];
				$woo_products[ $key ]['price']        = $get_product_data['price'];
				$Image_url_id                         = $get_product_data['image_id'];
				$woo_products[ $key ]['image']        = wp_get_attachment_url( $Image_url_id );
				foreach ( $woo_categories as $key1 => $value1 ) {
					if ( isset( $get_product_data['category_ids'] ) ) {
						foreach ( $get_product_data['category_ids'] as $key2 => $prodCat ) {
							if ( $value1->term_id == $prodCat ) {
								$woo_products[ $key ]['category'][] = $value1->name;
							}
						}
					}
				}
			}
		}

		if ( isset( $_POST['ced_ebay_product_filter_nonce'] ) && wp_verify_nonce( sanitize_text_field( $_POST['ced_ebay_product_filter_nonce'] ), 'ced_ebay_product_filter_page_nonce' ) ) {
			if ( isset( $_POST['filter_button'] ) ) {
				$woo_products = $instanceOf_FilterClass->ced_ebay_filters_on_products();
			}
		}

		if ( isset( $_POST['ced_ebay_filter_product_nonce'] ) && wp_verify_nonce( sanitize_text_field( $_POST['ced_ebay_filter_product_nonce'] ), 'ced_ebay_filter_product_action_nonce' ) ) {
			if ( isset( $_POST['ced_ebay_filter_product_button'] ) ) {
				$woo_products = $instanceOf_FilterClass->ced_ebay_product_search_box();
			}
		}

		return $woo_products;

	}

	/**
	 *
	 * Text displayed when no data is available
	 */
	public function no_items() {
		esc_html_e( 'No Products To Show.', 'ebay-integration-for-woocommerce' );
	}

	/**
	 * Columns to make sortable.
	 *
	 * @return array
	 */

	public function get_sortable_columns() {
		$sortable_columns = array();
		return $sortable_columns;
	}

	/*
	 * Render the bulk edit checkbox
	 *
	 */
	public function column_cb( $item ) {
		echo '<div class="admin-custom-action-button-outer"><div class="admin-custom-action-show-button-outer">';
		return sprintf(
			'<input type="checkbox" name="ebay_product_ids[]" class="ebay_products_id" value="%s" /></div></div>',
			$item['id']
		);
	}

	/**
	 *
	 * Function for name column
	 */
	public function column_name( $item ) {
		$user_id = isset( $_GET['user_id'] ) ? sanitize_text_field( $_GET['user_id'] ) : '';
		$url     = get_edit_post_link( $item['id'], '' );
		echo '<div class="admin-custom-action-button-outer"><div class="admin-custom-action-show-button-outer">';
		echo '<b><a class="ced_ebay_prod_name" href="' . esc_attr( $url ) . '" target="_blank">' . esc_attr( $item['name'] ) . '</a></b><br>';
		echo '</div></div>';
		// $actions['modify'] = '<a href="#" data-prod-id="' . esc_html( $item['id'] ) . '">' . __( 'Modify', 'ebay-integration-for-woocommerce' ) . '</a>';
	}

	/**
	 *
	 * Function for profile column
	 */
	public function column_profile( $item ) {
		echo '<div class="admin-custom-action-button-outer"><div class="admin-custom-action-show-button-outer">';
		$user_id                      = isset( $_GET['user_id'] ) ? sanitize_text_field( $_GET['user_id'] ) : '';
		$get_profile_id_of_prod_level = get_post_meta( $item['id'], 'ced_ebay_profile_assigned' . isset( $_GET['user_id'] ) ? sanitize_text_field( $_GET['user_id'] ) : '', true );
		$filtered_profile             = isset( $_GET['profileID'] ) ? sanitize_text_field( $_GET['profileID'] ) : '';
		if ( ! empty( $get_profile_id_of_prod_level ) ) {
			global $wpdb;
			$profile_name = $wpdb->get_results( $wpdb->prepare( "SELECT `profile_name` FROM {$wpdb->prefix}ced_ebay_profiles WHERE `id` = %s", $get_profile_id_of_prod_level ), 'ARRAY_A' );
			$profile_name = isset( $profile_name[0]['profile_name'] ) ? $profile_name[0]['profile_name'] : '';
			echo '<b>' . esc_attr( $profile_name ) . '</b>';
			$profile_id = $get_profile_id_of_prod_level;
		} else {
			$get_ebay_category_id = '';
			foreach ( $item['category_id'] as $key => $category_id ) {
				$get_ebay_category_id_data = get_term_meta( $category_id );
				$get_ebay_category_id      = ! empty( $get_ebay_category_id_data[ 'ced_ebay_mapped_category_' . $user_id ] ) ? $get_ebay_category_id_data[ 'ced_ebay_mapped_category_' . $user_id ] : '';
				if ( ! empty( $get_ebay_category_id ) ) {
					break;
				}
			}
			if ( empty( $get_ebay_category_id ) && ! empty( $get_ebay_category_id_data[ 'ced_ebay_profile_id_' . $user_id ] ) ) {
				$ebay_profile_id = $get_ebay_category_id_data[ 'ced_ebay_profile_id_' . $user_id ][0];
				global $wpdb;
				$profile_data           = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}ced_ebay_profiles WHERE `id`=%d AND `user_id`=%s", $ebay_profile_id, $user_id ), 'ARRAY_A' );
				$profile_category_data  = json_decode( $profile_data[0]['profile_data'], true );
				$profile_category_data  = isset( $profile_category_data ) ? $profile_category_data : '';
				$get_ebay_category_id[] = isset( $profile_category_data['_umb_ebay_category']['default'] ) ? $profile_category_data['_umb_ebay_category']['default'] : '';
			}
			if ( ! empty( $get_ebay_category_id ) ) {
				foreach ( $get_ebay_category_id as $key => $ebay_id ) {
					$get_ebay_profile_assigned = get_option( 'ced_woo_ebay_mapped_categories_name' );
					$get_ebay_profile_assigned = isset( $get_ebay_profile_assigned[ isset( $_GET['user_id'] ) ? sanitize_text_field( $_GET['user_id'] ) : '' ][ $ebay_id ] ) ? $get_ebay_profile_assigned[ isset( $_GET['user_id'] ) ? sanitize_text_field( $_GET['user_id'] ) : '' ][ $ebay_id ] : '';
				}

				if ( isset( $get_ebay_profile_assigned ) && ! empty( $get_ebay_profile_assigned ) ) {
					$profile_id            = isset( $get_ebay_category_id_data[ 'ced_ebay_profile_id_' . $user_id ] ) ? $get_ebay_category_id_data[ 'ced_ebay_profile_id_' . $user_id ] : '';
					$profile_id            = isset( $profile_id[0] ) ? $profile_id[0] : 0;
					$assigned_profile_html = sprintf( '<a target="_blank" data-profile-id="%s" data-ebay-cat-id="%s" href="?page=%s&section=%s&user_id=%s&profileID=%s&eBayCatID=%s&panel=edit">%s</a>', $profile_id, $get_ebay_category_id[0], esc_attr( isset( $_REQUEST['page'] ) ? sanitize_text_field( $_REQUEST['page'] ) : '' ), 'profiles-view', esc_attr( isset( $_GET['user_id'] ) ? sanitize_text_field( $_GET['user_id'] ) : '' ), $profile_id, ! empty( $get_ebay_category_id[0] ) ? $get_ebay_category_id[0] : 0, $get_ebay_profile_assigned );
					print_r( $assigned_profile_html );
				}
			} else {
				echo '<b class="not_completed">' . esc_attr( 'No Profile Assigned', 'ebay-integration-for-woocommerce' ) . '</b>';
			}
		}
		echo '</div></div>';
	}
	/**
	 *
	 * Function for stock column
	 */
	public function column_stock( $item ) {
		echo '<div class="admin-custom-action-button-outer"><div class="admin-custom-action-show-button-outer">';

		if ( 'instock' == $item['stock_status'] ) {
			if ( 0 == $item['stock'] || '0' == $item['stock'] ) {
				return '<b class="stock_alert_instock" >' . esc_attr( 'In Stock', 'ebay-integration-for-woocommerce' ) . '</b>';
			} else {
				return '<b class="stock_alert_instock">In Stock(' . $item['stock'] . ')</b>';
			}
		} else {
			return '<b class="stock_alert_outofstock" >' . esc_attr( 'Out of Stock', 'ebay-integration-for-woocommerce' ) . '</b>';
		}

		echo '</div></div>';

	}
	/**
	 *
	 * Function for category column
	 */
	public function column_category( $item ) {
		echo '<div class="admin-custom-action-button-outer"><div class="admin-custom-action-show-button-outer">';

		if ( isset( $item['category'] ) ) {
			$allCategories = '';
			foreach ( $item['category'] as $key => $prodCat ) {
				$allCategories .= '<b>-->' . $prodCat . '</b><br>';
			}
			return $allCategories;
		}

		echo '</div></div>';

	}
	/**
	 *
	 * Function for price column
	 */
	public function column_price( $item ) {
		echo '<div class="admin-custom-action-button-outer"><div class="admin-custom-action-show-button-outer">';
		$currencySymbol = get_woocommerce_currency_symbol();
		return $currencySymbol . '&nbsp<b class="success_upload_on_ebay">' . $item['price'] . '</b>';
		echo '</div></div>';
	}
	/**
	 *
	 * Function for product type column
	 */
	public function column_type( $item ) {
		echo '<div class="admin-custom-action-button-outer"><div class="admin-custom-action-show-button-outer">';

		$product      = wc_get_product( $item['id'] );
		$product_type = $product->get_type();
		return '<b>' . $product_type . '</b>';
		echo '</div></div>';
	}
	/**
	 *
	 * Function for sku column
	 */
	public function column_sku( $item ) {
		echo '<div class="admin-custom-action-button-outer"><div class="admin-custom-action-show-button-outer">';
		return '<b>' . $item['sku'] . '</b>';
		echo '</div></div>';
	}
	/**
	 *
	 * Function for image column
	 */
	public function column_image( $item ) {
		echo '<div class="admin-custom-action-button-outer"><div class="admin-custom-action-show-button-outer">';
		return '<img height="50" width="50" src="' . $item['image'] . '">';
		echo '</div></div>';
	}

	public function column_woo_id( $item ) {
		echo '<div class="admin-custom-action-button-outer"><div class="admin-custom-action-show-button-outer">';
		return '<b class="success_upload_on_ebay">#' . $item['id'] . '</b>';
		echo '</div></div>';
	}
	/**
	 *
	 * Function for status column
	 */
	public function column_status( $item ) {
		$actions    = array();
		$user_id    = isset( $_GET['user_id'] ) ? sanitize_text_field( $_GET['user_id'] ) : '';
		$listing_id = get_post_meta( $item['id'], '_ced_ebay_listing_id_' . $user_id, true );
		if ( ! empty( get_post_meta( $item['id'], 'ced_ebay_alt_prod_description_' . $item['id'] . '_' . $user_id, true ) ) || ! empty( get_post_meta( $item['id'], 'ced_ebay_alt_prod_title_' . $item['id'] . '_' . $user_id, true ) ) ) {
			echo '<button class="px-3 py-1 mr-3 text-white font-semibold bg-blue-500 rounded">Modified</button><br>';

		}
		if ( ! empty( get_post_meta( $item['id'], '_ced_ebay_relist_item_id_' . $user_id, true ) ) ) {
			echo '<button class="px-3 py-1 mr-3 text-white font-semibold bg-blue-500 rounded">Re-Listed</button><br>';
		}
		if ( isset( $listing_id ) && ! empty( $listing_id ) ) {
			$user_id = isset( $_GET['user_id'] ) ? sanitize_text_field( $_GET['user_id'] ) : '';
			if ( ! empty( get_option( 'ced_ebay_listing_url_tld_' . $user_id ) ) ) {
				$listing_url_tld     = get_option( 'ced_ebay_listing_url_tld_' . $user_id, true );
				$view_url_production = 'https://www.ebay' . $listing_url_tld . '/itm/' . $listing_id;
				$view_url_sandbox    = 'https://sandbox.ebay' . $listing_url_tld . '/itm/' . $listing_id;
			} else {
				$view_url_production = 'https://www.ebay.com/itm/' . $listing_id;
				$view_url_sandbox    = 'https://sandbox.ebay.com/itm/' . $listing_id;

			}
			$mode_of_operation = get_option( 'ced_ebay_mode_of_operation', '' );
			if ( 'sandbox' == $mode_of_operation ) {
				echo '<div class="admin-custom-action-button-outer">';
				echo '<div class="admin-custom-action-show-button-outer">';
				echo '<a target="_blank" href="' . esc_attr( $view_url_sandbox ) . '" type="button" style="background:#5850ec !important;" class="button btn-normal-tt"><span>View on eBay</span></a>';
				echo '</div></div>';
			} elseif ( 'production' == $mode_of_operation ) {
				echo '<div class="admin-custom-action-button-outer">';
				echo '<div class="admin-custom-action-show-button-outer">';
				echo '<a target="_blank" href="' . esc_attr( $view_url_production ) . '" type="button" style="background:#5850ec !important;" class="button btn-normal-tt"><span>View on eBay</span></a>';
				echo '</div></div>';            } else {
				echo '<div class="admin-custom-action-button-outer">';
				echo '<div class="admin-custom-action-show-button-outer">';
				echo '<a target="_blank" href="' . esc_attr( $view_url_production ) . '" type="button" style="background:#5850ec !important;" class="button btn-normal-tt"><span>View on eBay</span></a>';
				echo '</div></div>';            }
		} else {
			echo '<div class="admin-custom-action-button-outer">';
			echo '<div class="admin-custom-action-show-button-outer">';
			echo '<button type="button" class="button btn-normal-tt"><span>Not Uploaded</span></button>';
			echo '</div></div>';
		}
		return $this->row_actions( $actions );

	}

	/**
	 *  Associative array of columns
	 *
	 * @return array
	 */

	public function get_columns() {
		$columns = array(
			'cb'       => '<input type="checkbox" />',
			'woo_id'   => __( 'Woo ID', 'ebay-integration-for-woocommerce' ),
			'image'    => __( 'Image', 'ebay-integration-for-woocommerce' ),
			'name'     => __( 'Name', 'ebay-integration-for-woocommerce' ),
			'type'     => __( 'Type', 'ebay-integration-for-woocommerce' ),
			'price'    => __( 'Price', 'ebay-integration-for-woocommerce' ),
			'profile'  => __( 'Profile Assigned', 'ebay-integration-for-woocommerce' ),
			'sku'      => __( 'SKU', 'ebay-integration-for-woocommerce' ),
			'stock'    => __( 'Stock', 'ebay-integration-for-woocommerce' ),
			'category' => __( 'Woo Category', 'ebay-integration-for-woocommerce' ),
			'status'   => __( 'Status', 'ebay-integration-for-woocommerce' ),
		);
		return $columns;
	}

	/**
	 *
	 * Function to count number of responses in result
	 */
	public function get_count( $per_page, $page_number ) {
		$args    = $this->GetFilteredData( $per_page, $page_number );
		$user_id = isset( $_GET['user_id'] ) ? sanitize_text_field( $_GET['user_id'] ) : '';
		if ( ! empty( $args['profileID'] ) ) {
			$profile_filter_count = get_option( 'ced_ebay_profile_filter_count_' . $user_id, true );
			return $profile_filter_count;
		} elseif ( ( ! empty( $args ) && isset( $args['tax_query'] ) || isset( $args['meta_query'] ) || isset( $args['s'] ) ) ) {
			$args = $args;
		} else {
			$args = array( 'post_type' => 'product' );
		}

		$loop         = new WP_Query( $args );
		$product_data = $loop->posts;
		$product_data = $loop->found_posts;

		return $product_data;
	}

	public function GetFilteredData( $per_page, $page_number ) {
		$args    = array();
		$user_id = isset( $_GET['user_id'] ) ? sanitize_text_field( $_GET['user_id'] ) : '';
		if ( ! empty( $_REQUEST['searchType'] ) && ! empty( $_REQUEST['searchQuery'] ) && ! empty( $_REQUEST['searchCriteria'] ) ) {
			$search_criteria = isset( $_GET['searchCriteria'] ) ? sanitize_text_field( $_GET['searchCriteria'] ) : '';
			$search_type     = isset( $_GET['searchType'] ) ? sanitize_text_field( $_GET['searchType'] ) : '';
			$search_query    = isset( $_GET['searchQuery'] ) ? sanitize_text_field( $_GET['searchQuery'] ) : '';
			if ( 'productId' == $search_type ) {
				$args['prodID'] = $search_query;
			}
			if ( 'product_name' == $search_criteria && 'productCustomSearch' == $search_type ) {
				$args['s'] = $search_query;
			}
			if ( 'product_sku' == $search_criteria && 'productCustomSearch' == $search_type ) {
				$args['search_by_sku'] = $search_query;
			}
		}
		if ( ( isset( $_GET['status_sorting'] )
		|| isset( $_GET['pro_cat_sorting'] )
		|| isset( $_GET['pro_type_sorting'] )
		|| isset( $_GET['searchBy'] )
		|| isset( $_GET['prodID'] )
		|| isset( $_GET['profileID'] ) )
		&& empty( $_REQUEST['searchType'] ) ) {
			if ( isset( $_REQUEST['pro_cat_sorting'] ) && ! empty( $_REQUEST['pro_cat_sorting'] ) ) {
				$pro_cat_sorting = isset( $_GET['pro_cat_sorting'] ) ? sanitize_text_field( $_GET['pro_cat_sorting'] ) : '';
				if ( '' != $pro_cat_sorting ) {
					$selected_cat          = array( $pro_cat_sorting );
					$tax_query             = array();
					$tax_queries           = array();
					$tax_query['taxonomy'] = 'product_cat';
					$tax_query['field']    = 'id';
					$tax_query['terms']    = $selected_cat;
					$args['tax_query'][]   = $tax_query;
				}
			}

			if ( isset( $_REQUEST['pro_type_sorting'] ) && ! empty( $_REQUEST['pro_type_sorting'] ) ) {
				$pro_type_sorting = isset( $_GET['pro_type_sorting'] ) ? sanitize_text_field( $_GET['pro_type_sorting'] ) : '';
				if ( '' != $pro_type_sorting ) {
					$selected_type         = array( $pro_type_sorting );
					$tax_query             = array();
					$tax_queries           = array();
					$tax_query['taxonomy'] = 'product_type';
					$tax_query['field']    = 'id';
					$tax_query['terms']    = $selected_type;
					$args['tax_query'][]   = $tax_query;
				}
			}

			if ( isset( $_REQUEST['status_sorting'] ) && ! empty( $_REQUEST['status_sorting'] ) ) {
				$status_sorting      = isset( $_GET['status_sorting'] ) ? sanitize_text_field( $_GET['status_sorting'] ) : '';
				$filtered_profile_id = isset( $_GET['profileID'] ) ? sanitize_text_field( $_GET['profileID'] ) : '';
				if ( '' != $status_sorting ) {
					$meta_query = array();
					if ( 'Uploaded' == $status_sorting ) {

						$meta_query[] = array(
							'key'     => '_ced_ebay_listing_id_' . $user_id,
							'compare' => 'EXISTS',
						);
					} elseif ( 'NotUploaded' == $status_sorting ) {
						$meta_query[] = array(
							'key'     => '_ced_ebay_listing_id_' . $user_id,
							'compare' => 'NOT EXISTS',
						);
					}
					$args['meta_query'] = $meta_query;
				}
			}

			if ( isset( $_REQUEST['pro_stock_sorting'] ) && ! empty( $_REQUEST['pro_stock_sorting'] ) ) {
				$sort_by_stock = isset( $_GET['pro_stock_sorting'] ) ? sanitize_text_field( $_GET['pro_stock_sorting'] ) : '';
				if ( '' != $sort_by_stock ) {
					$meta_query = array();
					if ( 'instock' == $sort_by_stock ) {
						if ( 'Uploaded' == $_REQUEST['status_sorting'] ) {
							$args['meta_query'] = array(
								'relation' => 'AND',
								array(
									'key'     => '_ced_ebay_listing_id_' . $user_id,
									'compare' => 'EXISTS',
								),
								array(
									'key'     => '_stock_status',
									'value'   => 'instock',
									'compare' => '=',
								),

							);

						} elseif ( 'NotUploaded' == $_REQUEST['status_sorting'] ) {
							$args['meta_query'] = array(
								'relation' => 'AND',
								array(
									'key'     => '_ced_ebay_listing_id_' . $user_id,
									'compare' => 'NOT EXISTS',
								),
								array(
									'key'     => '_stock_status',
									'value'   => 'instock',
									'compare' => '=',
								),

							);

						} else {
							$args['meta_query'][] = array(
								'key'   => '_stock_status',
								'value' => 'instock',
							);
						}
					} elseif ( 'outofstock' == $sort_by_stock ) {
						if ( 'Uploaded' == $_REQUEST['status_sorting'] ) {
							$args['meta_query'] = array(
								'relation' => 'AND',
								array(
									'key'     => '_ced_ebay_listing_id_' . $user_id,
									'compare' => 'EXISTS',
								),
								array(
									'key'     => '_stock_status',
									'value'   => 'outofstock',
									'compare' => '=',
								),

							);

						} elseif ( 'NotUploaded' == $_REQUEST['status_sorting'] ) {
							$args['meta_query'] = array(
								'relation' => 'AND',
								array(
									'key'     => '_ced_ebay_listing_id_' . $user_id,
									'compare' => 'NOT EXISTS',
								),

								array(
									'key'     => '_stock_status',
									'value'   => 'outofstock',
									'compare' => '=',
								),

							);

						} else {
							$args['meta_query'][] = array(
								'key'   => '_stock_status',
								'value' => 'outofstock',
							);
						}
					}
				}
			}
			if ( ! empty( $_REQUEST['searchBy'] ) ) {
				$search_by = isset( $_GET['searchBy'] ) ? sanitize_text_field( wp_unslash( $_GET['searchBy'] ) ) : '';
				if ( ! empty( $search_by ) ) {
					$args['s'] = $search_by;
				}
			}

			if ( ! empty( $_REQUEST['prodID'] ) ) {
				$prodID = isset( $_GET['prodID'] ) ? sanitize_text_field( wp_unslash( $_GET['prodID'] ) ) : '';
				if ( ! empty( $prodID ) ) {
					$args['prodID'] = $prodID;
				}
			}
			if ( ! empty( $_REQUEST['profileID'] ) ) {
				$profileID = isset( $_GET['profileID'] ) ? sanitize_text_field( wp_unslash( $_GET['profileID'] ) ) : '';
				if ( ! empty( $profileID ) ) {
					$args['profileID'] = $profileID;
				}
			}
		}

		$args['post_type']          = 'product';
			$args['posts_per_page'] = $per_page;
			$args['paged']          = $page_number;

			return $args;

	}
	/**
	 *
	 * Render bulk actions
	 */

	protected function bulk_actions( $which = '' ) {
		if ( 'top' == $which ) :
			if ( is_null( $this->_actions ) ) {
				$this->_actions = $this->get_bulk_actions();
				/**
				 * Filters the list table Bulk Actions drop-down.
				 *
				 * The dynamic portion of the hook name, `$this->screen->id`, refers
				 * to the ID of the current screen, usually a string.
				 *
				 * This filter can currently only be used to remove bulk actions.
				 *
				 * @since 3.5.0
				 *
				 * @param array $actions An array of the available bulk actions.
				 */
				$this->_actions = apply_filters( "bulk_actions-{$this->screen->id}", $this->_actions );
				$two            = '';
			} else {
				$two = '2';
			}

			if ( empty( $this->_actions ) ) {
				return;
			}

			echo '<label for="bulk-action-selector-' . esc_attr( $which ) . '" class="screen-reader-text">' . esc_attr( 'Select bulk action' ) . '</label>';
			echo '<select name="action' . esc_attr( $two ) . '" class="ced_ebay_select_ebay_product_action">';
			echo '<option value="-1">' . esc_attr( 'Bulk Actions' ) . "</option>\n";

			foreach ( $this->_actions as $name => $title ) {
				$class = 'edit' === $name ? ' class="hide-if-no-js"' : '';

				echo "\t" . '<option value="' . esc_attr( $name ) . '"' . esc_attr( $class ) . '>' . esc_attr( $title ) . "</option>\n";
			}

			echo "</select>\n";

			submit_button( __( 'Apply' ), 'action', '', false, array( 'id' => 'ced_ebay_bulk_operation' ) );
			echo "\n";
		endif;
	}

	/**
	 * Returns an associative array containing the bulk action
	 *
	 * @return array
	 */
	public function get_bulk_actions() {
		$actions = array(
			'upload_product' => __( 'Upload', 'ebay-integration-for-woocommerce' ),
			'relist_product' => __( 'Relist', 'ebay-integration-for-woocommerce' ),
			'update_product' => __( 'Update Product', 'ebay-integration-for-woocommerce' ),
			'update_stock'   => __( 'Update Inventory', 'ebay-integration-for-woocommerce' ),
			'remove_product' => __( 'End/Reset Product', 'ebay-integration-for-woocommerce' ),

		);
		return $actions;
	}
	/**
	 *
	 * Function for rendering html
	 */
	public function renderHTML() {
		$user_id = isset( $_GET['user_id'] ) ? sanitize_text_field( $_GET['user_id'] ) : '';
		?>
		<div class="justify-center my-8 select-none flex">

</div>

		<div class="ced-ebay-v2-header">
			<div class="ced-ebay-v2-logo">
			<img src="<?php echo esc_attr( CED_EBAY_URL ) . 'admin/images/icon-100X100.png'; ?>">
			</div>
			<div class="ced-ebay-v2-header-content">
				<div class="ced-ebay-v2-title">
					<h1>Products Management</h1>
				</div>

			<div class="ced-ebay-v2-actions">

<div class="admin-custom-action-button-outer">

<div class="admin-custom-action-show-button-outer">
		<?php
		if ( function_exists( 'as_get_scheduled_actions' ) ) {
			$scheduled_recurring_upload    = false;
			$scheduled_bulk_upload_actions = as_get_scheduled_actions(
				array(
					'group'  => 'ced_ebay_bulk_upload_' . $user_id,
					'status' => ActionScheduler_Store::STATUS_PENDING,
				),
				'ARRAY_A'
			);

			if ( function_exists( 'as_has_scheduled_action' ) ) {
				if ( as_has_scheduled_action( 'ced_ebay_recurring_bulk_upload_' . $user_id ) ) {
					$scheduled_recurring_upload = true;
				}
			}
		}
		if ( ! empty( $scheduled_bulk_upload_actions || $scheduled_recurring_upload ) ) {
			?>
<button style="background:red;" data-action="turn_off" style="margin-left:5px;" id="ced_ebay_toggle_bulk_upload_btn" type="button" class="button btn-normal-tt">
<span>Bulk Upload In Progress. Click To Turn Off!</span>
</button>
			<?php
		} else {
			?>
<button  style="margin-left:5px;" data-action="turn_on" id="ced_ebay_toggle_bulk_upload_btn" type="button" class="button btn-normal-sbc">
<span>Turn On Bulk Products Upload</span>
</button>
			<?php
		}
		?>
</div>



<div class="admin-custom-action-show-button-outer">
		<?php
		if ( function_exists( 'as_has_scheduled_action' ) ) {

			if ( as_has_scheduled_action( 'ced_ebay_inventory_scheduler_job_' . $user_id ) ) {
				?>
<button  data-action="turn_off" type="button" id="ced_ebay_toggle_bulk_inventory_btn" style="background:#c62019 !important;" class="button btn-normal-tt">
<span>Turn Off Inventory Sync</span>
</button>
				<?php
			} else {
				?>
<button  data-action="turn_on" type="button" id="ced_ebay_toggle_bulk_inventory_btn" class="button btn-normal-sbc">
<span>Turn On Inventory Sync</span>
</button>
				<?php
			}
		}
		?>

</div>
<div class="admin-custom-action-show-button-outer">
<button style="background:#5850ec !important;"  type="button" class="button btn-normal-tt">
<span><a style="all:unset;" href="https://docs.woocommerce.com/document/ebay-integration-for-woocommerce/#section-11" target="_blank">
Documentation					</a></span>
</button>

</div>

</div>
</div>
		</div>
</div>

<section class="woocommerce-inbox-message plain">
			<div class="woocommerce-inbox-message__wrapper">
				<div class="woocommerce-inbox-message__content">
					<h2 class="woocommerce-inbox-message__title">Free Onboarding Sessions</h2>
					<div class="woocommerce-inbox-message__text">
					<h4>For a limited time, you can connect directly with our eBay selling experts by scheduling an onboarding session through Calendly. 
						Our experts will help you navigate the plugin and setup your eBay and WooCommerce store for the holiday season.</h4>
						<h4>You can always live chat with the plugin developers in case of any issues by clicking on the chat icon in the bottom right.</h4>
						<div class="admin-custom-action-show-button-outer">

						<div class="admin-custom-action-show-button-outer">
<button style="background:#5850ec !important;"  type="button" class="button btn-normal-tt">
<span><a style="all:unset;" href="" onclick="Calendly.initPopupWidget({url: 'https://calendly.com/ali_cedcommerce/meeting-with-ebay-integration-team'});return false;">Book a Free Onboarding Session</a>
</span>
</button>
	</div>
</div>
					
					</div>
				</div>
				
			</div>

		</section>
		<div class="ced-ebay-products-view-notice success-admin-notices is-dismissible"></div>

		<div id="post-body" class="metabox-holder columns-2">
			<div id="post-body-content">
				<div class="meta-box-sortables ui-sortable">
					<?php
					$status_actions = array(
						'Uploaded'    => __( 'Uploaded', 'ebay-integration-for-woocommerce' ),
						'NotUploaded' => __( 'Not Uploaded', 'ebay-integration-for-woocommerce' ),
					);

					$product_types = get_terms( 'product_type', array( 'hide_empty' => false ) );
					$temp_array    = array();
					foreach ( $product_types as $key => $value ) {
						if ( 'simple' == $value->name || 'variable' == $value->name ) {
							$temp_array_type[ $value->term_id ] = ucfirst( $value->name );
						}
					}
					$product_types      = $temp_array_type;
					$product_categories = $this->ced_ebay_get_taxonomy_hierarchy( 'product_cat', 0, 0 );
					$temp_array         = array();
					// foreach ( $product_categories as $key => $value ) {
					// $temp_array[ $value->term_id ] = $value->name;
					// }
					// $product_categories = $temp_array;
					$profiles_array = array();
					global $wpdb;
					$tableName         = $wpdb->prefix . 'ced_ebay_profiles';
					$assigned_profiles = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}ced_ebay_profiles WHERE `user_id`=%s", $user_id ), 'ARRAY_A' );
					foreach ( $assigned_profiles as $key => $ced_profiles ) {
						$profiles_array[ $ced_profiles['id'] ] = $ced_profiles['profile_name'];
					}
					$assigned_profiles              = $profiles_array;
					$previous_selected_status       = isset( $_GET['status_sorting'] ) ? sanitize_text_field( $_GET['status_sorting'] ) : '';
					$previous_selected_cat          = isset( $_GET['pro_cat_sorting'] ) ? sanitize_text_field( $_GET['pro_cat_sorting'] ) : '';
					$previous_selected_type         = isset( $_GET['pro_type_sorting'] ) ? sanitize_text_field( $_GET['pro_type_sorting'] ) : '';
					$previous_selected_stock_status = isset( $_GET['pro_stock_sorting'] ) ? sanitize_text_field( $_GET['pro_stock_sorting'] ) : '';
					echo '<div class="ced_ebay_wrap">';
					echo '<form method="post" action="">';
					echo '<div class="ced_ebay_top_wrapper">';
					echo '<select name="status_sorting" class="select_boxes_product_page">';
					echo '<option value="">' . esc_attr( 'Product Status', 'ebay-integration-for-woocommerce' ) . '</option>';
					foreach ( $status_actions as $name => $title ) {
						$selectedStatus = ( $previous_selected_status == $name ) ? 'selected="selected"' : '';
						$class          = 'edit' === $name ? ' class="hide-if-no-js"' : '';
						echo '<option ' . esc_attr( $selectedStatus ) . ' value="' . esc_attr( $name ) . '"' . esc_attr( $class ) . '>' . esc_attr( $title ) . '</option>';
					}

					echo '</select>';
					$previous_selected_cat = isset( $_GET['pro_cat_sorting'] ) ? sanitize_text_field( $_GET['pro_cat_sorting'] ) : '';

					echo '<select name="pro_type_sorting" class="select_boxes_product_page">';
					echo '<option value="">' . esc_attr( 'Product Type', 'ebay-integration-for-woocommerce' ) . '</option>';
					foreach ( $product_types as $name => $title ) {
						$selectedType = ( $previous_selected_type == $name ) ? 'selected="selected"' : '';
						$class        = 'edit' === $name ? ' class="hide-if-no-js"' : '';
						echo '<option ' . esc_attr( $selectedType ) . ' value="' . esc_attr( $name ) . '"' . esc_attr( $class ) . '>' . esc_attr( $title ) . '</option>';
					}
					echo '</select>';

					echo '<select name="pro_stock_sorting" class="select_boxes_product_page">';
					echo '<option value="">' . esc_attr( 'Stock Status', 'ebay-integration-for-woocommerce' ) . '</option>';
					echo '<option ' . esc_attr( ( 'instock' == $previous_selected_stock_status ) ? 'selected="selected"' : '' ) . ' value="instock">In Stock</option>';
					echo '<option ' . esc_attr( ( 'outofstock' == $previous_selected_stock_status ) ? 'selected="selected"' : '' ) . ' value="outofstock">Out Of Stock</option>';
					echo '</select>';

					$dropdown_cat_args = array(
						'name'            => 'pro_cat_sorting',
						'show_count'      => 1,
						'hierarchical'    => 1,
						'depth'           => 10,
						'taxonomy'        => 'product_cat',
						'class'           => 'ced_ebay_category_dropdown_product_page',
						'selected'        => $previous_selected_cat,
						'show_option_all' => 'Product Category',

					);
					if ( ! isset( $_GET['profileID'] ) ) {
						wp_dropdown_categories( $dropdown_cat_args );
					}
					wp_nonce_field( 'ced_ebay_product_filter_page_nonce', 'ced_ebay_product_filter_nonce' );
					submit_button( __( 'Filter', 'ebay-integration-for-woocommerce' ), 'action', 'filter_button', false, array() );
					?>


					<?php
					echo '</div>';
					echo '</form>';
					echo '</div>';

					?>

					<form method="post">

</div>
	</div>
						<?php
						$this->display();
						?>

					</form>



				</div>
			</div>
			<div class="clear"></div>
		</div>

		<div id="ced_ebay_pro_errors_modal" class="ced_ebay_pro_errors_modal">
  <div class="ced_ebay_pro_errors_modal-inner">
  </div>
</div>

		<div class="ced_ebay_preview_product_popup_main_wrapper"></div>
		<div id="form-modal-create-ad">
		<div class="modal">

			<input class="modal__tab-radio" type="radio" name="tabs" id="tab1" checked>
			<label class="modal__tab-label" for="tab1">Create Ad</label>


			<div class="modal__panel" id="tab1-content">
			<h4>Create Promotions for your eBay listing.</h4>
			<p>To create promotion, please select an Ad Campaign and enter Ad Rate. You can also use your global Ad Campaign and Ad Rate.</p>

			<label for="ad_campaign">Select Ad Campaign</label>
			<select name="ad_campaign" id="ced_ebay_select_ad_campaign" style="min-width:100%; box-sizing: border-box;margin-bottom: 1rem;">
			<option value=""><?php esc_attr_e( '--Select Campaign--', 'ebay-integration-for-woocommerce' ); ?></option>
			<?php

			if ( null != get_option( 'ced_ebay_ad_campaigns' ) && '' != get_option( 'ced_ebay_ad_campaigns' ) ) {
				$getCampaigns = get_option( 'ced_ebay_ad_campaigns' );
				$adCampaigns  = $getCampaigns[ $user_id ];
				foreach ( $adCampaigns->campaigns as $key => $value ) {
					?>
					<option value="<?php echo esc_attr( $value->campaignId ); ?>" data-campaign-id="<?php echo esc_attr( $value->campaignId ); ?>"><?php esc_attr_e( $value->campaignName ); ?></option>
					<?php
				}
			}
			?>
			</select>
			<label for="ced_ebay_create_ad_rate" style="float:left;">Enter Ad Rate (Bid Percentage)</label><br>
			<input class="text-input" type="number" id="ced_ebay_create_ad_rate"><br>
			<li>
			<label  style="word-wrap:break-word">
			<input id="ced_ebay_use_global_ad_campaign"  type="checkbox" />Check this to use saved global ad campaign
			 </label>
			</li>
			<li>
			<label  style="word-wrap:break-word">
			<input id="ced_ebay_use_global_ad_rate"  type="checkbox" />Check this to use saved global ad rate
			</li>

		  <br>

			<input class="button form-submit" type="button" value="Create Ad" id="ced_ebay_create_listing_promotion">

			</div>


		</div>
	</div>

	<div id="form-modal-update-ad">
		<div class="modal">


			<input class="modal__tab-radio" type="radio" name="tabs" id="tab2">
			<label class="modal__tab-label" for="tab2">Update Ad</label>


			<div class="modal__panel" id="tab2-content">
			<h4>Update Ad Rate for Promoted Listings</h4>
			<p>To update the ad rate for an existing promotion, please enter the ad rate below.</p><br>
	<input class="text-input" type="number" id="ced_ebay_updated_ad_rate"><br>

	<input class="button form-submit" type="button" value="Update Ad Rate" id="ced_ebay_update_listing_promotion_ad_rate">

			</div>
		</div>
	</div>

	<div class="ced-ebay-bulk-create-ads-modal-wrapper">
  <div class="ced-ebay-bulk-create-ads-modal">
	<div class="ced-ebay-bulk-create-ads-head">
	  <a class="ced-ebay-bulk-create-ads-btn-close ced-ebay-bulk-create-ads-trigger" href="javascript:;"></a>
	</div>
	<div class="ced-ebay-bulk-create-ads-content">
	<h4>Create Promotions for your eBay listing.</h4>
			<p>To create promotion, please select an Ad Campaign and enter Ad Rate. You can also use your global Ad Campaign and Ad Rate.</p>
			<div class="showBulkCreateAdErrors" style="color:red; text-align:center;"></div>
			<label for="ced_ebay_select_ad_campaign_for_bulk_create_ad_rate">Select Ad Campaign</label>
			<select name="ced_ebay_select_ad_campaign_for_bulk_create_ad_rate" id="ced_ebay_select_ad_campaign_for_bulk_create_ad_rate" style="min-width:100%; box-sizing: border-box;margin-bottom: 1rem;">
			<option value=""><?php esc_attr_e( '--Select Campaign--', 'ebay-integration-for-woocommerce' ); ?></option>
			<?php

			if ( null != get_option( 'ced_ebay_ad_campaigns' ) && '' != get_option( 'ced_ebay_ad_campaigns' ) ) {
				$getCampaigns = get_option( 'ced_ebay_ad_campaigns' );
				$adCampaigns  = $getCampaigns[ $user_id ];
				foreach ( $adCampaigns->campaigns as $key => $value ) {
					?>
					<option value="<?php echo esc_attr( $value->campaignId ); ?>" data-campaign-id="<?php echo esc_attr( $value->campaignId ); ?>"><?php esc_attr_e( $value->campaignName ); ?></option>
					<?php
				}
			}
			?>
			</select>
			<label for="ced_ebay_bulk_create_ad_rate" style="float:left;">Enter Ad Rate (Bid Percentage)</label><br>
			<input class="text-input" type="number" id="ced_ebay_bulk_create_ad_rate"><br>

		  <br>
			<input class="button form-submit" type="button" value="Create Ad" id="ced_ebay_bulk_create_ad_rate_button">
	</div>
  </div>

</div>

		<?php
	}

	public function extra_tablenav( $which ) {
		$user_id = isset( $_GET['user_id'] ) ? sanitize_text_field( $_GET['user_id'] ) : '';
		if ( 'top' == $which ) {
			ob_start();
			?>

	  <div class="alignleft actions bulkactions" style="padding-right:0px !important;">

		  <select name="product-filter" class="ced-ebay-filter-products" style="min-width:210px;">
		  </select>


	  </div>
	  <div class="alignleft actions bulkactions">

<select name="product-filter-criteria" class="ced-ebay-filter-products-criteria">
<option value="product_name">Name</option>
<option value="product_sku">SKU</option>
<option value="ebay_listing_id">eBay Item ID</option>

</select>

<button type="submit" class="button btn-normal-tt" name="ced_ebay_filter_product_button" id="ced_ebay_filter_product_button">
<span> Search </span></button>
</div>


			<?php
			wp_nonce_field( 'ced_ebay_filter_product_action_nonce', 'ced_ebay_filter_product_nonce' );
			ob_flush();

			?>
			<div class="alignleft actions bulkactions">
			<div class="admin-custom-action-button-outer" style="margin: 0px !important;">
							<div class="admin-custom-action-show-button-outer">

							<input type="text" placeholder="No. of entries to view" name="ced_ebay_view_entries_prod_section_input" style="line-height:0;" value="<?php echo ! empty( get_option( 'ced_ebay_product_section_per_page_' . $user_id ) ) ? esc_attr( get_option( 'ced_ebay_product_section_per_page_' . $user_id, true ) ) : ''; ?>">
		</div>
			<div class="admin-custom-action-show-button-outer" style="line-height:2 !important; min-height:30px !important;">
				<button style="background:#135e96 !important;vertical-align:bottom;" type="submit" class="button btn-normal-tt" name="ced_ebay_view_entries_bulk_upload">
<span>Save</span>
</button>
			<?php wp_nonce_field( 'ced_ebay_view_entries_product_section_nonce', 'ced_ebay_view_entries_product_section' ); ?>
	</div>

		</div>

			</div>
			<?php
		}
	}

	public function column_listing_ad_rate( $item ) {
		$dataInGlobalSettings = get_option( 'ced_ebay_global_settings', false );

		$user_id = isset( $_GET['user_id'] ) ? sanitize_text_field( $_GET['user_id'] ) : '';

		$listing_id = get_post_meta( $item['id'], '_ced_ebay_listing_id_' . $user_id, true );
		if ( isset( $listing_id ) && ! empty( $listing_id ) ) {
			$promoted_listing_data = get_post_meta( $item['id'], '_ced_ebay_promoted_listings_ad_data_' . $user_id, true );
			if ( empty( $promoted_listing_data['adId'] ) ) {
				echo '<div class="admin-custom-action-button-outer"><div class="admin-custom-action-show-button-outer">';
				echo '<input type="button"
				class="button button-primary create-ad-button"
				data-tab-id="tab1"
				data-product-id="' . esc_attr( $item['id'] ) . '"
				data-listing-id="' . esc_attr( $listing_id ) . '" value="Create Ad">';
				echo '</div></div>';
			} else {
				echo '<div class="admin-custom-action-button-outer"><div class="admin-custom-action-show-button-outer">';
				echo '<input type="button" class="button button-primary update-ad-button" data-tab-id="tab2" id="ced_ebay_update_listing_ad_rate" data-listing-ad-id= "' . esc_attr( $promoted_listing_data['adId'] ) . '" data-campaign-id="' . esc_attr( $promoted_listing_data['campaignId'] ) . '" data-listing-id="' . esc_attr( $listing_id ) . '"  value="Update Ad">';
				echo '<input type="button"
				id="ced_ebay_delete_campaign_ad_button"
				class="button button-primary create-ad-button"
				data-tab-id="tab1"
				data-listing-ad-id= "' . esc_attr( $promoted_listing_data['adId'] ) . '"
				data-campaign-id="' . esc_attr( $promoted_listing_data['campaignId'] ) . '"
				style="margin-top:10px;"
				value="Delete Ad">';
				echo '</div></div>';
			}
		} else {
			echo '<div class="admin-custom-action-button-outer"><div class="admin-custom-action-show-button-outer">';
			echo '<p style="color:red;">Please upload the product first.</p>';
			echo '</div></div>';
		}

	}

}

$ced_ebay_products_obj = new EBayListProducts();
$ced_ebay_products_obj->prepare_items();

?>


<style>

.wp-list-table .column-profile { width: 25%; }
.wp-list-table .column-name { width: 12% !important; }
.wp-list-table .column-price { width: 5% !important; }
.wp-list-table .column-type { width: 5% !important; }

.select2-container--open {
	z-index: 99999999999999 !important;
	}

/* .select2-container .select2-selection--single {
		height: 30px !important;
	} */
#form-modal-create-ad {
  display: flex;
  justify-content: center;
  position: fixed;
  background: rgba(0, 0, 0, 0.65);
  padding: calc(1rem * 3) 1rem 0;
  top: 0;
  right: 0;
  left: 0;
  height: 100vh;
}
#form-modal-update-ad {
  display: flex;
  justify-content: center;
  position: fixed;
  background: rgba(0, 0, 0, 0.65);
  padding: calc(1rem * 3) 1rem 0;
  top: 0;
  right: 0;
  left: 0;
  height: 100vh;
}
.modal {
  padding: 0;
  list-style: none;
  align-self: flex-start;
  max-width: 550px;
}
@media (min-width: 768px) {
  .modal {
	width: 70%;
  }
}
@media (min-width: 992px) {
  .modal {
	width: 40%;
  }
}
.modal .modal__tab-radio {
  display: none;
}
.modal__tab-label {
  width: 100%;
  box-sizing: border-box;
  display: block;
  float: left;
  text-align: center;
  padding: 1rem 1rem;
  cursor: pointer;
  transition: all 0.4s;
  background: #eaeaeb;
}
.modal__tab-label:hover {
  background-color: #d0d0d2;
}
.modal__panel {
  display: none;
  width: 100%;
  float: left;
  padding: 1rem calc(1rem * 2);
  box-sizing: border-box;
  background: #ffffff;
}
.modal__panel * {
  animation: scale 0.4s ease-in-out;
}
.modal [id^="tab"]:checked + label {
  background: #ffffff;
  cursor: default;
  color: #007c92;
}
.modal #tab1:checked ~ #tab1-content,
.modal #tab2:checked ~ #tab2-content {
  display: block;
}
@keyframes scale {
  0% {
	/* 		transform: scale(0.95); */
	opacity: 0;
  }
  50% {
	/* 		transform: scale(1.01); */
	opacity: 0.5;
  }
  100% {
	/* 		transform: scale(1); */
	opacity: 1;
  }
}
input.text-input {
  width: 100%;
  box-sizing: border-box;
  margin-bottom: 1rem;
}

input[type="checkbox"]
{
	vertical-align:middle;
}

.reset {
  float: right;
}
.form-submit {
  margin: 1rem auto;
  display: block;
  width: 100%;
  cursor: pointer;
}
.form-questions {
  text-align: center;
  max-width: 80%;
  margin: 0 auto;
}
.ced-ebay-bulk-create-ads-modal-wrapper{
  width:100%;
  height:100%;
  position:fixed;
  top:0; left:0;
  opacity:1;
  visibility:visible;
  opacity:1;
  -webkit-transition: all 0.25s ease-in-out;
  -moz-transition: all 0.25s ease-in-out;
  -o-transition: all 0.25s ease-in-out;
  transition: all 0.25s ease-in-out;
}


.ced-ebay-bulk-create-ads-modal{
  width:600px;
  height:400px;
  display:block;
  margin:50% 0 0 -300px;
  position:relative;
  top:50%; left:50%;
  background:#fff;
	margin-top:-200px;
	border: 1px solid #0073aa;
  opacity:1;
	-webkit-transition: all 0.5s ease-in-out;
  -moz-transition: all 0.5s ease-in-out;
  -o-transition: all 0.5s ease-in-out;
  transition: all 0.5s ease-in-out;
}

.ced-ebay-bulk-create-ads-modal-wrapper.open .ced-ebay-bulk-create-ads-modal{
  margin-top:-200px;
  opacity:1;
}

.ced-ebay-bulk-create-ads-head{
  width:100%;
  height:64px;
  padding:1.5em 5%;
  overflow:hidden;
  background:#0073aa;
}

.ced-ebay-bulk-create-ads-btn-close{
  width:32px;
  height:32px;
  display:block;
  float:right;
}

.ced-ebay-bulk-create-ads-btn-close::before, .ced-ebay-bulk-create-ads-btn-close::after{
  content:'';
  width:32px;
  height:6px;
  display:block;
  background:#fff;
}

.ced-ebay-bulk-create-ads-btn-close::before{
  margin-top:12px;
  -webkit-transform:rotate(45deg);
  -moz-transform:rotate(45deg);
  -o-transform:rotate(45deg);
  transform:rotate(45deg);
}

.ced-ebay-bulk-create-ads-btn-close::after{
  margin-top:-6px;
  -webkit-transform:rotate(-45deg);
  -moz-transform:rotate(-45deg);
  -o-transform:rotate(-45deg);
  transform:rotate(-45deg);
}

.ced-ebay-bulk-create-ads-content{
  padding:3%;
}
tbody tr:nth-child(odd) {
  background-color: #F0E68C;
}

tbody tr:nth-child(even) {
  background-color: #FAEBD7;
}

tbdoy tr {
  margin: 10px 0;
}

.ced_ebay_pro_errors_modal {
  background-color: rgba(0, 0, 0, 0.5);
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  overflow: auto;
  display: none;
  padding: 0 20px;
  z-index: 2;
}

.ced_ebay_pro_errors_modal-inner {
  background-color: #fff;
  border-radius: 3px;
  max-width: 500px;
  margin: 50px auto;
  padding: 20px;
}

.height {
	height: 100vh
}

.form {
	position: relative
}

.form .fa-search {
	position: absolute;
	top: 20px;
	left: 20px;
	color: #9ca3af
}

.form span {
	position: absolute;
	right: 17px;
	top: 13px;
	padding: 2px;
	border-left: 1px solid #d1d5db
}

.left-pan {
	padding-left: 7px
}

.left-pan i {
	padding-left: 10px
}

.form-input {
	height: 55px;
	text-indent: 33px;
	border-radius: 10px
}

.form-input:focus {
	box-shadow: none;
	border: none
}


/* Placed on the body while a modal is open to prevent scrolling. */
.showing-error-modal {
  overflow: hidden;
}

.ced-searchResult{
		list-style: none;
		width: 400px;
		background: white;
		border-radius: 2px;
		}

		.ced-searchResult ul{
		list-style: none;
		padding-left: 8px;
		padding-bottom: 14px;
		line-height: 30px;
		}


		.ced-searchResult li:hover{
		 cursor: default;
		}

		.ced-searchbox{
		 padding: 5px;
		 width: 400px;
		 letter-spacing: 1px;
		}
		.ced-h3{
			padding: 5px;
		}
		.ced-box{
		border-bottom: solid thin #eee;
		padding: -2px;
		padding-left: 5px;
		}
		.form-control-borderless {
	border: none;
}

.form-control-borderless:hover, .form-control-borderless:active, .form-control-borderless:focus {
	border: none;
	outline: none;
	box-shadow: none;
}

form-control {
	border-radius: 0;
	box-shadow: none;
	border-color: #d2d6de
}

.select2-hidden-accessible {
	border: 0 !important;
	clip: rect(0 0 0 0) !important;
	height: 1px !important;
	margin: -1px !important;
	overflow: hidden !important;
	padding: 0 !important;
	position: absolute !important;
	width: 1px !important
}

.ced_ebay_category_dropdown_product_page {
width:18%!important;
}

</style>
<script>
(function( $ ) {
	

  var $modalButtonCreateAd = $('.create-ad-button'),
	  $modalButtonUpdateAd = $('.update-ad-button'),
	  $formModalCreateAd = $('#form-modal-create-ad').hide(),
	  $formModalUpdateAd = $('#form-modal-update-ad').hide(),
	  $modal = $('.modal'),
	  $createAdButton = $('#ced_ebay_create_listing_promotion'),
	  $updateAdRateButton = $('#ced_ebay_update_listing_promotion_ad_rate');

	$('.ced-ebay-bulk-create-ads-modal-wrapper').hide();


  // Close modal when clicked outside
  $(document).mouseup(function(e) {
	  if (!$modal.is(e.target) && $modal.has(e.target).length === 0) {
		$('#form-modal-create-ad').find('input[type="number"]').val('');
		$('#form-modal-update-ad').find('input[type="number"]').val('');
		$('#ced_ebay_select_ad_campaign').prop('selectedIndex',0);
		$formModalUpdateAd.hide();
		  $formModalCreateAd.hide();
		$('html').css('overflow', 'auto');
	  }
  });

  $modalButtonCreateAd.click(function(){
	var product_id = jQuery(this).data('product-id');
	var ebay_listing_id = jQuery(this).data('listing-id');
	$createAdButton.data('product-id', product_id);
	$createAdButton.data('listing-id', ebay_listing_id);
	$radio = 'input:radio[id=' + $(this).attr('data-tab-id') + ']';
	$($radio).prop('checked',true);
	$formModalCreateAd.show();
	$('html').css('overflow', 'hidden');

  });

  $modalButtonUpdateAd.click(function(){
	var product_ad_id = jQuery(this).data('listing-ad-id');
	var campaign_id = jQuery(this).data('campaign-id');
	$updateAdRateButton.data('product-ad-id', product_ad_id);
	$updateAdRateButton.data('campaign-id', campaign_id);
	$radio = 'input:radio[id=' + $(this).attr('data-tab-id') + ']';
	$($radio).prop('checked',true);
	$formModalUpdateAd.show();
	$('html').css('overflow', 'hidden');

  });


  $('#ced_ebay_use_global_ad_rate').change(function(){


if ($('#ced_ebay_use_global_ad_rate').is(':checked') == true){
	$('#ced_ebay_create_listing_promotion').attr('data-use-global-ad-rate', 'true');
  $('#ced_ebay_create_ad_rate').prop('disabled', true);
} else {
	$('#ced_ebay_create_listing_promotion').attr('data-use-global-ad-rate', 'false');
 $('#ced_ebay_create_ad_rate').prop('disabled', false);
}

});

$('#ced_ebay_use_global_ad_campaign').change(function(){


if ($('#ced_ebay_use_global_ad_campaign').is(':checked') == true){
	$('#ced_ebay_create_listing_promotion').attr('data-use-global-ad-campaign', 'true');
  $('#ced_ebay_select_ad_campaign').prop('disabled', true);
} else {
	$('#ced_ebay_create_listing_promotion').attr('data-use-global-ad-campaign', 'false');
 $('#ced_ebay_select_ad_campaign').prop('disabled', false);
}

});


jQuery(".ced_ebay_category_dropdown_product_page").selectWoo(
		{
		dropdownPosition: 'below',
	  dropdownAutoWidth : true,
		}
	);
})(jQuery);



</script>

<script type="text/template" id="tmpl-wc-ced-ebay-bulk-update-modal">
		<div class="wc-backbone-modal wc-order-preview">
				<div class="wc-backbone-modal-content">
					<section class="wc-backbone-modal-main" role="main">
						<header class="wc-backbone-modal-header">
							<h1>Product Auto-Update</h1>
						<button class="modal-close modal-close-link dashicons dashicons-no-alt">
								<span class="screen-reader-text">Close modal panel</span>
							</button>
						</header>
											
		<div class="ced-ebay-bootstrap-wrapper">
		<div class="container mt-3 mb-3">
	

	<div class="row">
		<div class="col-md-12">
			
			<h5 style="color:#0073aa;">Select Properties To Auto-Update</h5>
			<p class="woocommerce-inbox-message__text mt-2 mb-0"><b> > Before you begin Auto-Update, make sure the WooCommerce products have a profile associated with them and synced with our plugin.</p>		
			<p class="woocommerce-inbox-message__text mt-0 mb-0"><b>> For faster updates to eBay, only select the properties that change frequently.</p>		
<p class="woocommerce-inbox-message__text mt-0 mb-0"><b>> Pricing and inventory can't be updated using Auto-Update. Use Inventory Sync instead.</p>		
<p class="woocommerce-inbox-message__text mt-0 mb-0"><b>> In some cases, adding new attributes and variations will not auto-update on eBay successfully. If this is the case, please contact support.</p>
<p class="woocommerce-inbox-message__text mt-0"><b>> You can check the progress of auto-update in the Feeds section</p>
<div id="ced_ebay_auto_update_selection_container">
		
<div class="form-check form-check-inline">
  <input class="form-check-input" style="width: 17px; height: 17px;" type="checkbox" id="ced_ebay_update_description_checkbox" value="ced_ebay_auto_update_description_option">
  <label class="form-check-label" for="ced_ebay_update_description_checkbox"><b>Product Description</b></label>
</div>
<div class="form-check form-check-inline">
  
<input class="form-check-input" style="width: 17px; height: 17px;" type="checkbox" id="ced_ebay_update_images_checkbox" value="ced_ebay_auto_update_images_option">
  <label class="form-check-label" for="ced_ebay_update_images_checkbox"><b>Product Images</b></label>
</div>
<div class="form-check form-check-inline">
  
<input class="form-check-input" style="width: 17px; height: 17px;" type="checkbox" id="ced_ebay_update_title_checkbox" value="ced_ebay_auto_update_title_option">
  <label class="form-check-label" for="ced_ebay_update_title_checkbox"><b>Product Title</b></label>
</div>
<div class="form-check form-check-inline">
  
<input class="form-check-input" style="width: 17px; height: 17px;" type="checkbox" id="ced_ebay_update_variations_checkbox" value="ced_ebay_auto_update_variations_option">
  <label class="form-check-label" for="ced_ebay_update_variations_checkbox"><b>Product Variations</b></label>
</div>
<div class="form-check form-check-inline">
  
<input class="form-check-input" style="width: 17px; height: 17px;" type="checkbox" id="ced_ebay_update_shipping_checkbox" value="ced_ebay_auto_update_shipping_option">
  <label class="form-check-label" for="ced_ebay_update_shipping_checkbox"><b>Shipping Details for Products</b></label>
</div>
</div>
</div> <!-- /.col -->
	</div>
	
	</div>
	
</div>



						<footer>
							<div class="inner">

								<a class="button button-primary button-large" id="ced_ebay_begin_auto_update_button">Begin Update</a>
							</div>
						</footer>
					</section>
				</div>
			</div>
			<div class="wc-backbone-modal-backdrop modal-close"></div>
						</script>

