<?php
// If this file is called directly, abort.
if ( ! defined( 'ABSPATH' ) ) {
	die;
}
if ( empty( get_option( 'ced_ebay_user_access_token' ) ) ) {
	wp_redirect( get_admin_url() . 'admin.php?page=ced_ebay' );
}
$file = CED_EBAY_DIRPATH . 'admin/partials/header.php';
if ( file_exists( $file ) ) {
	require_once $file;
}

$shop_data = isset( $shopDetails ) ? $shopDetails : array();
$site_id   = isset( $shop_data['site_id'] ) ? $shop_data['site_id'] : false;
$user_id   = isset( $_GET['user_id'] ) ? sanitize_text_field( $_GET['user_id'] ) : '';
$part      = isset( $_GET['part'] ) ? sanitize_text_field( $_GET['part'] ) : '';
?>


<div class="ced-ebay-v2-header">
			<div class="ced-ebay-v2-logo">
			<img src="<?php echo esc_attr( CED_EBAY_URL ) . 'admin/images/icon-100X100.png'; ?>">
			</div>
			<div class="ced-ebay-v2-header-content">
				<div class="ced-ebay-v2-title">
					<h1>Account Settings</h1>
				</div>
				<div class="ced-ebay-v2-actions">
				<a class="ced-ebay-v2-btn" href="https://docs.woocommerce.com/document/ebay-integration-for-woocommerce/#section-5" target="_blank">
					Documentation					</a>

			</div>
		</div>
</div>
<section class="woocommerce-inbox-message plain">
			<div class="woocommerce-inbox-message__wrapper">
				<div class="woocommerce-inbox-message__content">
					<h2 class="woocommerce-inbox-message__title">Important Notice!</h2>
					<div class="woocommerce-inbox-message__text">
					<h4>We will soon discontinue support for specifying custom Payment, Return, and Shipping options in this section.
						Sellers who use the custom options for Payment, Return and Shipping will not be affected moving forward.
New and existing sellers will be able to choose their existing eBay Payment, Return, and Shipping business policies from the General Settings section and use 
those when listing the WooCommerce products on eBay.
					</h4>
					</div>
				</div>
			</div>

		</section>
		<?php
		$payment_select              = '';
		$shipping_select             = '';
		$return_select               = '';
		$description_template_select = '';
		if ( 'shipping' == $part || '' == $part ) {
			$shipping_select = 'active';
		} elseif ( 'return' == $part ) {
			$return_select = 'active';
		} elseif ( 'description_template' == $part ) {
			$description_template_select = 'active';
		}
		?>

		<div class="ced_ebay_flex_wrapper">
			<div class="ced_ebay_account_settings_header">
				<ul>
					<li class="<?php echo esc_attr_e( $shipping_select ); ?>">
						<a href="<?php echo esc_url( admin_url( 'admin.php?page=ced_ebay&section=accounts-view&part=shipping&user_id=' . $user_id . '&site_id=' . $site_id . '&ver=' . $this->version ) ); ?>" id="shipping_details" class="ced-ebay-v2-btn"><?php esc_html_e( 'Shipping Settings', 'ebay-integration-for-woocommerce' ); ?></a>
					</li>
					<li class="<?php echo esc_attr_e( $return_select ); ?>">
						<a href="<?php echo esc_url( admin_url( 'admin.php?page=ced_ebay&section=accounts-view&part=return&user_id=' . $user_id . '&site_id=' . $site_id . '&ver=' . $this->version ) ); ?>" id="return_details" class="ced-ebay-v2-btn"><?php esc_html_e( 'Return Settings', 'ebay-integration-for-woocommerce' ); ?></a>
					</li>
					<li class="<?php echo esc_attr_e( $description_template_select ); ?>">
						<a href="<?php echo esc_url( admin_url( 'admin.php?page=ced_ebay&section=accounts-view&part=description_template&user_id=' . $user_id . '&site_id=' . $site_id . '&ver=' . $this->version ) ); ?>" id="description_template_details" class="ced-ebay-v2-btn"><?php esc_html_e( 'Description Template', 'ebay-integration-for-woocommerce' ); ?></a>
					</li>
				</ul>
			</div>
			<div class="ced_ebay_account_settings_fields">
				<?php
				if ( 'shipping' == $part || '' == $part ) {
					?>
					<div class="ced_ebay_shipping_details_wrapper">
						<?php
						include_once CED_EBAY_DIRPATH . 'admin/partials/ced-ebay-shipping-fields.php';
						include_once CED_EBAY_DIRPATH . 'admin/partials/ced-ebay-add-shipping-template-fields.php';
						?>
					</div>

					<?php
				} elseif ( 'return' == $part ) {
					?>
					<div class="ced_ebay_return_details_wrapper">
						<?php
						include_once CED_EBAY_DIRPATH . 'admin/partials/ced-ebay-return-fields.php';
						?>
					</div>

					<?php
				} elseif ( 'description_template' == $part ) {
					?>
					<div class="ced_ebay_description_template_details_wrapper">
						<?php
						include_once CED_EBAY_DIRPATH . 'admin/partials/ced-ebay-description-template-fields.php';
						?>
					</div>

					<?php
				}
				?>
			</div>
		</div>
	</div>

</div>
