<?php
// If this file is called directly, abort.
if ( ! defined( 'ABSPATH' ) ) {
	die;
}
if ( empty( get_option( 'ced_ebay_user_access_token' ) ) ) {
	wp_redirect( get_admin_url() . 'admin.php?page=ced_ebay' );
}
$file = CED_EBAY_DIRPATH . 'admin/partials/header.php';
if ( file_exists( $file ) ) {
	require_once $file;
}

if ( isset( $_POST['ced_ebay_setting_nonce'] ) && wp_verify_nonce( sanitize_text_field( $_POST['ced_ebay_setting_nonce'] ), 'ced_ebay_setting_page_nonce' ) ) {
	if ( isset( $_POST['global_settings'] ) ) {
		$objDateTime = new DateTime( 'NOW' );
		$timestamp   = $objDateTime->format( 'Y-m-d\TH:i:s\Z' );

		$settings                              = array();
		$sanitized_array                       = filter_input_array( INPUT_POST, FILTER_UNSAFE_RAW );
		$settings                              = get_option( 'ced_ebay_global_settings', array() );
		$settings[ $user_id ]                  = isset( $sanitized_array['ced_ebay_global_settings'] ) ? ( $sanitized_array['ced_ebay_global_settings'] ) : array();
		 $settings[ $user_id ]['last_updated'] = $timestamp;
		update_option( 'ced_ebay_global_settings', $settings );


		$inventory_schedule            = isset( $sanitized_array['ced_ebay_global_settings']['ced_ebay_inventory_schedule_info'] ) && '0' != $sanitized_array['ced_ebay_global_settings']['ced_ebay_inventory_schedule_info'] ? ( $sanitized_array['ced_ebay_global_settings']['ced_ebay_inventory_schedule_info'] ) : as_unschedule_all_actions( 'ced_ebay_inventory_scheduler_job_' . $user_id );
		$order_schedule                = isset( $sanitized_array['ced_ebay_global_settings']['ced_ebay_order_schedule_info'] ) && '0' != $sanitized_array['ced_ebay_global_settings']['ced_ebay_order_schedule_info'] ? ( $sanitized_array['ced_ebay_global_settings']['ced_ebay_order_schedule_info'] ) : as_unschedule_all_actions( 'ced_ebay_order_scheduler_job_' . $user_id );
		$existing_product_sync         = isset( $sanitized_array['ced_ebay_global_settings']['ced_ebay_existing_products_sync'] ) && '0' != $sanitized_array['ced_ebay_global_settings']['ced_ebay_existing_products_sync'] ? ( $sanitized_array['ced_ebay_global_settings']['ced_ebay_existing_products_sync'] ) : wp_clear_scheduled_hook( 'ced_ebay_existing_products_sync_job_' . $user_id );
		$import_products_schedule      = isset( $sanitized_array['ced_ebay_global_settings']['ced_ebay_import_product_scheduler_info'] ) && '0' != $sanitized_array['ced_ebay_global_settings']['ced_ebay_import_product_scheduler_info'] ? ( $sanitized_array['ced_ebay_global_settings']['ced_ebay_import_product_scheduler_info'] ) : wp_clear_scheduled_hook( 'ced_ebay_import_products_job_' . $user_id );
		$instant_stock_update          = isset( $sanitized_array['ced_ebay_global_settings']['ced_ebay_instant_stock_update'] ) && '0' != $sanitized_array['ced_ebay_global_settings']['ced_ebay_instant_stock_update'] ? ( $sanitized_array['ced_ebay_global_settings']['ced_ebay_instant_stock_update'] ) : false;
		$bulk_upload_server_scheduler  = isset( $sanitized_array['ced_ebay_global_settings']['ced_ebay_bulk_upload_server_scheduler'] ) && '0' != $sanitized_array['ced_ebay_global_settings']['ced_ebay_bulk_upload_server_scheduler'] ? ( $sanitized_array['ced_ebay_global_settings']['ced_ebay_bulk_upload_server_scheduler'] ) : false;
		$sync_ended_listings_scheduler = isset( $sanitized_array['ced_ebay_global_settings']['ced_ebay_sync_ended_listings_info'] ) && '0' != $sanitized_array['ced_ebay_global_settings']['ced_ebay_sync_ended_listings_info'] ? ( $sanitized_array['ced_ebay_global_settings']['ced_ebay_sync_ended_listings_info'] ) : false;

		if ( 'On' == $bulk_upload_server_scheduler ) {
			if ( function_exists( 'as_has_scheduled_action' ) && function_exists( 'as_unschedule_all_actions' ) && function_exists( 'as_get_scheduled_actions' ) && function_exists( 'as_unschedule_all_actions' ) ) {
				$recurring_bulk_upload_action = as_has_scheduled_action( 'ced_ebay_recurring_bulk_upload_' . $user_id );
				if ( $recurring_bulk_upload_action ) {
					as_unschedule_all_actions( 'ced_ebay_recurring_bulk_upload_' . $user_id );
					$has_action = as_get_scheduled_actions(
						array(
							'group'  => 'ced_ebay_bulk_upload_' . $user_id,
							'status' => ActionScheduler_Store::STATUS_PENDING,
						),
						'ARRAY_A'
					);
					if ( is_array( $has_action ) && ! empty( $has_action ) ) {
						$unschedule_actions = as_unschedule_all_actions( null, null, 'ced_ebay_bulk_upload_' . $user_id );
					}
				}
			}
		}

		if ( 'On' == $instant_stock_update ) {
			if ( class_exists( 'WC_Webhook' ) ) {
				$wp_folder     = wp_upload_dir();
				$wp_upload_dir = $wp_folder['basedir'];
				$logs_folder   = $wp_upload_dir . '/ced-ebay/logs/stock-update/webhook/';
				if ( ! is_dir( $logs_folder ) ) {
					  wp_mkdir_p( $logs_folder, 0777 );
					  $current_date = new DateTime();
					  $current_date = $current_date->format( 'ymd' );
					  $log_file     = $logs_folder . 'logs_' . $current_date . '.txt';
					  file_put_contents( $log_file, '' );
				}
				delete_option( 'ced_ebay_stock_sync_progress_' . $user_id );
				if ( function_exists( 'as_has_scheduled_action' ) && function_exists( 'as_unschedule_all_actions' ) ) {
					if ( as_has_scheduled_action( 'ced_ebay_inventory_scheduler_job_' . $user_id ) ) {
						as_unschedule_all_actions( 'ced_ebay_inventory_scheduler_job_' . $user_id );
						$renderDataOnGlobalSettings = get_option( 'ced_ebay_global_settings', false );
						if ( ! empty( $renderDataOnGlobalSettings ) && is_array( $renderDataOnGlobalSettings ) ) {
							if ( ! empty( $renderDataOnGlobalSettings ) && is_array( $renderDataOnGlobalSettings ) ) {
								$global_settings      = array();
								$temp_global_settings = array();
								foreach ( $renderDataOnGlobalSettings as $key => $global_setting ) {
									if ( $user_id == $key ) {
										$temp_global_settings                                     = $global_setting;
										$temp_global_settings['ced_ebay_inventory_schedule_info'] = '0';
										$global_settings[ $user_id ]                              = $temp_global_settings;
										continue;
									}
									$global_settings[ $key ] = $global_setting;
								}
								update_option( 'ced_ebay_global_settings', $global_settings );
							}
						}
					}
				}
				$get_webhook_id = ! empty( get_option( 'ced_ebay_prduct_update_webhook_id_' . $user_id, true ) ) ? get_option( 'ced_ebay_prduct_update_webhook_id_' . $user_id, true ) : false;
				if ( $get_webhook_id ) {
					$webhook        = new WC_Webhook( $get_webhook_id );
					$webhook_status = $webhook->get_status();
					if ( 'paused' == $webhook_status ) {
						$webhook->set_status( 'active' );
						$webhook->save();
					}
					if ( 'disabled' == $webhook_status ) {
						$delivery_url = get_admin_url() . 'admin-ajax.php?action=ced_ebay_update_stock_on_webhook';
						$webhook      = new WC_Webhook();
						$webhook->set_name( 'Product update to eBay' );
						$webhook->set_user_id( get_current_user_id() ); // User ID used while generating the webhook payload.
						$webhook->set_topic( 'product.updated' ); // Event used to trigger a webhook.
						$webhook->set_delivery_url( $delivery_url ); // URL where webhook should be sent.
						$webhook->set_status( 'active' ); // Webhook status.
						$webhook_id = $webhook->save();
						if ( ! empty( $webhook_id ) ) {
							update_option( 'ced_ebay_prduct_update_webhook_id_' . $user_id, $webhook_id );
						}
					}
				} else {
					$delivery_url = get_admin_url() . 'admin-ajax.php?action=ced_ebay_update_stock_on_webhook';
					$webhook      = new WC_Webhook();
					$webhook->set_name( 'Product update to eBay' );
					$webhook->set_user_id( get_current_user_id() ); // User ID used while generating the webhook payload.
					$webhook->set_topic( 'product.updated' ); // Event used to trigger a webhook.
					$webhook->set_delivery_url( $delivery_url ); // URL where webhook should be sent.
					$webhook->set_status( 'active' ); // Webhook status.
					$webhook_id = $webhook->save();
					if ( ! empty( $webhook_id ) ) {
						update_option( 'ced_ebay_prduct_update_webhook_id_' . $user_id, $webhook_id );
					}
				}
			}
		} elseif ( 'Off' == $instant_stock_update ) {
			if ( class_exists( 'WC_Webhook' ) ) {
				$get_webhook_id = ! empty( get_option( 'ced_ebay_prduct_update_webhook_id_' . $user_id, true ) ) ? get_option( 'ced_ebay_prduct_update_webhook_id_' . $user_id, true ) : false;
				if ( $get_webhook_id ) {
					$webhook        = new WC_Webhook( $get_webhook_id );
					$webhook_status = $webhook->get_status();
					if ( 'active' == $webhook_status ) {
						$webhook->set_status( 'paused' );
						$webhook->save();
					}
				}
			}
		}

		if ( '0' == $sanitized_array['ced_ebay_global_settings']['ced_ebay_import_product_scheduler_info'] ) {
			update_option( 'ced_ebay_clear_import_process', true );
		}
		if ( '0' == $sanitized_array['ced_ebay_global_settings']['ced_ebay_inventory_schedule_info'] ) {
			delete_option( 'ced_ebay_stock_sync_progress_' . $user_id );
		}
		if ( '0' == $sanitized_array['ced_ebay_global_settings']['ced_ebay_sync_ended_listings_info'] ) {
			if ( function_exists( 'as_has_scheduled_action' ) && function_exists( 'as_unschedule_all_actions' ) ) {
				if ( as_has_scheduled_action( 'ced_ebay_sync_ended_listings_scheduler_job_' . $user_id ) ) {
					as_unschedule_all_actions( 'ced_ebay_sync_ended_listings_scheduler_job_' . $user_id );
				}
			}
		}
		if ( ! empty( $inventory_schedule ) && function_exists( 'as_schedule_recurring_action' ) ) {
			delete_option( 'ced_eBay_update_chunk_product_' . $user_id );
			if ( 'daily' == $inventory_schedule ) {
				$action_duration = 86400;
			} elseif ( 'twicedaily' == $inventory_schedule ) {
				$action_duration = 43200;
			} elseif ( 'ced_ebay_6min' == $inventory_schedule ) {
				$action_duration = 360;
			} elseif ( 'ced_ebay_10min' == $inventory_schedule ) {
				$action_duration = 600;
			} elseif ( 'ced_ebay_15min' == $inventory_schedule ) {
				$action_duration = 900;
			} elseif ( 'ced_ebay_30min' == $inventory_schedule ) {
				$action_duration = 1800;
			}
			as_schedule_recurring_action( time(), $action_duration, 'ced_ebay_inventory_scheduler_job_' . $user_id );
			if ( class_exists( 'WC_Webhook' ) ) {
				$get_webhook_id = ! empty( get_option( 'ced_ebay_prduct_update_webhook_id_' . $user_id, true ) ) ? get_option( 'ced_ebay_prduct_update_webhook_id_' . $user_id, true ) : false;
				if ( $get_webhook_id ) {
					$webhook        = new WC_Webhook( $get_webhook_id );
					$webhook_status = $webhook->get_status();
					if ( 'active' == $webhook_status ) {
						$webhook->set_status( 'paused' );
						$webhook->save();
					}
				}
			}
			update_option( 'ced_ebay_inventory_scheduler_job_' . $user_id, $user_id );
		}

		if ( ! empty( $order_schedule ) && function_exists( 'as_has_scheduled_action' ) && function_exists( 'as_unschedule_all_actions' ) && function_exists( 'as_schedule_recurring_action' ) ) {
			if ( as_has_scheduled_action( 'ced_ebay_order_scheduler_job_' . $user_id ) ) {
				as_unschedule_all_actions( 'ced_ebay_order_scheduler_job_' . $user_id );
			}
			if ( 'daily' == $order_schedule ) {
				$action_duration = 86400;
			} elseif ( 'twicedaily' == $order_schedule ) {
				$action_duration = 43200;
			} elseif ( 'ced_ebay_6min' == $order_schedule ) {
				$action_duration = 360;
			} elseif ( 'ced_ebay_10min' == $order_schedule ) {
				$action_duration = 600;
			} elseif ( 'ced_ebay_15min' == $order_schedule ) {
				$action_duration = 900;
			} elseif ( 'ced_ebay_30min' == $order_schedule ) {
				$action_duration = 1800;
			}
			as_schedule_recurring_action( time(), $action_duration, 'ced_ebay_order_scheduler_job_' . $user_id );
			update_option( 'ced_ebay_order_scheduler_job_' . $user_id, 'active' );
		}

		if ( ! empty( $sync_ended_listings_scheduler ) && function_exists( 'as_has_scheduled_action' ) && function_exists( 'as_unschedule_all_actions' ) && function_exists( 'as_schedule_recurring_action' ) ) {
			if ( as_has_scheduled_action( 'ced_ebay_sync_ended_listings_scheduler_job_' . $user_id ) ) {
				as_unschedule_all_actions( 'ced_ebay_sync_ended_listings_scheduler_job_' . $user_id );
			}
			if ( 'daily' == $sync_ended_listings_scheduler ) {
				$action_duration = 86400;
			} elseif ( 'twicedaily' == $sync_ended_listings_scheduler ) {
				$action_duration = 43200;
			} elseif ( 'ced_ebay_6min' == $sync_ended_listings_scheduler ) {
				$action_duration = 360;
			} elseif ( 'ced_ebay_10min' == $sync_ended_listings_scheduler ) {
				$action_duration = 600;
			} elseif ( 'ced_ebay_15min' == $sync_ended_listings_scheduler ) {
				$action_duration = 900;
			} elseif ( 'ced_ebay_30min' == $sync_ended_listings_scheduler ) {
				$action_duration = 1800;
			}
			as_schedule_recurring_action( time(), $action_duration, 'ced_ebay_sync_ended_listings_scheduler_job_' . $user_id );
			update_option( 'ced_ebay_sync_ended_listings_scheduler_job_' . $user_id, 'active' );
		}

		if ( ! empty( $existing_product_sync ) ) {
			wp_schedule_event( time(), $existing_product_sync, 'ced_ebay_existing_products_sync_job_' . $user_id );
			update_option( 'ced_ebay_existing_products_sync_job_' . $user_id, $user_id );
		}
		if ( ! empty( $import_products_schedule ) ) {
			wp_schedule_event( time(), $import_products_schedule, 'ced_ebay_import_products_job_' . $user_id );
			update_option( 'ced_ebay_import_products_job_' . $user_id, $user_id );
			delete_option( 'ced_ebay_clear_import_process' );
		}

		update_option( 'ebay_auto_syncing' . $user_id, 'off' );
		if ( isset( $_POST['ced_ebay_global_settings']['ced_ebay_auto_import'] ) ) {
			update_option( 'ced_ebay_enable_product_import', 'on' );
			wp_clear_scheduled_hook( 'ced_ebay_auto_import_cron_' . $user_id );
			wp_schedule_event( time(), 'ced_ebay_10min', 'ced_ebay_auto_import_cron_' . $user_id );
		} else {
			wp_clear_scheduled_hook( 'ced_ebay_auto_import_cron_' . $user_id );
			update_option( 'ced_ebay_enable_product_import', 'off' );
		}
		$admin_success_notice = '<div class="notice notice-success"> <p>Your configuration has been saved! </p></div>';
		print_r( $admin_success_notice );
	} elseif ( isset( $_POST['reset_global_settings'] ) ) {
		delete_option( 'ced_ebay_global_settings' );
		$admin_success_notice = '<div class="notice notice-success">
	  <p>Your configuration has been Reset!</p></div>';
		print_r( $admin_success_notice );
	}
}

$wc_countries = new WC_Countries();

$renderDataOnGlobalSettings = get_option( 'ced_ebay_global_settings', false );
if ( class_exists( 'WC_Webhook' ) ) {
	$get_webhook_id = ! empty( get_option( 'ced_ebay_prduct_update_webhook_id_' . $user_id, true ) ) ? get_option( 'ced_ebay_prduct_update_webhook_id_' . $user_id, true ) : false;
	if ( $get_webhook_id ) {
		$webhook        = new WC_Webhook( $get_webhook_id );
		$webhook_status = $webhook->get_status();
		if ( 'disabled' == $webhook_status || 'paused' == $webhook_status ) {
			if ( ! empty( $renderDataOnGlobalSettings[ $user_id ] ) && is_array( $renderDataOnGlobalSettings[ $user_id ] ) ) {
					$global_settings      = array();
					$temp_global_settings = array();
				foreach ( $renderDataOnGlobalSettings as $key => $global_setting ) {
					if ( $user_id == $key ) {
						$temp_global_settings                                  = $global_setting;
						$temp_global_settings['ced_ebay_instant_stock_update'] = 'Off';
						$global_settings[ $user_id ]                           = $temp_global_settings;
						break;
					}
					$global_settings[ $key ] = $global_setting;
				}
					update_option( 'ced_ebay_global_settings', $global_settings );

			}
		}
		if ( 'active' == $webhook_status ) {
			if ( ! empty( $renderDataOnGlobalSettings[ $user_id ] ) && is_array( $renderDataOnGlobalSettings[ $user_id ] ) ) {
					$global_settings      = array();
					$temp_global_settings = array();
				foreach ( $renderDataOnGlobalSettings as $key => $global_setting ) {
					if ( $user_id == $key ) {
						$temp_global_settings                                  = $global_setting;
						$temp_global_settings['ced_ebay_instant_stock_update'] = 'On';
						$global_settings[ $user_id ]                           = $temp_global_settings;
						break;
					}
					$global_settings[ $key ] = $global_setting;
				}
					update_option( 'ced_ebay_global_settings', $global_settings );

			}
		}
	}
}
// echo '<pre>';print_r($renderDataOnGlobalSettings);die;
?>
<div class="ced-ebay-v2-header">
	<div class="ced-ebay-v2-logo">
		<img src="<?php echo esc_attr( CED_EBAY_URL ) . 'admin/images/icon-100X100.png'; ?>">
	</div>
	<div class="ced-ebay-v2-header-content">
		<div class="ced-ebay-v2-title">
			<h1>eBay Configuration</h1>
		</div>
		<div class="ced-ebay-v2-actions">

				<div class="admin-custom-action-button-outer">

				<?php if ( ! empty( $renderDataOnGlobalSettings[ $user_id ]['last_updated'] ) ) { ?>
<div class="admin-custom-action-show-button-outer">
		<button style="margin-left:5px;" type="button" class="button btn-normal-sbc">
<span>Last Updated <?php echo esc_html( ced_ebay_time_elapsed_string( $renderDataOnGlobalSettings[ $user_id ]['last_updated'] ) ); ?></span>
</button>
			</div>
			<?php } ?>


<div class="admin-custom-action-show-button-outer">
<button style="background:#5850ec !important;" type="button" class="button btn-normal-tt">
<span><a style="all:unset;" href="https://docs.woocommerce.com/document/ebay-integration-for-woocommerce/#section-6" target="_blank">
Documentation					</a></span>
</button>

</div>
<div class="admin-custom-action-show-button-outer">
<button style="background:#5850ec !important;"  type="button" class="button btn-normal-tt">
<span><a style="all:unset;" href="" onclick="Calendly.initPopupWidget({url: 'https://calendly.com/ali_cedcommerce/meeting-with-ebay-integration-team'});return false;">Book a Free Onboarding Session</a>
</span>
</button>
	</div>

</div>
		</div>


	</div>
</div>

<style>


	.wp-core-ui select {
		vertical-align: baseline;
	}
</style>
<div class="ced-ebay-ui dashboard-wrapper version_control">
	<form id="cmb2-metabox-ced" class="ced-ebay-rollback-form cmb2-form ced-ebay-box" style="margin-right:20px;margin-left:2px;" action="" method="post">

		<header>
			<h3>Listings Configuration</h3>
		</header>

		<p>Increase or decrease the Price of eBay Listings, Adjust Stock Levels, Sync Price from WooCommerce and import eBay Categories.</p>

		<table class="form-table">
			<tbody>
				<tr>
					<?php
					$listing_stock = isset( $renderDataOnGlobalSettings[ $user_id ]['ced_ebay_listing_stock'] ) ? $renderDataOnGlobalSettings[ $user_id ]['ced_ebay_listing_stock'] : '';
					$stock_type    = isset( $renderDataOnGlobalSettings[ $user_id ]['ced_ebay_product_stock_type'] ) ? $renderDataOnGlobalSettings[ $user_id ]['ced_ebay_product_stock_type'] : '';
					?>
					<th scope="row"><label>Stock Levels</label></th>
					<td>
					<select name="ced_ebay_global_settings[ced_ebay_product_stock_type]" data-fieldId="ced_ebay_product_stock_type">
									<option value=""><?php esc_attr_e( 'Select', 'ebay-integration-for-woocommerce' ); ?></option>
									<option <?php echo ( 'MaxStock' == $stock_type ) ? 'selected' : ''; ?> value="MaxStock"><?php esc_attr_e( 'Maximum Quantity', 'ebay-integration-for-woocommerce' ); ?></option>
								</select>
						<input type="text" value="<?php echo esc_attr( $listing_stock ); ?>" id="ced_ebay_listing_stock" name="ced_ebay_global_settings[ced_ebay_listing_stock]">
						<p class="description">Set rules for Quantity of items listed on eBay.</p>
					</td>
				</tr>
				<tr class="cmb-row cmb-type-switch">
					<?php
					$skip_sku_sending = isset( $renderDataOnGlobalSettings[ $user_id ]['ced_ebay_sending_sku'] ) ? $renderDataOnGlobalSettings[ $user_id ]['ced_ebay_sending_sku'] : '';
					?>
					<th scope="row"><label>Skip Sending SKU for Simple Products?</label></th>
					<td style="padding:0px;">
						<ul class="cmb2-radio-list cmb2-list">
							<li>
								<input type="radio" class="cmb2-option"
								<?php
								if ( 'Off' == $skip_sku_sending ) {
									echo 'checked="checked"';}
								?>
								 name="ced_ebay_global_settings[ced_ebay_sending_sku]" id="ced_ebay_global_settings[ced_ebay_sending_sku]_Off" checked="checked" value="Off">
								<label for="ced_ebay_global_settings[ced_ebay_sending_sku]_Off">Off</label>
							</li>
							<li>
								<input type="radio" class="cmb2-option"
								<?php
								if ( 'On' == $skip_sku_sending ) {
									echo 'checked="checked"';}
								?>
								 name="ced_ebay_global_settings[ced_ebay_sending_sku]" id="ced_ebay_global_settings[ced_ebay_sending_sku]_On" value="On">
								<label for="ced_ebay_global_settings[ced_ebay_sending_sku]_On">On</label>
							</li>
						</ul>
						<p class="description">If you are having issues syncing inventory, use this setting to prevent SKUs from being sent for simple products on eBay.</p>

					</td>
				</tr>

				
				<tr>

					<th scope="row"><label>Markup</label></th>
					<td>
						<ul style="margin:0;">
							<li style="display:inline-block;">
								<?php
								$markup_type = isset( $renderDataOnGlobalSettings[ $user_id ]['ced_ebay_product_markup_type'] ) ? $renderDataOnGlobalSettings[ $user_id ]['ced_ebay_product_markup_type'] : '';
								?>
								<select name="ced_ebay_global_settings[ced_ebay_product_markup_type]" data-fieldId="ced_ebay_product_markup">
									<option value=""><?php esc_attr_e( 'Select', 'ebay-integration-for-woocommerce' ); ?></option>
									<option <?php echo ( 'Fixed_Increased' == $markup_type ) ? 'selected' : ''; ?> value="Fixed_Increased"><?php esc_attr_e( 'Fixed Increment', 'ebay-integration-for-woocommerce' ); ?></option>
									<option <?php echo ( 'Fixed_Decreased' == $markup_type ) ? 'selected' : ''; ?> value="Fixed_Decreased"><?php esc_attr_e( 'Fixed Decrement', 'ebay-integration-for-woocommerce' ); ?></option>
									<option <?php echo ( 'Percentage_Increased' == $markup_type ) ? 'selected' : ''; ?> value="Percentage_Increased"><?php esc_attr_e( 'Percentage Increment', 'ebay-integration-for-woocommerce' ); ?></option>
									<option <?php echo ( 'Percentage_Decreased' == $markup_type ) ? 'selected' : ''; ?> value="Percentage_Decreased"><?php esc_attr_e( 'Percentage Decrement', 'ebay-integration-for-woocommerce' ); ?></option>
								</select>

							</li>
							<li style="display:inline-block;">
								<?php
								$markup_price = isset( $renderDataOnGlobalSettings[ $user_id ]['ced_ebay_product_markup'] ) ? $renderDataOnGlobalSettings[ $user_id ]['ced_ebay_product_markup'] : '';
								?>
								<input type="text" value="<?php echo esc_attr( $markup_price ); ?>" id="ced_ebay_product_markup" name="ced_ebay_global_settings[ced_ebay_product_markup]">

							</li>
						</ul>


						<p class="description">Set your preference for Increasing/Decreasing the price of your eBay Listings.</p>
					</td>
				</tr>
				<tr class="cmb-row cmb-type-switch">
					<?php
					$sync_price = isset( $renderDataOnGlobalSettings[ $user_id ]['ced_ebay_sync_price'] ) ? $renderDataOnGlobalSettings[ $user_id ]['ced_ebay_sync_price'] : '';
					?>
					<th scope="row"><label>Sync Price to eBay</label></th>
					<td style="padding:0px;">
						<ul class="cmb2-radio-list cmb2-list">
							<li>
								<input type="radio" class="cmb2-option"
								<?php
								if ( 'Off' == $sync_price ) {
									echo 'checked="checked"';}
								?>
								 name="ced_ebay_global_settings[ced_ebay_sync_price]" id="ced_ebay_global_settings[ced_ebay_sync_price]_Off" checked="checked" value="Off">
								<label for="ced_ebay_global_settings[ced_ebay_sync_price]_Off">Off</label>
							</li>
							<li>
								<input type="radio" class="cmb2-option"
								<?php
								if ( 'On' == $sync_price ) {
									echo 'checked="checked"';}
								?>
								 name="ced_ebay_global_settings[ced_ebay_sync_price]" id="ced_ebay_global_settings[ced_ebay_sync_price]_On" value="On">
								<label for="ced_ebay_global_settings[ced_ebay_sync_price]_On">On</label>
							</li>
						</ul>
						<p class="description">Set your preference for WooCommerce Products Price Sync to eBay during Automatic Inventory Update.</p>

					</td>
				</tr>
				<tr class="cmb-row cmb-type-switch">
					<?php

					$instant_stock_update = isset( $renderDataOnGlobalSettings[ $user_id ]['ced_ebay_instant_stock_update'] ) ? $renderDataOnGlobalSettings[ $user_id ]['ced_ebay_instant_stock_update'] : '';
					?>
					<th scope="row"><label>Instant Stock Update (WooCommerce to eBay)</label></th>
					<td style="padding:0px;">
						<ul class="cmb2-radio-list cmb2-list">
							<li>
								<input type="radio" class="cmb2-option"
								<?php
								if ( 'Off' == $instant_stock_update ) {
									echo 'checked="checked"';}
								?>
								 name="ced_ebay_global_settings[ced_ebay_instant_stock_update]" id="ced_ebay_global_settings[ced_ebay_instant_stock_update]_Off" checked="checked" value="Off">
								<label for="ced_ebay_global_settings[ced_ebay_instant_stock_update]_Off">Off</label>
							</li>
							<li>
								<input type="radio" class="cmb2-option"
								<?php
								if ( 'On' == $instant_stock_update ) {
									echo 'checked="checked"';}
								?>
								 name="ced_ebay_global_settings[ced_ebay_instant_stock_update]" id="ced_ebay_global_settings[ced_ebay_instant_stock_update]_On" value="On">
								<label for="ced_ebay_global_settings[ced_ebay_instant_stock_update]_On">On</label>
							</li>
						</ul>
						<p class="description">Update stock on eBay when stock changes are detected on WooCommerce. Turning this on will disable scheduled inventory syncing.</p>

					</td>
				</tr>


				<tr class="cmb-row cmb-type-switch">
					<?php
					$import_categories = isset( $renderDataOnGlobalSettings[ $user_id ]['ced_ebay_import_ebay_categories'] ) ? $renderDataOnGlobalSettings[ $user_id ]['ced_ebay_import_ebay_categories'] : '';
					$shop_data         = ced_ebay_get_shop_data( $user_id );
					if ( ! empty( $shop_data ) ) {
						$siteID = $shop_data['site_id'];
					}
					$is_store_category_present = false;
					require_once CED_EBAY_DIRPATH . 'admin/ebay/lib/ebayAuthorization.php';
					$cedAuthorization        = new Ebayauthorization();
					$cedAuhorizationInstance = $cedAuthorization->get_instance();
					$storeDetails            = $cedAuhorizationInstance->getStoreData( $siteID, $user_id );
					if ( ! empty( $storeDetails ) && 'Success' == $storeDetails['Ack'] ) {
						$store_categories = $storeDetails['Store']['CustomCategories']['CustomCategory'];
						if ( ! empty( $store_categories ) ) {
							$is_store_category_present = true;
						}
					}
					?>
					<th scope="row"><label>Import and assign eBay Categories</label></th>
					<td style="padding:0px;">
						<ul class="cmb2-radio-list cmb2-list">
							<li>
								<input type="radio" class="cmb2-option"
								<?php
								if ( 'Disabled' == $import_categories ) {
									echo 'checked="checked"';}
								?>
								 class="ced_ebay_import_ebay_categories" name="ced_ebay_global_settings[ced_ebay_import_ebay_categories]" id="ced_ebay_global_settings[ced_ebay_import_ebay_categories]_Off" value="Disabled" checked="checked">
								<label for="ced_ebay_global_settings[ced_ebay_import_ebay_categories]_Off">Off</label>
							</li>
							<li>
								<input type="radio" class="cmb2-option"
								<?php
								if ( 'Enabled' == $import_categories ) {
									echo 'checked="checked"';}
								?>
								 class="ced_ebay_import_ebay_categories" name="ced_ebay_global_settings[ced_ebay_import_ebay_categories]" id="ced_ebay_global_settings[ced_ebay_import_ebay_categories]_On" value="Enabled">
								<label for="ced_ebay_global_settings[ced_ebay_import_ebay_categories]_On">On</label>
							</li>
						</ul>

						<!-- Add checks to only show the dropdown if the seller has active store subscription -->
						<?php if ( $is_store_category_present ) { ?>
						<ul id="ced_ebay_select_categories_type_to_import" style="margin:0;display:none;">
							<li style="display:inline-block;">
								<?php
								$import_categories_type = isset( $renderDataOnGlobalSettings[ $user_id ]['ced_ebay_import_categories_type'] ) ? $renderDataOnGlobalSettings[ $user_id ]['ced_ebay_import_categories_type'] : '';
								?>
								<select name="ced_ebay_global_settings[ced_ebay_import_categories_type]" data-fieldId="ced_ebay_import_categories_type">
									<option value=""><?php esc_attr_e( 'Select eBay categories to import', 'ebay-integration-for-woocommerce' ); ?></option>
									<option <?php echo ( 'ebay_site' == $import_categories_type ) ? 'selected' : ''; ?> value="ebay_site"><?php esc_attr_e( 'eBay Site Categories', 'ebay-integration-for-woocommerce' ); ?></option>
									<option <?php echo ( 'ebay_store' == $import_categories_type ) ? 'selected' : ''; ?> value="ebay_store"><?php esc_attr_e( 'eBay Store Categories', 'ebay-integration-for-woocommerce' ); ?></option>
								</select>
							</li>
								</ul>

						<p class="description">Set your preference for importing eBay Categories during Automatic Product Import from eBay to WooCommerce.</p>
						<?php } ?>
					</td>
				</tr>
				<tr>

					<th scope="row"><label>Import Products from eBay Site</label></th>
					<td>
						<ul style="margin:0;">
							<li style="display:inline-block;">
								<?php
								// an array of all the supported eBay sites
								$ebay_sites          = array(
									'US'             => 'United States',
									'UK'             => 'United Kingdom',
									'Australia'      => 'Australia',
									'Austria'        => 'Austria',
									'Belgium_French' => 'Belgium (French)',
									'Belgium_Dutch'  => 'Belgium (Dutch)',
									'Canada'         => 'Canada',
									'CanadaFrench'   => 'Canada French',
									'France'         => 'France',
									'Germany'        => 'Germany',
									'Italy'          => 'Italy',
									'Netherlands'    => 'Netherlands',
									'Spain'          => 'Spain',
									'Switzerland'    => 'Switzerland',
									'HongKong'       => 'Hong Kong',
									'India'          => 'India',
									'Ireland'        => 'Ireland',
									'Malaysia'       => 'Malaysia',
									'Philippines'    => 'Philippines',
									'Poland'         => 'Poland',
									'Singapore'      => 'Singapore',
									'Russia'         => 'Russia',
									'eBayMotors'     => 'eBay Motors',
								);
								$item_import_country = isset( $renderDataOnGlobalSettings[ $user_id ]['ced_ebay_item_import_country'] ) ? $renderDataOnGlobalSettings[ $user_id ]['ced_ebay_item_import_country'] : '';
								?>
								<select name="ced_ebay_global_settings[ced_ebay_item_import_country]" data-fieldId="ced_ebay_import_product_location">
								<option value=""><?php esc_attr_e( 'Select', 'ebay-integration-for-woocommerce' ); ?></option>
								<?php
								foreach ( $ebay_sites as $key => $import_country ) {
									?>
									<option <?php echo ( $key == $item_import_country ) ? 'selected' : ''; ?> value="<?php echo esc_attr( $key ); ?>"><?php esc_attr_e( $import_country, 'ebay-integration-for-woocommerce' ); ?></option>
									<?php
								}
								?>
								</select>

							</li>
						</ul>


						<p class="description">Select the eBay listing site for which you want to import the products. Product belonging to non-selected eBay site will be skipped during import process.</p>
					</td>
				</tr>
				<tr>

					<th scope="row"><label>Item Location</label></th>
					<td>
						<ul style="margin:0;">
							<li style="display:inline-block;">
								<?php
								$wc_countries          = new WC_Countries();
								$countries             = $wc_countries->get_countries();
								$item_location_country = isset( $renderDataOnGlobalSettings[ $user_id ]['ced_ebay_item_location_country'] ) ? $renderDataOnGlobalSettings[ $user_id ]['ced_ebay_item_location_country'] : '';
								?>
								<select name="ced_ebay_global_settings[ced_ebay_item_location_country]" data-fieldId="ced_ebay_product_location">
								<option value=""><?php esc_attr_e( 'Select', 'ebay-integration-for-woocommerce' ); ?></option>
								<?php
								foreach ( $countries as $key => $country ) {
									?>
									<option <?php echo ( $key == $item_location_country ) ? 'selected' : ''; ?> value="<?php echo esc_attr( $key ); ?>"><?php esc_attr_e( $country, 'ebay-integration-for-woocommerce' ); ?></option>
									<?php
								}
								?>
								</select>

							</li>
							<li style="display:inline-block;">
								<?php
								$item_location_state = isset( $renderDataOnGlobalSettings[ $user_id ]['ced_ebay_item_location_state'] ) ? $renderDataOnGlobalSettings[ $user_id ]['ced_ebay_item_location_state'] : '';
								?>
								<input type="text" placeholder="Enter City Name" value="<?php echo esc_attr( $item_location_state ); ?>" id="ced_ebay_product_markup" name="ced_ebay_global_settings[ced_ebay_item_location_state]">

							</li>
						</ul>


						<p class="description">If you are shipping the product from outside of your eBay Account Region, please set the item location.</p>
					</td>
				</tr>

				<tr>

					<th scope="row"><label>Description Template</label></th>
					<td>
						<ul style="margin:0;">
							<li style="display:inline-block;">
								<?php
								$upload_dir    = wp_upload_dir();
								$templates_dir = $upload_dir['basedir'] . '/ced-ebay/templates/';
								$templates     = array();
								$files         = glob( $upload_dir['basedir'] . '/ced-ebay/templates/*/template.html' );
								if ( is_array( $files ) ) {
									foreach ( $files as $file ) {
										$file     = basename( dirname( $file ) );
										$fullpath = $templates_dir . $file;

										if ( file_exists( $fullpath . '/info.txt' ) ) {
											$template_header       = array(
												'Template' => 'Template',
											);
											$template_data         = get_file_data( $fullpath . '/info.txt', $template_header, 'theme' );
											$item['template_name'] = $template_data['Template'];
										}
										$template_id                                = basename( $fullpath );
										$templates[ $template_id ]['template_name'] = $item['template_name'];
									}
								}
								$listing_description_template = isset( $renderDataOnGlobalSettings[ $user_id ]['ced_ebay_listing_description_template'] ) ? $renderDataOnGlobalSettings[ $user_id ]['ced_ebay_listing_description_template'] : '';
								if ( ! empty( $templates ) ) {
									?>
								<select name="ced_ebay_global_settings[ced_ebay_listing_description_template]" data-fieldId="ced_ebay_listing_description_template">
								<option value=""><?php esc_attr_e( 'Select', 'ebay-integration-for-woocommerce' ); ?></option>
									<?php
									foreach ( $templates as $key => $value ) {
										?>
									<option <?php echo ( $key == $listing_description_template ) ? 'selected' : ''; ?> value="<?php echo esc_attr( $key ); ?>"><?php esc_attr_e( $value['template_name'], 'ebay-integration-for-woocommerce' ); ?></option>
										<?php
									}
									?>
								</select>
									<?php
								} else {
									?>
						<p>No templates were found. Please create atleast one template in the Account Settings section of the plugin.</p>

									<?php
								}
								?>

							</li>
						</ul>

					</td>
				</tr>

				


			</tbody>
		</table>

		<footer>
		</footer>
		<header>
			<h3>Order Sync Configuration</h3>
		</header>

		<p>Configuration related to order syncing from eBay to WooCommerce</p>

		<table class="form-table ced-form-table" >
			<tbody>
			<tr class="cmb-row cmb-type-switch">

<th scope="row"><label>Sync eBay Orders</label></th>
<td>
	<?php
	$order_schedule = isset( $renderDataOnGlobalSettings[ $user_id ]['ced_ebay_order_schedule_info'] ) ? $renderDataOnGlobalSettings[ $user_id ]['ced_ebay_order_schedule_info'] : '';
	?>
	<select name="ced_ebay_global_settings[ced_ebay_order_schedule_info]" data-fieldId="ced_ebay_order_schedule_info">
		<option <?php echo ( '0' == $order_schedule ) ? 'selected' : ''; ?> value="0"><?php esc_attr_e( 'Disabled', 'ced-umb-ebay' ); ?></option>
		<option <?php echo ( 'daily' == $order_schedule ) ? 'selected' : ''; ?> value="daily"><?php esc_attr_e( 'Daily', 'ced-umb-ebay' ); ?></option>
		<option <?php echo ( 'twicedaily' == $order_schedule ) ? 'selected' : ''; ?> value="twicedaily"><?php esc_attr_e( 'Twice Daily', 'ced-umb-ebay' ); ?></option>
		<option <?php echo ( 'ced_ebay_6min' == $order_schedule ) ? 'selected' : ''; ?> value="ced_ebay_6min"><?php esc_attr_e( 'Every 6 Minutes', 'ced-umb-ebay' ); ?></option>
		<option <?php echo ( 'ced_ebay_10min' == $order_schedule ) ? 'selected' : ''; ?> value="ced_ebay_10min"><?php esc_attr_e( 'Every 10 Minutes', 'ced-umb-ebay' ); ?></option>
		<option <?php echo ( 'ced_ebay_15min' == $order_schedule ) ? 'selected' : ''; ?> value="ced_ebay_15min"><?php esc_attr_e( 'Every 15 Minutes', 'ced-umb-ebay' ); ?></option>
		<option <?php echo ( 'ced_ebay_30min' == $order_schedule ) ? 'selected' : ''; ?> value="ced_ebay_30min"><?php esc_attr_e( 'Every 30 Minutes', 'ced-umb-ebay' ); ?></option>

	</select>

	<p class="description">Fetch your eBay Orders automatically and create them in WooCommerce. Before running this scheduler, make sure the corresponding eBay listing or SKU exists in your WooCommerce store. </p>
	</p>
</td>
</tr>
			<tr class="cmb-row cmb-type-switch">
					<?php
					$customer = isset( $renderDataOnGlobalSettings[ $user_id ]['ced_ebay_create_customer'] ) ? $renderDataOnGlobalSettings[ $user_id ]['ced_ebay_create_customer'] : '';
					?>
					<th scope="row"><label>Import eBay buyers as WooCommerce customers</label></th>
					<td style="padding:0px;">
						<ul class="cmb2-radio-list cmb2-list">
							<li>
								<input type="radio" class="cmb2-option"
								<?php
								if ( 'Off' == $customer ) {
									echo 'checked="checked"';}
								?>
								 name="ced_ebay_global_settings[ced_ebay_create_customer]" id="ced_ebay_global_settings[ced_ebay_create_customer]_Off" checked="checked" value="Off">
								<label for="ced_ebay_global_settings[ced_ebay_create_customer]_Off">Off</label>
							</li>
							<li>
								<input type="radio" class="cmb2-option"
								<?php
								if ( 'On' == $customer ) {
									echo 'checked="checked"';}
								?>
								 name="ced_ebay_global_settings[ced_ebay_create_customer]" id="ced_ebay_global_settings[ced_ebay_create_customer]_On" value="On">
								<label for="ced_ebay_global_settings[ced_ebay_create_customer]_On">On</label>
							</li>
						</ul>
						<p class="description">Set your preference for Creating Customers when importing eBay orders into WooCommerce.</p>

					</td>
				</tr>

				<?php
				$shop_data = ced_ebay_get_shop_data( $user_id );
				if ( ! empty( $shop_data ) ) {
					$siteID = $shop_data['site_id'];
				}
				if ( '3' == $siteID || '101' ==  $siteID) {

					?>
				<tr>

					<th scope="row"><label>Exclude Order Product VAT</label></th>
					<?php
						$exclude_product_vat = isset( $renderDataOnGlobalSettings[ $user_id ]['ced_ebay_exclude_product_vat'] ) ? $renderDataOnGlobalSettings[ $user_id ]['ced_ebay_exclude_product_vat'] : '';
					?>
					<td style="padding:0px;">
						<ul class="cmb2-radio-list cmb2-list">
							<li>
								<input type="radio" class="cmb2-option"
								<?php
								if ( 'Off' == $exclude_product_vat ) {
									echo 'checked="checked"';}
								?>
								 name="ced_ebay_global_settings[ced_ebay_exclude_product_vat]" id="ced_ebay_global_settings[ced_ebay_exclude_product_vat]_Off" checked="checked" value="Off">
								<label for="ced_ebay_global_settings[ced_ebay_exclude_product_vat]_Off">Off</label>
							</li>
							<li>
								<input type="radio" class="cmb2-option"
								<?php
								if ( 'On' == $exclude_product_vat ) {
									echo 'checked="checked"';}
								?>
								 name="ced_ebay_global_settings[ced_ebay_exclude_product_vat]" id="ced_ebay_global_settings[ced_ebay_exclude_product_vat]_On" value="On">
								<label for="ced_ebay_global_settings[ced_ebay_exclude_product_vat]_On">On</label>
							</li>
						</ul>
						<p class="description">Exclude VAT from the ordered product amount when an eBay order is created in WooCommerce.</p>

					</td>
				</tr>

					<?php
				}
				?>

			</tbody>
		</table>


		<footer>
		</footer>
		<header>
			<h3>Scheduler Configuration</h3>
		</header>

		<p>Manage the Automatic Sync of Products & Stock</p>

		<table class="form-table ced-form-table" >
			<tbody>
			<tr class="cmb-row cmb-type-switch">
					<?php
					$server_scheduler = isset( $renderDataOnGlobalSettings[ $user_id ]['ced_ebay_bulk_upload_server_scheduler'] ) ? $renderDataOnGlobalSettings[ $user_id ]['ced_ebay_bulk_upload_server_scheduler'] : '';
					?>
					<th scope="row"><label>Bulk Upload <br>(Server Scheduler)</label></th>
					<td style="padding:0px;">
						<ul class="cmb2-radio-list cmb2-list">
							<li>
								<input type="radio" class="cmb2-option"
								<?php
								if ( 'Off' == $server_scheduler ) {
									echo 'checked="checked"';}
								?>
								 name="ced_ebay_global_settings[ced_ebay_bulk_upload_server_scheduler]" id="ced_ebay_global_settings[ced_ebay_bulk_upload_server_scheduler]_Off" checked="checked" value="Off">
								<label for="ced_ebay_global_settings[ced_ebay_bulk_upload_server_scheduler]_Off">Off</label>
							</li>
							<li>
								<input type="radio" class="cmb2-option"
								<?php
								if ( 'On' == $server_scheduler ) {
									echo 'checked="checked"';}
								?>
								 name="ced_ebay_global_settings[ced_ebay_bulk_upload_server_scheduler]" id="ced_ebay_global_settings[ced_ebay_bulk_upload_server_scheduler]_On" value="On">
								<label for="ced_ebay_global_settings[ced_ebay_bulk_upload_server_scheduler]_On">On</label>
							</li>
						</ul>
						<p class="description">When enabled, you can run the Bulk Upload process using an external cron job. Use this only if you are having issues running native Bulk Upload. Turning this on will automatically disable the native Bulk Upload. </p>
						<p class="description">The command you want to use is <code>wget -qO- <?php esc_attr_e( site_url( '/admin-ajax.php?action=ced_ebay_bulk_upload_endpoint&user_id=' . $user_id ) ); ?> &> /dev/null</code> for setting up an external cron job to run Bulk Upload.
</p>

					</td>
				</tr>
				
				<tr class="cmb-row cmb-type-switch">

					<th scope="row"><label>Sync Stock Levels from WooCommerce to eBay</label></th>
					<td>
						<?php
						$inventory_schedule = isset( $renderDataOnGlobalSettings[ $user_id ]['ced_ebay_inventory_schedule_info'] ) ? $renderDataOnGlobalSettings[ $user_id ]['ced_ebay_inventory_schedule_info'] : '';
						?>

						<select name="ced_ebay_global_settings[ced_ebay_inventory_schedule_info]" class="block mt-2 max-w-md" data-fieldId="ced_ebay_inventory_schedule_info">
							<option <?php echo ( '0' == $inventory_schedule ) ? 'selected' : ''; ?> value="0"><?php esc_attr_e( 'Disabled', 'ced-umb-ebay' ); ?></option>
							<option <?php echo ( 'daily' == $inventory_schedule ) ? 'selected' : ''; ?> value="daily"><?php esc_attr_e( 'Daily', 'ced-umb-ebay' ); ?></option>
							<option <?php echo ( 'twicedaily' == $inventory_schedule ) ? 'selected' : ''; ?> value="twicedaily"><?php esc_attr_e( 'Twice Daily', 'ced-umb-ebay' ); ?></option>
							<option <?php echo ( 'ced_ebay_6min' == $inventory_schedule ) ? 'selected' : ''; ?> value="ced_ebay_6min"><?php esc_attr_e( 'Every 6 Minutes', 'ced-umb-ebay' ); ?></option>
							<option <?php echo ( 'ced_ebay_10min' == $inventory_schedule ) ? 'selected' : ''; ?> value="ced_ebay_10min"><?php esc_attr_e( 'Every 10 Minutes', 'ced-umb-ebay' ); ?></option>
							<option <?php echo ( 'ced_ebay_15min' == $inventory_schedule ) ? 'selected' : ''; ?> value="ced_ebay_15min"><?php esc_attr_e( 'Every 15 Minutes', 'ced-umb-ebay' ); ?></option>
							<option <?php echo ( 'ced_ebay_30min' == $inventory_schedule ) ? 'selected' : ''; ?> value="ced_ebay_30min"><?php esc_attr_e( 'Every 30 Minutes', 'ced-umb-ebay' ); ?></option>

						</select>

						<p class="description"> Update your eBay inventory automatically as soon as stock change is detected in your WooCommerce store. </p>
						<?php
						if ( 'false' === get_option( 'ced_ebay_out_of_stock_preference_' . $user_id, true ) ) {
							?>
							<p class="description"><b>Listings on eBay will be automatically removed if they are out of stock on WooCommerce.</b></p>
							<?php
						}
						?>
						</p>
						</p>
					</td>
				</tr>

				<tr class="cmb-row cmb-type-switch">

					<th scope="row"><label>Link Existing eBay Products (Using same SKUs)</label></th>
					<td>
						<?php

						$existing_product_sync = isset( $renderDataOnGlobalSettings[ $user_id ]['ced_ebay_existing_products_sync'] ) ? ( $renderDataOnGlobalSettings[ $user_id ]['ced_ebay_existing_products_sync'] ) : '';

						?>

						<select name="ced_ebay_global_settings[ced_ebay_existing_products_sync]" class="block mt-2 max-w-md" data-fieldId="ced_ebay_existing_products_sync">
							<option <?php echo ( '0' == $existing_product_sync ) ? 'selected' : ''; ?> value="0"><?php esc_attr_e( 'Disabled', 'ced-umb-ebay' ); ?></option>
							<option <?php echo ( 'daily' == $existing_product_sync ) ? 'selected' : ''; ?> value="daily"><?php esc_attr_e( 'Daily', 'ced-umb-ebay' ); ?></option>
							<option <?php echo ( 'twicedaily' == $existing_product_sync ) ? 'selected' : ''; ?> value="twicedaily"><?php esc_attr_e( 'Twice Daily', 'ced-umb-ebay' ); ?></option>
							<option <?php echo ( 'ced_ebay_6min' == $existing_product_sync ) ? 'selected' : ''; ?> value="ced_ebay_6min"><?php esc_attr_e( 'Every 6 Minutes', 'ced-umb-ebay' ); ?></option>
							<option <?php echo ( 'ced_ebay_10min' == $existing_product_sync ) ? 'selected' : ''; ?> value="ced_ebay_10min"><?php esc_attr_e( 'Every 10 Minutes', 'ced-umb-ebay' ); ?></option>
							<option <?php echo ( 'ced_ebay_15min' == $existing_product_sync ) ? 'selected' : ''; ?> value="ced_ebay_15min"><?php esc_attr_e( 'Every 15 Minutes', 'ced-umb-ebay' ); ?></option>
							<option <?php echo ( 'ced_ebay_30min' == $existing_product_sync ) ? 'selected' : ''; ?> value="ced_ebay_30min"><?php esc_attr_e( 'Every 30 Minutes', 'ced-umb-ebay' ); ?></option>
						</select>

						<p class="description"> Link your eBay products to the corresponding WooCommerce products on the basis of SKU.</p>
						</p>
						</p>
						</p>
					</td>
				</tr>
				<tr class="cmb-row cmb-type-switch">

<th scope="row"><label>Import eBay Products to WooCommerce</label></th>
<td>
<?php

$import_products_schedule = isset( $renderDataOnGlobalSettings[ $user_id ]['ced_ebay_import_product_scheduler_info'] ) ? ( $renderDataOnGlobalSettings[ $user_id ]['ced_ebay_import_product_scheduler_info'] ) : '';

?>

<select name="ced_ebay_global_settings[ced_ebay_import_product_scheduler_info]" class="block mt-2 max-w-md" data-fieldId="ced_ebay_import_product_scheduler_info">
					<option <?php echo ( '0' == $import_products_schedule ) ? 'selected' : ''; ?> value="0"><?php esc_attr_e( 'Disabled', 'ced-umb-ebay' ); ?></option>
					<option <?php echo ( 'daily' == $import_products_schedule ) ? 'selected' : ''; ?> value="daily"><?php esc_attr_e( 'Daily', 'ced-umb-ebay' ); ?></option>
					<option <?php echo ( 'twicedaily' == $import_products_schedule ) ? 'selected' : ''; ?> value="twicedaily"><?php esc_attr_e( 'Twice Daily', 'ced-umb-ebay' ); ?></option>
					<option <?php echo ( 'ced_ebay_6min' == $import_products_schedule ) ? 'selected' : ''; ?> value="ced_ebay_6min"><?php esc_attr_e( 'Every 6 Minutes', 'ced-umb-ebay' ); ?></option>
					<option <?php echo ( 'ced_ebay_10min' == $import_products_schedule ) ? 'selected' : ''; ?> value="ced_ebay_10min"><?php esc_attr_e( 'Every 10 Minutes', 'ced-umb-ebay' ); ?></option>
					<option <?php echo ( 'ced_ebay_15min' == $import_products_schedule ) ? 'selected' : ''; ?> value="ced_ebay_15min"><?php esc_attr_e( 'Every 15 Minutes', 'ced-umb-ebay' ); ?></option>
					<option <?php echo ( 'ced_ebay_30min' == $import_products_schedule ) ? 'selected' : ''; ?> value="ced_ebay_30min"><?php esc_attr_e( 'Every 30 Minutes', 'ced-umb-ebay' ); ?></option>
				</select>


	<p class="description"> Import your eBay Products to your WooCommerce Store automatically. For auction listings, the price of imported products will be 0. </p>

	</p>
	</p>
	</p>
</td>
</tr>

<tr class="cmb-row cmb-type-switch">

<th scope="row"><label>Sync Manually Ended eBay Listings</label></th>
<td>
<?php

$sync_ended_listings = isset( $renderDataOnGlobalSettings[ $user_id ]['ced_ebay_sync_ended_listings_info'] ) ? ( $renderDataOnGlobalSettings[ $user_id ]['ced_ebay_sync_ended_listings_info'] ) : '';

?>

<select name="ced_ebay_global_settings[ced_ebay_sync_ended_listings_info]" class="block mt-2 max-w-md" data-fieldId="ced_ebay_sync_ended_listings_info">
					<option <?php echo ( '0' == $sync_ended_listings ) ? 'selected' : ''; ?> value="0"><?php esc_attr_e( 'Disabled', 'ced-umb-ebay' ); ?></option>
					<option <?php echo ( 'daily' == $sync_ended_listings ) ? 'selected' : ''; ?> value="daily"><?php esc_attr_e( 'Daily', 'ced-umb-ebay' ); ?></option>
					<option <?php echo ( 'twicedaily' == $sync_ended_listings ) ? 'selected' : ''; ?> value="twicedaily"><?php esc_attr_e( 'Twice Daily', 'ced-umb-ebay' ); ?></option>
					<option <?php echo ( 'ced_ebay_6min' == $sync_ended_listings ) ? 'selected' : ''; ?> value="ced_ebay_6min"><?php esc_attr_e( 'Every 6 Minutes', 'ced-umb-ebay' ); ?></option>
					<option <?php echo ( 'ced_ebay_10min' == $sync_ended_listings ) ? 'selected' : ''; ?> value="ced_ebay_10min"><?php esc_attr_e( 'Every 10 Minutes', 'ced-umb-ebay' ); ?></option>
					<option <?php echo ( 'ced_ebay_15min' == $sync_ended_listings ) ? 'selected' : ''; ?> value="ced_ebay_15min"><?php esc_attr_e( 'Every 15 Minutes', 'ced-umb-ebay' ); ?></option>
					<option <?php echo ( 'ced_ebay_30min' == $sync_ended_listings ) ? 'selected' : ''; ?> value="ced_ebay_30min"><?php esc_attr_e( 'Every 30 Minutes', 'ced-umb-ebay' ); ?></option>
				</select>


	<p class="description">Sync the listings directly removed from eBay Seller Hub to WooCommerce. By default, only the listings removed in the last 2 days, from the eBay Seller Hub, will be synced to WooCommerce.</p>

	</p>
	</p>
	</p>
</td>
</tr>
			</tbody>
		</table>

		<footer></footer>
		<header>
			<h3>Miscellaneous Configuration</h3>
		</header>
		<table class="form-table ced-form-table" >
			<tbody>
			<tr class="cmb-row cmb-type-switch">
					<?php
					$live_chat_opt_in = isset( $renderDataOnGlobalSettings[ $user_id ]['ced_ebay_live_chat_opt_in'] ) ? $renderDataOnGlobalSettings[ $user_id ]['ced_ebay_live_chat_opt_in'] : 'On';
					?>
					<th scope="row"><label>Chat Support Icon</label></th>
					<td style="padding:0px;">
						<ul class="cmb2-radio-list cmb2-list">
							<li>
								<input type="radio" class="cmb2-option"
								<?php
								if ( 'Off' == $live_chat_opt_in ) {
									echo 'checked="checked"';}
								?>
								 name="ced_ebay_global_settings[ced_ebay_live_chat_opt_in]" id="ced_ebay_global_settings[ced_ebay_live_chat_opt_in]_Off" checked="checked" value="Off">
								<label for="ced_ebay_global_settings[ced_ebay_live_chat_opt_in]_Off">Off</label>
							</li>
							<li>
								<input type="radio" class="cmb2-option"
								<?php
								if ( 'On' == $live_chat_opt_in ) {
									echo 'checked="checked"';}
								?>
								 name="ced_ebay_global_settings[ced_ebay_live_chat_opt_in]" id="ced_ebay_global_settings[ced_ebay_live_chat_opt_in]_On" value="On">
								<label for="ced_ebay_global_settings[ced_ebay_live_chat_opt_in]_On">On</label>
							</li>
						</ul>
						<p class="description">Turn on and off the chat support icon displayed in the bottom right corner throughout the plugin.</p>

					</td>
				</tr>
								</tbody>
								</table>
		<footer>
			<?php wp_nonce_field( 'ced_ebay_setting_page_nonce', 'ced_ebay_setting_nonce' ); ?>
			<button id="save_global_settings" name="global_settings" class="button button-primary button-xlarge"><?php esc_attr_e( 'Save Configuration', 'ebay-integration-for-woocommerce' ); ?></button>
			<button id="rest_global_settings" name="reset_global_settings" class="button button-primary button-xlarge" style="background:#c62019 !important;"><?php esc_attr_e( 'Reset Configuration', 'ebay-integration-for-woocommerce' ); ?></button>
		</footer>

	</form>
</div>

<script>
	if ( jQuery( 'input[name="ced_ebay_global_settings[ced_ebay_import_ebay_categories]"]:checked' ).val() == 'Enabled') {
			jQuery('#ced_ebay_select_categories_type_to_import').show();
		} else if( jQuery( 'input[name="ced_ebay_global_settings[ced_ebay_import_ebay_categories]"]:checked' ).val() == 'Disabled') {
			jQuery('#ced_ebay_select_categories_type_to_import').hide();

		}
</script>

<script type="text/template" id="tmpl-wc-ced-ebay-show-ext-cron-urls-modal">
		<div class="wc-backbone-modal wc-order-preview">
				<div class="wc-backbone-modal-content">
					<section class="wc-backbone-modal-main" role="main">
						<header class="wc-backbone-modal-header">
							<h1>Product Auto-Update</h1>
						<button class="modal-close modal-close-link dashicons dashicons-no-alt">
								<span class="screen-reader-text">Close modal panel</span>
							</button>
						</header>
											
		<div class="ced-ebay-bootstrap-wrapper">
		<div class="container mt-3 mb-3">
	

	<div class="row">
		<div class="col-md-12">
			<h5 style="color:#0073aa;">Select Properties To Auto-Update</h5>
			<p class="mt-2 mb-0">> Before you begin Auto-Update, make sure the WooCommerce products have a profile associated with them and synced with our plugin.</p>		
			<p class="mt-0 mb-0">> For faster updates to eBay, only select the properties that change frequently.</p>		
<p class="mt-0 mb-0">> Pricing and inventory can't be updated using Auto-Update. Use Inventory Sync instead.</p>		
<p class="mt-0 mb-0">> In some cases, adding new attributes and variations will not auto-update on eBay successfully.</p>
<p class="mt-0">> You can check the progress of auto-update in the Feeds section</p>
		<div class="form-check form-check-inline">
  <input class="form-check-input" style="width: 17px; height: 17px;" type="checkbox" id="inlineCheckbox1" value="option1">
  <label class="form-check-label" for="inlineCheckbox1"><b>Product Description</b></label>
</div>
<div class="form-check form-check-inline">
  
<input class="form-check-input" style="width: 17px; height: 17px;" type="checkbox" id="inlineCheckbox2" value="option1">
  <label class="form-check-label" for="inlineCheckbox2"><b>Product Images</b></label>
</div>
<div class="form-check form-check-inline">
  
<input class="form-check-input" style="width: 17px; height: 17px;" type="checkbox" id="inlineCheckbox3" value="option1">
  <label class="form-check-label" for="inlineCheckbox3"><b>Product Title</b></label>
</div>
<div class="form-check form-check-inline">
  
<input class="form-check-input" style="width: 17px; height: 17px;" type="checkbox" id="inlineCheckbox4" value="option1">
  <label class="form-check-label" for="inlineCheckbox4"><b>Product Variations</b></label>
</div>
<div class="form-check form-check-inline">
  
<input class="form-check-input" style="width: 17px; height: 17px;" type="checkbox" id="inlineCheckbox5" value="option1">
  <label class="form-check-label" for="inlineCheckbox5"><b>Shipping Details for Products</b></label>
</div>

</div> <!-- /.col -->
	</div>
	
	</div>
	
</div>



						<footer>
							<div class="inner">

								<a class="button button-primary button-large" aria-label="Edit this order">Begin Update</a>
							</div>
						</footer>
					</section>
				</div>
			</div>
			<div class="wc-backbone-modal-backdrop modal-close"></div>
						</script>

