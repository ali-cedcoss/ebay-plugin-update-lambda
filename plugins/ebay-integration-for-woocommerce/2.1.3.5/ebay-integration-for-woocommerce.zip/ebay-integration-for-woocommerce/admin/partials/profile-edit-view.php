<?php
// If this file is called directly, abort.
if ( ! defined( 'ABSPATH' ) ) {
	die;
}

if ( empty( get_option( 'ced_ebay_user_access_token' ) ) ) {
	wp_redirect( get_admin_url() . 'admin.php?page=ced_ebay' );
}

$fileHeader   = CED_EBAY_DIRPATH . 'admin/partials/header.php';
$fileCategory = CED_EBAY_DIRPATH . 'admin/ebay/lib/cedGetcategories.php';
$fileFields   = CED_EBAY_DIRPATH . 'admin/partials/products_fields.php';


if ( file_exists( $fileHeader ) ) {
	require_once $fileHeader;
}
if ( file_exists( $fileCategory ) ) {
	require_once $fileCategory;
}
if ( file_exists( $fileFields ) ) {
	require_once $fileFields;
}
$user_id       = isset( $_GET['user_id'] ) ? sanitize_text_field( $_GET['user_id'] ) : '';
$wp_folder     = wp_upload_dir();
$wp_upload_dir = $wp_folder['basedir'];
$wp_upload_dir = $wp_upload_dir . '/ced-ebay/category-specifics/' . $user_id . '/';
if ( ! is_dir( $wp_upload_dir ) ) {
	wp_mkdir_p( $wp_upload_dir, 0777 );
}
$shop_data = ced_ebay_get_shop_data( $user_id );
if ( ! empty( $shop_data ) ) {
	$siteID      = $shop_data['site_id'];
	$token       = $shop_data['access_token'];
	$getLocation = $shop_data['location'];
}
$isProfileSaved = false;
$profileID      = isset( $_GET['profileID'] ) ? sanitize_text_field( $_GET['profileID'] ) : '';
$ebay_cat_id    = isset( $_GET['eBayCatID'] ) ? sanitize_text_field( $_GET['eBayCatID'] ) : '';

function get_categories_hierarchical( $args = array() ) {

	if ( ! isset( $args['parent'] ) ) {
		$args['parent'] = 0;
	}

	$categories = get_categories( $args );

	foreach ( $categories as $key => $category ) :

		$args['parent'] = $category->term_id;

		$categories[ $key ]->child_categories = get_categories_hierarchical( $args );

	endforeach;

	return $categories;

}

$woo_store_categories = get_categories_hierarchical(
	array(
		'taxonomy'   => 'product_cat',
		'hide_empty' => false,
	)
);

if ( ! empty( $_POST['ced_ebay_profile_edit_category_dropdown'] ) && isset( $_POST['ced_ebay_profile_edit'] ) && wp_verify_nonce( sanitize_text_field( $_POST['ced_ebay_profile_edit'] ), 'ced_ebay_profile_edit_page_nonce' ) ) {
	if ( isset( $_POST['add_meta_keys'] ) || isset( $_POST['ced_ebay_profile_save_button'] ) ) {

		global $wpdb;

		$tableName = $wpdb->prefix . 'ced_ebay_profiles';

		$profile_data = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}ced_ebay_profiles WHERE `id`=%d AND `user_id`=%s", $profileID, $user_id ), 'ARRAY_A' );
		if ( ! empty( $profile_data ) ) {
			$woo_categories        = ! empty( $profile_data[0]['woo_categories'] ) ? json_decode( $profile_data[0]['woo_categories'], true ) : false;
			$profile_category_data = json_decode( $profile_data[0]['profile_data'], true );
		}
		if ( ! empty( $woo_categories ) && is_array( $woo_categories ) ) {
			foreach ( $woo_categories as $key => $in_db_woo_cat ) {
				delete_term_meta( $in_db_woo_cat, 'ced_ebay_profile_created_' . $user_id );
				delete_term_meta( $in_db_woo_cat, 'ced_ebay_profile_id_' . $user_id );
				delete_term_meta( $in_db_woo_cat, 'ced_ebay_mapped_category_' . $user_id );
			}
		}
		$profile_category_data = isset( $profile_category_data ) ? $profile_category_data : '';
		$profile_category_id   = isset( $profile_category_data['_umb_ebay_category']['default'] ) ? $profile_category_data['_umb_ebay_category']['default'] : '';
		$sanitized_array       = filter_input_array( INPUT_POST, FILTER_UNSAFE_RAW );

		// echo '<pre>'; print_r($sanitized_array); die;
		$woo_categories_mapped = isset( $sanitized_array['ced_ebay_profile_edit_category_dropdown'] ) ? $sanitized_array['ced_ebay_profile_edit_category_dropdown'] : false;
		if ( ! empty( $woo_categories_mapped ) && is_array( $woo_categories_mapped ) ) {
			foreach ( $woo_categories_mapped as $key => $woo_mapped_cat ) {
				update_term_meta( $woo_mapped_cat, 'ced_ebay_profile_created_' . $user_id, 'yes' );
				update_term_meta( $woo_mapped_cat, 'ced_ebay_profile_id_' . $user_id, $profileID );
				update_term_meta( $woo_mapped_cat, 'ced_ebay_mapped_category_' . $user_id, $ebay_cat_id );
			}
			$woo_categories_mapped = json_encode( $woo_categories_mapped );
		}
		$is_active                    = isset( $sanitized_array['profile_status'] ) ? 'Active' : 'Inactive';
		$marketplaceName              = isset( $sanitized_array['marketplaceName'] ) ? ( $sanitized_array['marketplaceName'] ) : 'all';
		$updateinfo                   = array();
		$ced_ebay_custom_item_aspects = isset( $sanitized_array['custom_item_aspects'] ) ? ( $sanitized_array['custom_item_aspects'] ) : array();

		$common = isset( $sanitized_array['ced_ebay_required_common'] ) ? ( $sanitized_array['ced_ebay_required_common'] ) : array();
		foreach ( $common as $key ) {
			$arrayToSave = array();
			if ( false !== strpos( $key, '_required' ) ) {
				$position                            = strpos( $key, '_required' );
				$key                                 = substr( $key, 0, $position );
				$sanitized_array[ $key ]['required'] = true;
				$arrayToSave['required']             = $sanitized_array[ $key ]['required'];
			}
			isset( $sanitized_array[ $key ][0] ) ? $arrayToSave['default'] = ( $sanitized_array[ $key ][0] ) : $arrayToSave['default'] = '';

			if ( '_umb_' . $marketplaceName . '_subcategory' == $key ) {

				isset( $sanitized_array[ $key ] ) ? $arrayToSave['default'] = ( $sanitized_array[ $key ] ) : $arrayToSave['default'] = '';
			}
			if ( '_umb_ebay_category' == $key && '' == $profileID ) {
				$category_id = isset( $sanitized_array['ced_ebay_level3_category'] ) ? ( $sanitized_array['ced_ebay_level3_category'] ) : '';
				$category_id = isset( $category_id[0] ) ? $category_id[0] : '';
				isset( $sanitized_array[ $key ][0] ) ? $arrayToSave['default'] = $category_id : $arrayToSave['default'] = '';
			}
			isset( $sanitized_array[ $key . '_attibuteMeta' ] ) ? $arrayToSave['metakey'] = ( $sanitized_array[ $key . '_attibuteMeta' ] )
				: $arrayToSave['metakey'] = 'null';
			$updateinfo[ $key ]           = $arrayToSave;
		}
		$updateinfo['selected_product_id']           = isset( $sanitized_array['selected_product_id'] ) ? ( $sanitized_array['selected_product_id'] ) : '';
		$updateinfo['selected_product_name']         = isset( $sanitized_array['ced_sears_pro_search_box'] ) ? ( $sanitized_array['ced_sears_pro_search_box'] ) : '';
		$updateinfo['_umb_ebay_category']['default'] = $profile_category_id;
		$updateinfo['custom_item_aspects']           = $ced_ebay_custom_item_aspects;
		$updateinfo                                  = json_encode( $updateinfo );
		if ( '' == $profileID ) {
			$ebay_categories_name = get_option( 'ced_ebay_categories' . $user_id, array() );
			$categoryIDs          = array();
			for ( $i = 1; $i <= 6; $i++ ) {
				$categoryIDs[] = isset( $sanitized_array[ 'ced_ebay_level' . $i . '_category' ] ) ? ( ( $sanitized_array[ 'ced_ebay_level' . $i . '_category' ] ) )
					: '';
			}
			$categoryName = '';
			foreach ( $categoryIDs as $index => $categoryId ) {
				foreach ( $ebay_categories_name['categories'] as $key => $value ) {
					if ( isset( $categoryId[0] ) && ! empty( $categoryId[0] ) && $categoryId[0] == $value['category_id'] ) {
						$categoryName    .= $value['category_name'] . ' --> ';
						$ebay_category_id = $value['category_id'];
					}
				}
			}
			$profile_name   = substr( $categoryName, 0, -5 );
			$profileDetails = array(
				'profile_name'   => $profile_name,
				'profile_status' => 'active',
				'profile_data'   => $updateinfo,
				'user_id'        => $user_id,
			);
			global $wpdb;
			$profileTableName = $wpdb->prefix . 'ced_ebay_profiles';

			$wpdb->insert( $profileTableName, $profileDetails );
			$profileId          = $wpdb->insert_id;
			$cat_specifics_file = $wp_upload_dir . 'ebaycat_' . $profile_category_id . '.json';
			if ( file_exists( $cat_specifics_file ) ) {
				$available_attribute = json_decode( file_get_contents( $cat_specifics_file ), true );
			}
			if ( ! is_array( $available_attribute ) ) {
				$available_attribute = array();
			}

			if ( ! empty( $available_attribute ) ) {
				$categoryAttributes = $available_attribute;
			} else {
				$ebayCategoryInstance    = CedGetCategories::get_instance( $siteID, $token );
				$categoryAttributes      = $ebayCategoryInstance->_getCatSpecifics( $profile_category_id );
				$categoryAttributes_json = json_encode( $categoryAttributes );
				$cat_specifics_file      = $wp_upload_dir . 'ebaycat_' . $profile_category_id . '.json';
				if ( file_exists( $cat_specifics_file ) ) {
					wp_delete_file( $cat_specifics_file );
				}
				file_put_contents( $cat_specifics_file, $categoryAttributes_json );
			}
			$ebayCategoryInstance = CedGetCategories::get_instance( $siteID, $token );
			$getCatFeatures       = $cedCatInstance->_getCatFeatures( $catID, $limit );
			$getCatFeatures_json  = json_encode( $getCatFeatures );
			$cat_features_file    = $wp_upload_dir . 'ebaycatfeatures_' . $profile_category_id . '.json';
			if ( file_exists( $cat_features_file ) ) {
				wp_delete_file( $cat_features_file );
			}
			file_put_contents( $cat_features_file, $getCatFeatures_json );
			$getCatFeatures   = isset( $getCatFeatures['Category'] ) ? $getCatFeatures['Category'] : false;
			$profile_edit_url = admin_url( 'admin.php?page=ced_ebay&section=profiles-view&user_id=' . $user_id . '&profileID=' . $profileId . '&panel=edit' );
			header( 'location:' . $profile_edit_url . '' );
		} elseif ( $profileID ) {

			global $wpdb;
			$tableName = $wpdb->prefix . 'ced_ebay_profiles';
			$wpdb->update(
				$tableName,
				array(
					'profile_status' => $is_active,
					'profile_data'   => $updateinfo,
					'woo_categories' => $woo_categories_mapped,
				),
				array( 'id' => $profileID )
			);

		}

		if ( '' === $wpdb->last_error ) {
			$isProfileSaved = true;
		}
	}
} else {
	if ( ! empty( $_POST ) ) {
		?>
<div class="notice notice-error">
	 <p>Unable to save the profile. It looks like you haven't assigned any WooCommerce Category.</p>
   </div>
		<?php
	}
}

global $wpdb;

$tableName = $wpdb->prefix . 'ced_ebay_profiles';

$profile_data       = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}ced_ebay_profiles WHERE `id`=%d AND `user_id`=%s", $profileID, $user_id ), 'ARRAY_A' );
$all_woo_cat_mapped = $wpdb->get_results( $wpdb->prepare( "SELECT woo_categories,id FROM {$wpdb->prefix}ced_ebay_profiles WHERE `id`!= %d AND `user_id`=%s", $profileID, $user_id ), 'ARRAY_A' );
if ( ! empty( $all_woo_cat_mapped ) && is_array( $all_woo_cat_mapped ) ) {
	$woo_categories_to_exclude       = array();
	$get_all_woo_categories_term_ids = array();
	$get_all_woo_categories_terms    = get_terms( 'product_cat', array( 'hide_empty' => false ) );
	if ( ! empty( $get_all_woo_categories_terms ) ) {
		foreach ( $get_all_woo_categories_terms as $key => $woo_cat_terms ) {
			if ( ! empty( $woo_cat_terms->term_id ) ) {
				$get_all_woo_categories_term_ids[] = $woo_cat_terms->term_id;
			}
		}
	}
	if ( ! empty( $get_all_woo_categories_term_ids ) ) {
		foreach ( $all_woo_cat_mapped as $key => $mapped_in_woo ) {
			if ( ! empty( $mapped_in_woo['woo_categories'] ) ) {
				$woo_cat_mappings_in_db = json_decode( $mapped_in_woo['woo_categories'], true );
				if ( ! empty( $woo_cat_mappings_in_db ) && is_array( $woo_cat_mappings_in_db ) ) {
					foreach ( $woo_cat_mappings_in_db as $key_1 => $woo_db_mapping ) {
						if ( ( array_search( $woo_db_mapping, $get_all_woo_categories_term_ids ) ) !== false ) {
							$woo_categories_to_exclude[] = (int) $woo_db_mapping;
						}
					}
				}
			}
		}
	}
}
if ( ! empty( $woo_categories_to_exclude ) && is_array( $woo_categories_to_exclude ) ) {
	$woo_categories_to_exclude = implode( ',', $woo_categories_to_exclude );
} else {
	$woo_categories_to_exclude = array();
}

if ( ! empty( $profile_data ) ) {
	$woo_categories        = ! empty( $profile_data[0]['woo_categories'] ) ? json_decode( $profile_data[0]['woo_categories'], true ) : false;
	$profile_category_data = json_decode( $profile_data[0]['profile_data'], true );
}
$profile_category_data = isset( $profile_category_data ) ? $profile_category_data : '';
$profile_category_id   = isset( $profile_category_data['_umb_ebay_category']['default'] ) ? $profile_category_data['_umb_ebay_category']['default'] : '';
$profile_data          = isset( $profile_data[0] ) ? $profile_data[0] : $profile_data;
$attributes            = wc_get_attribute_taxonomies();
$attrOptions           = array();
$addedMetaKeys         = get_option( 'CedUmbProfileSelectedMetaKeys', false );
$selectDropdownHTML    = '';

global $wpdb;
$results = $wpdb->get_results( "SELECT DISTINCT meta_key FROM {$wpdb->prefix}postmeta WHERE meta_key NOT LIKE '%wcf%' AND meta_key NOT LIKE '%elementor%' AND meta_key NOT LIKE '%_menu%'", 'ARRAY_A' );
foreach ( $results as $key => $meta_key ) {
	$post_meta_keys[] = $meta_key['meta_key'];
}
$custom_prd_attrb = array();
$query            = $wpdb->get_results( $wpdb->prepare( "SELECT `meta_value` FROM  {$wpdb->prefix}postmeta WHERE `meta_key` LIKE %s", '_product_attributes' ), 'ARRAY_A' );
if ( ! empty( $query ) ) {
	foreach ( $query as $key => $db_attribute_pair ) {
		foreach ( maybe_unserialize( $db_attribute_pair['meta_value'] ) as $key => $attribute_pair ) {
			if ( 1 != $attribute_pair['is_taxonomy'] ) {
				$custom_prd_attrb[] = $attribute_pair['name'];
			}
		}
	}
}
if ( $addedMetaKeys && count( $addedMetaKeys ) > 0 ) {
	foreach ( $addedMetaKeys as $metaKey ) {
		$attrOptions[ $metaKey ] = $metaKey;
	}
}
if ( ! empty( $attributes ) ) {
	foreach ( $attributes as $attributesObject ) {
		$attrOptions[ 'umb_pattr_' . $attributesObject->attribute_name ] = $attributesObject->attribute_label;
	}
}
/* select dropdown setup */
ob_start();
$fieldID  = '{{*fieldID}}';
$selectId = $fieldID . '_attibuteMeta';
// $selectDropdownHTML .= '<label>Get value from</lable>';
$selectDropdownHTML .= '<select class="ced_ebay_search_item_sepcifics_mapping" id="' . $selectId . '" name="' . $selectId . '">';
$selectDropdownHTML .= '<option value="-1">Select</option>';
$selectDropdownHTML .= '<option value="ced_product_tags">Product Tags</option>';
$selectDropdownHTML .= '<option value="ced_product_cat_single">Product Category - Last Category</option>';
$selectDropdownHTML .= '<option value="ced_product_cat_hierarchy">Product Category - Hierarchy</option>';

if ( class_exists( 'ACF' ) ) {
	$acf_fields_posts = get_posts(
		array(
			'posts_per_page' => -1,
			'post_type'      => 'acf-field',
		)
	);

	foreach ( $acf_fields_posts as $key => $acf_posts ) {
		$acf_fields[ $key ]['field_name'] = $acf_posts->post_title;
		$acf_fields[ $key ]['field_key']  = $acf_posts->post_name;
	}
}
if ( is_array( $attrOptions ) ) {
	$selectDropdownHTML .= '<optgroup label="Global Attributes">';
	foreach ( $attrOptions as $attrKey => $attrName ) :
		$selectDropdownHTML .= '<option value="' . $attrKey . '">' . $attrName . '</option>';
	endforeach;
}

if ( ! empty( $custom_prd_attrb ) ) {
	$custom_prd_attrb    = array_unique( $custom_prd_attrb );
	$selectDropdownHTML .= '<optgroup label="Custom Attributes">';
	foreach ( $custom_prd_attrb as $key => $custom_attrb ) {
		$selectDropdownHTML .= '<option value="ced_cstm_attrb_' . esc_attr( $custom_attrb ) . '">' . esc_html( $custom_attrb ) . '</option>';
	}
}

if ( ! empty( $post_meta_keys ) ) {
	$post_meta_keys      = array_unique( $post_meta_keys );
	$selectDropdownHTML .= '<optgroup label="Custom Fields">';
	foreach ( $post_meta_keys as $key => $p_meta_key ) {
		$selectDropdownHTML .= '<option value="' . $p_meta_key . '">' . $p_meta_key . '</option>';
	}
}

if ( ! empty( $acf_fields ) ) {
	$selectDropdownHTML .= '<optgroup label="ACF Fields">';
	foreach ( $acf_fields as $key => $acf_field ) :
		$selectDropdownHTML .= '<option value="acf_' . $acf_field['field_key'] . '">' . $acf_field['field_name'] . '</option>';
	endforeach;
}
$selectDropdownHTML .= '</select>';
$cat_specifics_file  = $wp_upload_dir . 'ebaycat_' . $profile_category_id . '.json';
if ( file_exists( $cat_specifics_file ) ) {
	$available_attribute = json_decode( file_get_contents( $cat_specifics_file ), true );
} else {
	$available_attribute = array();
}
if ( ! empty( $available_attribute ) ) {
	$categoryAttributes = $available_attribute;
} else {
	$ebayCategoryInstance    = CedGetCategories::get_instance( $siteID, $token );
	$categoryAttributes      = $ebayCategoryInstance->_getCatSpecifics( $profile_category_id );
	$categoryAttributes_json = json_encode( $categoryAttributes );
	$cat_specifics_file      = $wp_upload_dir . 'ebaycat_' . $profile_category_id . '.json';
	if ( file_exists( $cat_specifics_file ) ) {
		wp_delete_file( $cat_specifics_file );
	}
	file_put_contents( $cat_specifics_file, $categoryAttributes_json );
}
$ebayCategoryInstance = CedGetCategories::get_instance( $siteID, $token );
$limit                = array( 'ConditionEnabled', 'ConditionValues' );
$getCatFeatures       = $ebayCategoryInstance->_getCatFeatures( $profile_category_id, array() );
$getCatFeatures_json  = json_encode( $getCatFeatures );
$cat_features_file    = $wp_upload_dir . 'ebaycatfeatures_' . $profile_category_id . '.json';
if ( file_exists( $cat_features_file ) ) {
	wp_delete_file( $cat_features_file );
}
file_put_contents( $cat_features_file, $getCatFeatures_json );
$getCatFeatures = isset( $getCatFeatures['Category'] ) ? $getCatFeatures['Category'] : false;
$attribute_data = array();


$productFieldInstance = CedeBayProductsFields::get_instance();
$fields               = $productFieldInstance->ced_ebay_get_custom_products_fields( $profile_category_id );


$woo_store_categories = get_terms( 'product_cat' );
$user_id              = isset( $_GET['user_id'] ) ? sanitize_text_field( $_GET['user_id'] ) : '';


?>
<form action="" method="post">
	<div class="ced_ebay_profile_details_wrapper">
		<div class="ced_ebay_profile_details_fields">
			<table>
				<thead>
				<div class="ced-ebay-v2-header">
			<div class="ced-ebay-v2-logo">
			<img src="<?php echo esc_attr( CED_EBAY_URL ) . 'admin/images/icon-100X100.png'; ?>">
			</div>
			<div class="ced-ebay-v2-header-content">
				<div class="ced-ebay-v2-title">

					<h2 style="font-size:18px;"><b><?php echo esc_attr_e( $profile_data['profile_name'] ); ?></h2>
				</div>
				<div class="ced-ebay-v2-actions">
					<?php
					if ( ! empty( $woo_categories ) && is_array( $woo_categories ) ) {
						?>
				<a class="ced-ebay-v2-btn" target="_blank" href="<?php echo esc_attr( admin_url( 'admin.php?page=ced_ebay&section=products-view&user_id=' . $user_id . '&profileID=' . $profileID ) ); ?>">
					Show Products				</a>
						<?php
					}
					?>
				<a class="ced-ebay-v2-btn" href="<?php echo esc_attr( admin_url( 'admin.php?page=ced_ebay&section=profiles-view&user_id=' . $user_id ) ); ?>">
					Go Back					</a>
				<a class="ced-ebay-v2-btn" href="https://docs.woocommerce.com/document/ebay-integration-for-woocommerce/#section-8" target="_blank">
					Documentation					</a>

			</div>
		</div>
</div>
<?php
if ( $isProfileSaved ) {
	?>
<div class="notice notice-success">
	 <p> We’ve saved your profile data. </p>
   </div>
   <!-- End Alert Success -->


   </div>
   </div>
	<?php
}
?>
				</thead>
				<tbody>

<th colspan="3" class="px-4 mt-4 py-6 sm:p-6 border-t-2 border-green-500" style="text-align:left;margin:0;">

<label style="font-size: 1.25rem;color: #6574cd;" ><?php esc_attr_e( 'GENERAL DETAILS', 'ebay-integration-for-woocommerce' ); ?></label>

</th>

<tr class="form-field _umb_id_type_field ">
<input type="hidden" name="ced_ebay_required_common[]" value="_umb_ebay_mapped_woocommerce_category">
<td>
				<label class="ced_ebay_show_tippy" data-tippy-content="Add/Remove the WooCommerce categories associated with this profile.">Assigned WooCommerce Category</label>
			</td>
	<td>
	<?php
	$dropdown_cat_args      = array(
		'name'              => 'ced_ebay_profile_edit_category_dropdown[]',
		'id'                => 'ced_ebay_profile_edit_category_dropdown_select',
		'class'             => 'select2 form-control',
		'show_count'        => 1,
		'hierarchical'      => 1,
		'depth'             => 10,
		'option_none_value' => '-1',
		'selected'          => false,
		'hide_empty'        => false,
		'taxonomy'          => 'product_cat',
		'echo'              => 0,
		'exclude'           => $woo_categories_to_exclude,
	);
	$dropdown               = wp_dropdown_categories( $dropdown_cat_args );
	$multi                  = str_replace( '<select', '<select multiple ', $dropdown );
	$multi_dropdown         = preg_replace( '#class *= *["\']?([^"\']*)"#', '', $multi );
	$already_mapped_woo_cat = $woo_categories;
	if ( null !== $multi_dropdown ) {
		foreach ( $already_mapped_woo_cat as $key => $mapped_woo_cat ) {
			// add the selected to each selected value
			$multi_dropdown = str_replace(
				'<option  value="' . esc_attr( $mapped_woo_cat ) . '"',
				'<option value="' . esc_attr( $mapped_woo_cat ) . '" selected="selected"',
				$multi_dropdown
			);
		}
	}
	print_r( $multi_dropdown );






	?>
	</td>
</tr>
					<?php
					$requiredInAnyCase = array( '_umb_id_type', '_umb_id_val', '_umb_brand' );
					global $global_CED_ebay_Render_Attributes;
					$marketPlace        = 'ced_ebay_required_common';
					$productID          = 0;
					$categoryID         = '';
					$indexToUse         = 0;
					$selectDropdownHTML = $selectDropdownHTML;
					?>


						<?php
						if ( ! empty( $profile_data ) ) {
							$data = json_decode( $profile_data['profile_data'], true );
						}
						foreach ( $fields as $value ) {
							$isText   = false;
							$field_id = trim( $value['fields']['id'], '_' );
							if ( in_array( $value['fields']['id'], $requiredInAnyCase ) ) {
								$attributeNameToRender  = ucfirst( $value['fields']['label'] );
								$attributeNameToRender .= '<span class="ced_ebay_wal_required">' . __( '[ Required ]', 'ebay-integration-for-woocommerce' ) . '</span>';
							} else {
								$attributeNameToRender = ucfirst( $value['fields']['label'] );
							}
							$default           = isset( $data[ $value['fields']['id'] ]['default'] ) ? $data[ $value['fields']['id'] ]['default'] : '';
							$field_description = ! empty( $value['fields']['description'] ) ? $value['fields']['description'] : '';
							echo '<tr class="form-field _umb_id_type_field ">';

							if ( '_select' == $value['type'] ) {
								$valueForDropdown = $value['fields']['options'];
								if ( '_umb_id_type' == $value['fields']['id'] ) {
									unset( $valueForDropdown['null'] );
								}
								$productFieldInstance->renderDropdownHTML(
									$field_id,
									$attributeNameToRender,
									$valueForDropdown,
									$categoryID,
									$productID,
									$marketPlace,
									$indexToUse,
									array(
										'case'  => 'profile',
										'value' => $default,
									),
									'',
									'SINGLE',
									$field_description
								);
								$isText = false;
							} elseif ( '_text_input' == $value['type'] ) {
								$productFieldInstance->renderInputTextHTML(
									$field_id,
									$attributeNameToRender,
									$categoryID,
									$productID,
									$marketPlace,
									$indexToUse,
									array(
										'case'  => 'profile',
										'value' => $default,
									),
									false,
									'SINGLE',
									$field_description
								);
								$isText = true;
							} elseif ( '_hidden' == $value['type'] ) {
								$productFieldInstance->renderInputTextHTMLhidden(
									$field_id,
									$attributeNameToRender,
									$categoryID,
									$productID,
									$marketPlace,
									$indexToUse,
									array(
										'case'  => 'profile',
										'value' => $profile_category_id,
									),
									false,
									$field_description
								);
								$isText = false;
							} else {
								$isText = false;
							}

							echo '<td>';
							if ( $isText ) {
								$previousSelectedValue = 'null';
								if ( isset( $data[ $value['fields']['id'] ]['metakey'] ) && 'null' != $data[ $value['fields']['id'] ]['metakey'] ) {
									$previousSelectedValue = $data[ $value['fields']['id'] ]['metakey'];
								}
								$updatedDropdownHTML = str_replace( '{{*fieldID}}', $value['fields']['id'], $selectDropdownHTML );
								$updatedDropdownHTML = str_replace( 'value="' . $previousSelectedValue . '"', 'value="' . $previousSelectedValue . '" selected="selected"', $updatedDropdownHTML );
								print_r( $updatedDropdownHTML );
							}
							echo '</td>';
							echo '</tr>';
						}
						?>
						<th colspan="3" class="px-4 mt-4 py-6 sm:p-6 border-t-2 border-green-500" style="text-align:left;margin:0;">

						<label style="font-size: 1.25rem;color: #6574cd;" ><?php esc_attr_e( 'ITEM ASPECTS', 'ebay-integration-for-woocommerce' ); ?></label>
						<p style="font-size:16px;text-style:none;">Specify additional details about products listed on eBay based on the selected eBay Category.</p>
						<p style="font-size:14px;"><span style="color:red;">[Required]</span> - Filling or mapping fields with this tag is REQUIRED for successfully listing a product on eBay.</p>
						<p style="font-size:14px;"><span style="color:green;">[Multiple]</span> - For such fields, you can specify multiple comma-separated values.</p>

						</th>

					<?php
					if ( ! empty( $categoryAttributes ) ) {
						if ( ! empty( $profile_data ) ) {
							$data = json_decode( $profile_data['profile_data'], true );
						}
						foreach ( $categoryAttributes as $key1 => $value ) {
							$isText   = true;
							$field_id = trim( urlencode( $value['localizedAspectName'] ) );
							$default  = isset( $data[ $profile_category_id . '_' . $field_id ] ) ? $data[ $profile_category_id . '_' . $field_id ] : '';
							$default  = isset( $default['default'] ) ? $default['default'] : '';
							$required = '';
							echo '<tr class="form-field _umb_brand_field ">';

							if ( 'SELECTION_ONLY' == $value['aspectConstraint']['aspectMode'] ) {
								$cardinality          = 'SINGLE';
								$valueForDropdown     = $value['aspectValues'];
								$tempValueForDropdown = array();
								foreach ( $valueForDropdown as $key => $_value ) {
									$tempValueForDropdown[ $_value['localizedValue'] ] = $_value['localizedValue'];
								}
								$valueForDropdown = $tempValueForDropdown;

								if ( 'MULTI' == $value['aspectConstraint']['itemToAspectCardinality'] ) {
									$cardinality = 'MULTI';
								}
								if ( 'true' == $value['aspectConstraint']['aspectRequired'] ) {
									$required = 'required';
								}

								$productFieldInstance->renderDropdownHTML(
									$field_id,
									ucfirst( $value['localizedAspectName'] ),
									$valueForDropdown,
									$profile_category_id,
									$productID,
									$marketPlace,
									$indexToUse,
									array(
										'case'  => 'profile',
										'value' => $default,
									),
									$required,
									$cardinality
								);
								$isText = false;
							} elseif ( 'COMBO_BOX' == isset( $value['input_type'] ) ? $value['input_type'] : '' ) {
								$cardinality = 'SINGLE';
								$isText      = true;
								if ( 'true' == $value['aspectConstraint']['aspectRequired'] ) {
									$required = 'required';
								}
								if ( 'MULTI' == $value['aspectConstraint']['itemToAspectCardinality'] ) {
									$cardinality = 'MULTI';
								}
								$productFieldInstance->renderInputTextHTML(
									$field_id,
									ucfirst( $value['localizedAspectName'] ),
									$profile_category_id,
									$productID,
									$marketPlace,
									$indexToUse,
									array(
										'case'  => 'profile',
										'value' => $default,
									),
									$required,
									$cardinality
								);
							} elseif ( 'text' == isset( $value['input_type'] ) ? $value['input_type'] : '' ) {
								$cardinality = 'SINGLE';
								$isText      = true;
								if ( 'true' == $value['aspectConstraint']['aspectRequired'] ) {
									$required = 'required';
								}
								if ( 'MULTI' == $value['aspectConstraint']['itemToAspectCardinality'] ) {
									$cardinality = 'MULTI';
								}
								$productFieldInstance->renderInputTextHTML(
									$field_id,
									ucfirst( $value['localizedAspectName'] ),
									$profile_category_id,
									$productID,
									$marketPlace,
									$indexToUse,
									array(
										'case'  => 'profile',
										'value' => $default,
									),
									$required,
									$cardinality
								);
							} else {
								$cardinality = 'SINGLE';
								$isText      = true;
								if ( 'true' == $value['aspectConstraint']['aspectRequired'] ) {
									$required = 'required';
								}
								if ( 'MULTI' == $value['aspectConstraint']['itemToAspectCardinality'] ) {
									$cardinality = 'MULTI';
								}
								$productFieldInstance->renderInputTextHTML(
									$field_id,
									ucfirst( $value['localizedAspectName'] ),
									$profile_category_id,
									$productID,
									$marketPlace,
									$indexToUse,
									array(
										'case'  => 'profile',
										'value' => $default,
									),
									$required,
									$cardinality
								);
							}


							echo '<td>';
							if ( $isText ) {
								$previousSelectedValue = 'null';
								if ( isset( $data[ $profile_category_id . '_' . $field_id ] ) && 'null' != $data[ $profile_category_id . '_' . $field_id ] ) {

									$previousSelectedValue = $data[ $profile_category_id . '_' . $field_id ]['metakey'];
								}
								$updatedDropdownHTML = str_replace( '{{*fieldID}}', $profile_category_id . '_' . $field_id, $selectDropdownHTML );
								$updatedDropdownHTML = str_replace( 'value="' . $previousSelectedValue . '"', 'value="' . $previousSelectedValue . '" selected="selected"', $updatedDropdownHTML );
								print_r( $updatedDropdownHTML );
							}
							echo '</td>';


							echo '</tr>';
						}
					}
					if ( $getCatFeatures ) {
						if ( isset( $getCatFeatures['ConditionValues'] ) ) {
							$field_id             = 'Condition';
							$isText               = true;
							$valueForDropdown     = $getCatFeatures['ConditionValues']['Condition'];
							$tempValueForDropdown = array();
							if ( isset( $valueForDropdown[0] ) ) {
								foreach ( $valueForDropdown as $key => $value ) {
									$tempValueForDropdown[ $value['ID'] ] = $value['DisplayName'];
								}
							} else {
								$tempValueForDropdown[ $valueForDropdown['ID'] ] = $valueForDropdown['DisplayName'];
							}
							$valueForDropdown = $tempValueForDropdown;
							$name             = 'Condition';
							$default          = isset( $profile_category_data[ $profile_category_id . '_' . $name ] ) ? $profile_category_data[ $profile_category_id . '_' . $name ] : '';
							$default          = isset( $default['default'] ) ? $default['default'] : '';
							if ( 'Enabled' == $getCatFeatures['ConditionEnabled'] || 'Required' == $getCatFeatures['ConditionEnabled'] ) {
								$required                                       = true;
								$catFeatureSavingForvalidation[ $categoryID ][] = 'Condition';
							}
							$productFieldInstance->renderDropdownHTML(
								'Condition',
								$name,
								$valueForDropdown,
								$profile_category_id,
								$productID,
								$marketPlace,
								$indexToUse,
								array(
									'case'  => 'profile',
									'value' => $default,
								),
								$required
							);
						}

						echo '<td>';
						if ( $isText ) {
							$previousSelectedValue = 'null';
							if ( isset( $data[ $profile_category_id . '_' . $field_id ] ) && 'null' != $data[ $profile_category_id . '_' . $field_id ] ) {

								$previousSelectedValue = $data[ $profile_category_id . '_' . $field_id ]['metakey'];
							}
							$updatedDropdownHTML = str_replace( '{{*fieldID}}', $profile_category_id . '_' . $field_id, $selectDropdownHTML );
							$updatedDropdownHTML = str_replace( 'value="' . $previousSelectedValue . '"', 'value="' . $previousSelectedValue . '" selected="selected"', $updatedDropdownHTML );
							print_r( $updatedDropdownHTML );
						}
							echo '</td>';


							echo '</tr>';


					}

						require_once CED_EBAY_DIRPATH . 'admin/ebay/lib/ebayProfileSections.php';

						$profileInstance = new Ebayprofiles( $user_id );
						$profileInstance->prepareCustomItemAspects( $profile_category_id, $data );

					?>

						<tr>
							<th colspan="3" class="px-4 mt-4 py-6 sm:p-6 border-t-2 border-green-500" style="text-align:left;margin:0;">
							<label style="font-size: 1.25rem;color: #6574cd;" ><?php esc_attr_e( 'FRAMEWORK SPECIFIC', 'ebay-integration-for-woocommerce' ); ?></label>
							<p style="font-size:16px;">Specify additional details about products listed on eBay based on the selected eBay Category.
							You can only set the values of <span style="color:red;">[Required]</span> Item Aspects and leave other fields in this section.
							To do so, either enter a custom value or get the values from Product Attributes or Custom Fields.</p>
							</th>
						</tr>
						<?php
						if ( ! empty( $profile_data ) ) {
							$data = json_decode( $profile_data['profile_data'], true );
						}
						$productFieldInstance = CedeBayProductsFields::get_instance();
						$fields               = $productFieldInstance->ced_ebay_get_profile_framework_specific( $profile_category_id );

						foreach ( $fields as $value ) {
							$isText   = false;
							$field_id = trim( $value['fields']['id'], '_' );
							if ( in_array( $value['fields']['id'], $requiredInAnyCase ) ) {
								$attributeNameToRender  = ucfirst( $value['fields']['label'] );
								$attributeNameToRender .= '<span class="ced_ebay_wal_required">' . __( '[ Required ]', 'ebay-integration-for-woocommerce' ) . '</span>';
							} else {
								$attributeNameToRender = ucfirst( $value['fields']['label'] );
							}
							$default           = isset( $data[ $value['fields']['id'] ]['default'] ) ? $data[ $value['fields']['id'] ]['default'] : '';
							$field_description = ! empty( $value['fields']['description'] ) ? $value['fields']['description'] : '';
							$required          = isset( $value['required'] ) ? $value['required'] : '';
							echo '<tr class="form-field _umb_id_type_field ">';

							if ( '_select' == $value['type'] ) {
								$valueForDropdown = $value['fields']['options'];
								if ( '_umb_id_type' == $value['fields']['id'] ) {
									unset( $valueForDropdown['null'] );
								}
								$productFieldInstance->renderDropdownHTML(
									$field_id,
									$attributeNameToRender,
									$valueForDropdown,
									$categoryID,
									$productID,
									$marketPlace,
									$indexToUse,
									array(
										'case'  => 'profile',
										'value' => $default,
									),
									$required,
									'SINGLE',
									$field_description
								);
								$isText = false;
							} elseif ( '_text_input' == $value['type'] ) {
								$productFieldInstance->renderInputTextHTML(
									$field_id,
									$attributeNameToRender,
									$categoryID,
									$productID,
									$marketPlace,
									$indexToUse,
									array(
										'case'  => 'profile',
										'value' => $default,
									),
									$required,
									'SINGLE',
									$field_description
								);
								$isText = true;
							} elseif ( '_hidden' == $value['type'] ) {
								$productFieldInstance->renderInputTextHTMLhidden(
									$field_id,
									$attributeNameToRender,
									$categoryID,
									$productID,
									$marketPlace,
									$indexToUse,
									array(
										'case'  => 'profile',
										'value' => $profile_category_id,
									),
									'',
									'SINGLE',
									$field_description
								);
								$isText = false;
							} else {
								$isText = false;
							}

							echo '<td>';
							if ( $isText ) {
								$previousSelectedValue = 'null';
								if ( isset( $data[ $value['fields']['id'] ]['metakey'] ) && 'null' != $data[ $value['fields']['id'] ]['metakey'] ) {
									$previousSelectedValue = $data[ $value['fields']['id'] ]['metakey'];
								}
								$updatedDropdownHTML = str_replace( '{{*fieldID}}', $value['fields']['id'], $selectDropdownHTML );
								$updatedDropdownHTML = str_replace( 'value="' . $previousSelectedValue . '"', 'value="' . $previousSelectedValue . '" selected="selected"', $updatedDropdownHTML );
								print_r( $updatedDropdownHTML );
							}
							echo '</td>';
							echo '</tr>';
						}
						?>
					</tr>
				</tbody>

			</table>
			<button style="margin:50px 5px;" class="ced-ebay-v2-btn" name="ced_ebay_profile_save_button" ><?php esc_attr_e( 'Save Profile Data', 'ebay-integration-for-woocommerce' ); ?></button>

		</div>
	</div>
	<?php wp_nonce_field( 'ced_ebay_profile_edit_page_nonce', 'ced_ebay_profile_edit' ); ?>
</form>

<script>
						
	jQuery(".ced_ebay_search_item_sepcifics_mapping").selectWoo( {
		width: '90%',
		dropdownPosition: 'below',
		dropdownAutoWidth : false,
		placeholder: 'Select...',
		
	});
	
	jQuery(".ced_ebay_item_specifics_options").selectWoo({
		width: '90%',
		allowClear: true,
		dropdownPosition: 'below',
		dropdownAutoWidth : false,
		placeholder: 'Select...',
	});


	jQuery("#ced_ebay_profile_edit_category_dropdown_select").selectWoo({
		allowClear: true,
	});

	tippy('.ced_ebay_show_tippy', {
		arrow: true
	});

   // jQuery('.ced_ebay_fill_custom_value').selectWoo();
	
	jQuery(".js-example-tags").select2({
	  tags: true
	});



	jQuery(".test").selectWoo({
		width: '90%',
		// height:'40px',
		tags: true,
		allowClear: true, //
		closeOnSelect: true,
	});

	jQuery('.test').on("select2:select", function(e) { 
		e.preventDefault();
		let id = jQuery(this).attr('id');
		let sibling = jQuery('#' + id).next(); 

		let field = sibling.find('.select2-search__field');
		
		jQuery("li[aria-selected='true']").addClass("customclass");
		jQuery("li[aria-selected='false']").removeClass("customclass");
		jQuery('.select2-search-choice:not(.my-custom-css)', this).addClass('my-custom-css');
		jQuery(field).val("");
		
	});

	jQuery(".test").on("select2:unselect", function(e) { 

		jQuery("li[aria-selected='false']").removeClass("customclass");
	});

</script>


<style>

.short{
	padding: 5px;
	border: 1px solid #c7c7c7;
	height: 40px;
	width: 90% !important;
}

.ced_ebay_add_custom_item_aspect_heading{
	text-align: left;
}

.selectRow {
	display : block;
	padding : 20px;
}
.select2-container {
	width: 200px;
}

.customclass{
  color:grey;
}
</style>

