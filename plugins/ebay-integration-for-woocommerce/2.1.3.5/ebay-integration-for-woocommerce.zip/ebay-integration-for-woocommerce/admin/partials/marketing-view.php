<?php
if ( ! defined( 'ABSPATH' ) ) {
	die;
}
if ( empty( get_option( 'ced_ebay_user_access_token' ) ) ) {
	wp_redirect( get_admin_url() . 'admin.php?page=ced_ebay' );
}
$file = CED_EBAY_DIRPATH . 'admin/partials/header.php';
if ( file_exists( $file ) ) {
	require_once $file;
}

if ( ! class_exists( 'Ced_Ebay_Marketing_View' ) ) {
	class Ced_Ebay_Marketing_View {


		public function ced_ebay_renderMarketingViewHTML() {
			$user_id                    = isset( $_GET['user_id'] ) ? sanitize_text_field( $_GET['user_id'] ) : '';
			$renderDataOnGlobalSettings = get_option( 'ced_ebay_global_settings', false );
			$ad_campaign                = isset( $renderDataOnGlobalSettings[ $user_id ]['ced_ebay_ad_campaigns'] ) ? $renderDataOnGlobalSettings[ $user_id ]['ced_ebay_ad_campaigns'] : '';
			$ad_campaigns               = get_option( 'ced_ebay_ad_campaigns' );
			$ad_bid_percentage          = isset( $renderDataOnGlobalSettings[ $user_id ]['ced_ebay_product_ad_bid_percentage'] ) ? $renderDataOnGlobalSettings[ $user_id ]['ced_ebay_product_ad_bid_percentage'] : '';

			// (get_transient('feed_9bbd59226dc36b9b26cd43f15694c5c3'))
			// (get_transient('ced_ebay_user_access_token_' . $user_id))
			if ( get_transient( 'ced_ebay_user_access_token_' . $user_id ) ) {
				?>

<div class='ced_ebay_marketing-view-container'>
  <h1 class="ced_ebay_marketing_welcome_text">
	Welcome, <?php echo esc_attr( $user_id ); ?>!
  </h1>
  <p>
	You can use this section to manage your eBay product promotions.
  </p>
  <div class="button-container">


	<ul style="display:block;">
	  <li style="display:inline-block;">
		<div class='button -blue center' id="get_marketing_campaigns">Get Campaigns</div>

	  </li>
	  <li style="display:inline-block;">

		<div class='button -blue center' id="ced_ebay_fetch_marketplace_promotions">Get Promotions</div>

	  </li>
	</ul>

  </div>

  <div class="ced_ebay_marketing_data_grids">
	<!--start of flex grids-->

	<div class="ced_ebay_marketing_data_text">
	  <!--start of flex item-->
				<?php
				if ( is_array( get_option( 'ced_ebay_ad_campaigns' ) ) ) {
					if ( $ad_campaigns[ $user_id ]->total > 0 ) {
						?>
						<?php echo '<h1>' . esc_attr( $ad_campaigns[ $user_id ]->total ) . '</h1>'; ?>
	  <h2>Total Campaigns</h2>
						<?php
					} else {
						?>
						<?php echo '<h1>0</h1>'; ?>
	  <h2>Total Campaigns</h2>
						<?php
					}
				}
				?>
	</div>
	<!--end of flex item-->

				<?php
				if ( is_array( get_option( 'ced_ebay_marketplace_promotions' ) ) ) {
					?>
	<div class="ced_ebay_marketing_data_text">
	  <!--start of flex item-->
					  <?php
						$marketplacePromotions = get_option( 'ced_ebay_marketplace_promotions' );
						if ( $marketplacePromotions[ $user_id ]->total > 0 ) {
							echo '<h1>' . esc_attr( $marketplacePromotions[ $user_id ]->total ) . '</h1>';
							?>
	  <h2>Total Promotions</h2>
							<?php
						} else {
							?>
							<?php echo '<h1>' . esc_attr( 0 ) . '</h1>'; ?>
	  <h2>Total Promotions</h2>
	</div>
	<!--end of flex item-->
							<?php
						}
				}

				?>
</div>  <!--end of flex grids-->

</div> <!--end of container-->
<div class="ced-ebay-v2-header">
			<div class="ced-ebay-v2-logo">
			<img src="<?php echo esc_attr( CED_EBAY_URL ) . 'admin/images/icon-100X100.png'; ?>">
			</div>
			<div class="ced-ebay-v2-header-content">
				<div class="ced-ebay-v2-title">
					<h1 style="font-size:2em;">Promoted Listing Campaigns</h1>
				</div>

		</div>
</div>

<div style="max-width: 750px;margin: 0 auto;margin-top:20px;position:relative;">
<h3 style="text-align:center;">Create a Campaign</h3>
<p style="text-align:center;margin-bottom:20px;">Use the below form to create a campaign for your eBay Listings. Once the campaign has been successfully created, you can use the "Get Campaigns" button above to fetch the new campaign.
</p>
<p style="text-align:center;margin-bottom:20px;margin-top:20px;color:red;" class="showCreateCampaignErrors">

</p>

   <div class="ced-ebay-form-flex-group">
	 <div class="ced-ebay-form-flex-element">
	   <input placeholder="Campaign Name" id="ced_ebay_create_campaign_name_input">
	 </div>

	 <div class="ced-ebay-form-flex-element">
	 <input type="text" id="ced_ebay_create_campaign_start_date" placeholder="Start Date" style="background-color:#fff;line-height:0px;border-radius:0px;border: 1px solid #ccc;">
	 </div>

	 <div class="ced-ebay-form-flex-element">
	   <input placeholder="Ad Rate" id="ced_ebay_create_campaign_ad_rate_input">
	 </div>

	 <!-- <div class="ced-ebay-form-flex-element">
	   <input placeholder="End Date" id="ced_ebay_create_campaign_end_date" style="background-color:#fff;line-height:0px;border-radius:0px;border: 1px solid #ccc;">
	 </div> -->
   </div>
   <div class="ced-ebay-form-flex-group">
   <div class="ced-ebay-form-flex-element">
   <a href="#" class="ced_ebay_create_campaign_action_button" style="font-size:15px;">Create</a>

	   <!-- <input type="button" value="Button" style="width:20%; left:50%; margin-top:10px; transform: translate(-50%, -50%); position:absolute;"> -->
	 </div>
   </div>
</div>


<table class="ced_ebay_campaign_list_table">
  <thead>
	<tr>
	  <th colspan="3"><h3 style="color:white;">Campaigns List</h3></th>
	</tr>
	<tr>
	  <th>Campaign ID</th>
	  <th colspan="2">Campaign</th>
	</tr>
  </thead>
  <tbody>
				<?php
				if ( is_array( get_option( 'ced_ebay_ad_campaigns' ) ) ) {
					$adCampaigns = get_option( 'ced_ebay_ad_campaigns' );
					if ( $adCampaigns[ $user_id ]->total > 0 ) {
						foreach ( $adCampaigns[ $user_id ]->campaigns as $key => $value ) {
							?>

	<tr>
	  <td><?php echo esc_html( $value->campaignId ); ?></td>
	  <td><?php echo esc_html( $value->campaignName ) . ' | ' . esc_html( $value->campaignStatus ) . ' | ' . esc_html( gmdate( 'Y-m-d', strtotime( $value->startDate ) ) ); ?></td>
	  <td>

<a data-campaign-id="<?php echo esc_attr( $value->campaignId ); ?>" id="ced_ebay_clone_campaign_action_button" data-campaign-action="clone_campaign">Clone</a>
<a data-campaign-id="<?php echo esc_attr( $value->campaignId ); ?>" id="ced_ebay_delete_campaign_action_button" data-campaign-action="delete_campaign">Delete</a>
<a data-campaign-id="<?php echo esc_attr( $value->campaignId ); ?>" id="ced_ebay_end_campaign_action_button" data-campaign-action="end_campaign">End</a>
<a data-campaign-id="<?php echo esc_attr( $value->campaignId ); ?>" id="ced_ebay_pause_campaign_action_button" data-campaign-action="pause_campaign" >Pause</a>
<a data-campaign-id="<?php echo esc_attr( $value->campaignId ); ?>" id="ced_ebay_resume_campaign_action_button" data-campaign-action="resume_campaign">Resume</a>


	  </td>
	</tr>
												<?php
						}
					}
				}
				?>


  </tbody>
</table>




</div>

</div>

<div class="ced-ebay-v2-header">
			<div class="ced-ebay-v2-logo">
			<img src="<?php echo esc_attr( CED_EBAY_URL ) . 'admin/images/icon-100X100.png'; ?>">
			</div>
			<div class="ced-ebay-v2-header-content">
				<div class="ced-ebay-v2-title">
					<h1>eBay Promotions</h1>
				</div>

		</div>
</div>

<div class="ced_ebay_promotions_table_wrapper">

  <div class="ced_ebay_promotions_table">

	<div class="ced_ebay_promotions_table_row header">
	<div class="ced_ebay_promotions_table_cell">
		Promotion ID
	  </div>
	  <div class="ced_ebay_promotions_table_cell">
		Name
	  </div>
	  <div class="ced_ebay_promotions_table_cell">
		Start Date
	  </div>
	  <div class="ced_ebay_promotions_table_cell">
		End Date
	  </div>
	  <div class="ced_ebay_promotions_table_cell">
		Promotion Status
	  </div>
	  <div class="ced_ebay_promotions_table_cell">
		Actions
	  </div>

	</div>

				<?php

				$promotions_list = get_option( 'ced_ebay_marketplace_promotions' );
				if ( ! empty( $promotions_list ) ) {
					if ( $promotions_list[ $user_id ]->total > 0 ) {
						foreach ( $promotions_list[ $user_id ]->promotions as $key => $value ) {
							?>
	<div class="ced_ebay_promotions_table_row">
	<div class="ced_ebay_promotions_table_cell" data-title="Promotion ID">
								<?php echo esc_attr( $value->promotionId ); ?>
	  </div>
	  <div class="ced_ebay_promotions_table_cell" data-title="Name">
								<?php echo esc_attr( $value->name ); ?>
	  </div>
	  <div class="ced_ebay_promotions_table_cell" data-title="Start Date">
								<?php echo esc_html( get_date_from_gmt( $value->startDate, 'F j, Y H:i:s' ) ); ?>
	  </div>
	  <div class="ced_ebay_promotions_table_cell" data-title="End Date">
								<?php echo esc_html( get_date_from_gmt( $value->endDate, 'F j, Y H:i:s' ) ); ?>
	  </div>
	  <div class="ced_ebay_promotions_table_cell" data-title="Status">
								<?php echo esc_html( $value->promotionStatus ); ?>
	  </div>
	  <div class="ced_ebay_promotions_table_cell" data-title="Actions">
								  <?php
									if ( 'RUNNING' == $value->promotionStatus ) {
										?>
				<a class="ced_ebay_promotion_action_button" id="ced_ebay_pause_promotion_button" data-promotion-id=<?php echo esc_attr( $value->promotionId ); ?>>Pause</a>
										<?php
									} elseif ( 'PAUSED' == $value->promotionStatus ) {
										?>
				<a class="ced_ebay_promotion_action_button" id="ced_ebay_resume_promotion_button" data-promotion-id=<?php echo esc_attr( $value->promotionId ); ?>>Resume</a>
										<?php
									} else {
										?>
				<p style="text-align:center;margin:0;">No actions available!</p>
										<?php
									}
									?>
	  </div>
	  </div>

							<?php
						}
					} else {
						?>
			</div>
			<p style="text-align:center">No promotions found!</p>
						<?php
					}
				}

				?>






  </div>







<div class="ced-ebay-v2-header">
			<div class="ced-ebay-v2-logo">
			<img src="<?php echo esc_attr( CED_EBAY_URL ) . 'admin/images/icon-100X100.png'; ?>">
			</div>
			<div class="ced-ebay-v2-header-content">
				<div class="ced-ebay-v2-title">
					<h1>eBay Marketing Settings</h1>
				</div>

		</div>
</div>

	  <table class="wp-list-table widefat fixed  ced_ebay_global_settings_fields_table">
	  <thead>

	  </thead>
	  <tbody>
	  <tr>

	  <th style="padding:30px;">

								<label style="font-size:16px;"><?php esc_attr_e( 'Select Ad Campaign', 'ebay-integration-for-woocommerce' ); ?></label><br>
				<span class="campaign_settings_info_header"> <b>Only Active, Running and Paused campaigns are listed for selection.
				  If you have made changes to any campaign from your seller dashboard, please use the "Get Campaigns" button above to fetch the updated list.</span>

							</th>
	  <td style="padding:30px;">
	  <select name="ced_ebay_global_settings[ced_ebay_ad_campaigns]" class="select_boxes"  id="ced_ebay_select_marketing_campaign" style="padding:0px;">
	  <option value=""><?php esc_attr_e( '--Select Campaigns--', 'ebay-integration-for-woocommerce' ); ?></option>
				<?php
				if ( $ad_campaigns[ $user_id ]->total > 0 ) {
					foreach ( $ad_campaigns[ $user_id ]->campaigns as $key => $value ) {
						if ( 'SCHEDULED' == $value->campaignStatus || 'RUNNING' == $value->campaignStatus || 'PAUSED' == $value->campaignStatus ) {
							?>
						<option
							<?php echo ( $value->campaignId == $ad_campaign ) ? 'selected' : ''; ?> value="<?php echo esc_attr_e( $value->campaignId ); ?>"
			data-campaign-id="<?php echo esc_attr( $value->campaignId ); ?>" data-bid-percentage="<?php echo esc_attr_e( $value->fundingStrategy->bidPercentage ); ?>"><?php esc_attr_e( $value->campaignName ); ?></option>
							<?php
						}
					}
				} else {
					echo 'No campaigns found';
				}
				?>

	  </td>
	  </tr>
	  <tr>
	  <th style="padding:30px;">
	  <label style="font-size:16px;"><?php esc_attr_e( 'Global Ad Rate', 'ebay-integration-for-woocommerce' ); ?></label><br>
	  <span class="campaign_settings_info_header"> <b>Enter the Ad Rate which eBay will use to increase the visibility in search results for the associated listing.</span>
	  </th>
	  <td style="padding:30px;">
	  <input placeholder="<?php esc_attr_e( 'Enter Ad Rate', 'ebay-integration-for-woocommerce' ); ?>" class="ced_ebay_disabled_text_field ced_ebay_inputs" type="number" value="<?php echo esc_attr( $ad_bid_percentage ); ?>" id="ced_ebay_campaign_bid_percentage" name="ced_ebay_global_settings[ced_ebay_campaign_bid_percentage]" min=10 max=80></input>
	  </td>
	  </tr>

	  </tbody>
</table>
<div align="right">

			<button id="save_marketing_campaign_global_settings"  name="marketing_campaign_global_settings" class="ced_ebay_custom_button profile_button" ><?php esc_attr_e( 'Save', 'ebay-integration-for-woocommerce' ); ?></button>
		</div>
	<!-- <div class="ced_ebay_setting_header ">
<h2 style="text-align:left;">eBay Promoted Listings</h2>
<br><p>Use this section to view info about the Promoted Listings.</p>
				<label class="manage_labels"><b></b><span class="spinner"></span></label>
			</div>

<div class="ced_ebay_ad_listing_table">
  <table>
  <thead>
	<tr>
	  <th>eBay Listing ID</th>
	  <th>Product Name</th>
	  <th>Recommended  Ad Rate</th>
	  <th>Current Ad Rate</th>

	</tr>
  </thead>
  <tbody>
	<tr>

	</tr>

  </tbody>
</table> -->

  </div>
				<?php

			} else {
				?>
  <div class='ced_ebay_marketing-view-container'>
	<div class="ced-ebay-v2-title">
	<h1 style="text-align:center;">
	  eBay Product Promotion
	</h1>
	</div>

	<p>
	  To create and manage product promotions using eBay Marketing API please login first using the button below.
	</p>

	<div class="button-container">
	  <div class='button -blue center' id="ced_ebay_marketing_do_login">Login</div>

	</div>
				<?php
			}
			?>

  </div>



</div>
<div id="ced_ebay_clone_campaign_dialog" >
<form id="ced_ebay_clone_campaign_form" title="Clone A Campaign">
<p>Use the below form to clone an Ended Campaign.</p>

<p class="validateTips">All form fields are required.</p>

	<fieldset>
	  <label for="ced_ebay_clone_campaign_name" style="display:block;">Campaign Name</label>
	  <input type="text" name="ced_ebay_clone_campaign_name" id="ced_ebay_clone_campaign_name" class="text ui-widget-content ui-corner-all" style="display:block;" required>
	  <label for="ced_ebay_clone_campaign_ad_rate" style="display:block;">Ad Rate</label>
	  <input type="number" name="ced_ebay_clone_campaign_ad_rate" id="ced_ebay_clone_campaign_ad_rate" class="text ui-widget-content ui-corner-all" style="display:block;" required>
	  <label for="ced_ebay_clone_campaign_start_date" style="display:block;">Campaign Start Date</label>
	  <input type="text" name="ced_ebay_clone_campaign_start_date" id="ced_ebay_clone_campaign_start_date" style="display:block;">
	  <label for="ced_ebay_clone_campaign_end_date" style="display:block;">Campaign End Date</label>
	  <input type="text" name="ced_ebay_clone_campaign_end_date" id="ced_ebay_clone_campaign_end_date" style="display:block;">
	  <label for="ced_ebay_clone_funding_model" style="display:block;">Funding Model</label>
	  <select name="ced_ebay_clone_funding_model" id="ced_ebay_clone_funding_model" required style="display:block;">
		<option value="">Select Funding Model</option>
		<option value="COST_PER_SALE">COST_PER_SALE</option>
	  </select>

	  <!-- Allow form submission with keyboard without duplicating the dialog button -->
	  <input type="submit" tabindex="-1" style="position:absolute; top:-1000px">
	</fieldset>
  </form>
</div>
			<?php

		}
	}
}
$obj = new Ced_Ebay_Marketing_View();
$obj->ced_ebay_renderMarketingViewHTML();
?>
