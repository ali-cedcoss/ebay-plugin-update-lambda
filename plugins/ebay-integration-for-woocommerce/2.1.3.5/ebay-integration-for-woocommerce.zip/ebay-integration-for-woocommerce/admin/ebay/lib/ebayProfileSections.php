<?php
if ( ! class_exists( 'Ebayprofiles' ) ) {
	class Ebayprofiles {

		/**
		 * The ID of this plugin.
		 *
		 * @since    1.0.0
		 * @var      string    $user_id
		 * @var      string    $siteID
		 * @var      string    $getLocation
		 * @var      string    $token
		 * @var      string    $wp_upload_dir
		 * @var      string    $is_setup_wizard
		 * @var      string    $productFieldInstance
		 * @var      string    $ebayCategoryInstance
		 * @var      string    $adminInstance
		 */
		public $user_id;
		public $siteID;
		public $getLocation;
		public $token;
		public $wp_upload_dir;
		public $is_setup_wizard;
		public $productFieldInstance;
		public $ebayCategoryInstance;
		public $adminInstance;


		/**
		 * Constructor
		 */
		public function __construct( $user_id ) {

			$this->user_id         = $user_id;
			$this->is_setup_wizard = 'no';
			// if ( empty( $this->user_id ) ) {
			// $this->user_id         = isset( $_POST['userid'] ) ? sanitize_text_field( $_POST['userid'] ) : '';
			// $this->is_setup_wizard = isset( $_POST['is_setup_wizard'] ) ? sanitize_text_field( $_POST['is_setup_wizard'] ) : '';
			// }
			$shop_data = ced_ebay_get_shop_data( $this->user_id );
			if ( ! empty( $shop_data ) ) {
				$this->siteID      = $shop_data['site_id'];
				$this->token       = $shop_data['access_token'];
				$this->getLocation = $shop_data['location'];
			}

			$wp_folder     = wp_upload_dir();
			$wp_upload_dir = $wp_folder['basedir'];

			if ( ! is_dir( $wp_upload_dir ) ) {
				wp_mkdir_p( $wp_upload_dir, 0777 );
			}

			$this->wp_upload_dir = $wp_upload_dir . '/ced-ebay/category-specifics/' . $this->user_id . '/';
			$this->loadDependency();

		}

		public function loadDependency() {

			$fileCategory = CED_EBAY_DIRPATH . 'admin/ebay/lib/cedGetcategories.php';
			$fileFields   = CED_EBAY_DIRPATH . 'admin/partials/products_fields.php';
			$adminFile    = CED_EBAY_DIRPATH . 'admin/class-woocommerce-ebay-integration-admin.php';

			if ( file_exists( $fileCategory ) ) {
				require_once $fileCategory;
			}
			if ( file_exists( $fileFields ) ) {
				require_once $fileFields;
			}
			if ( file_exists( $adminFile ) ) {
				require_once $adminFile;
			}

		}


		public function prepareItemAspects( $profile_category_id, $profile_data, $section ) {

			$cat_specifics_file = $this->wp_upload_dir . 'ebaycat_' . $profile_category_id . '.json';
			if ( file_exists( $cat_specifics_file ) ) {
				$available_attribute = json_decode( file_get_contents( $cat_specifics_file ), true );
			} else {
				$available_attribute = array();
			}

			if ( ! empty( $available_attribute ) ) {
				$categoryAttributes = $available_attribute;
			} else {

				$this->ebayCategoryInstance = CedGetCategories::get_instance( $this->siteID, $this->token );
				$categoryAttributes         = $this->ebayCategoryInstance->_getCatSpecifics( $profile_category_id );
				$categoryAttributes_json    = json_encode( $categoryAttributes );
				$cat_specifics_file         = $this->wp_upload_dir . 'ebaycat_' . $profile_category_id . '.json';
				if ( file_exists( $cat_specifics_file ) ) {
					wp_delete_file( $cat_specifics_file );
				}
				file_put_contents( $cat_specifics_file, $categoryAttributes_json );
			}

			$this->productFieldInstance = CedeBayProductsFields::get_instance();
			// $fields    = $this->productFieldInstance->ced_ebay_get_custom_products_fields( $profile_category_id );
			// print_r($categoryAttributes);

			?>

			<th colspan="3" class="ced_ebay_green_border" >	
				<label style="font-size: 1.25rem;color: #6574cd;" ><?php esc_attr_e( 'ITEM ASPECTS', 'ebay-integration-for-woocommerce' ); ?></label>
				<p style="font-size:16px;text-style:none;">Specify additional details about products listed on eBay based on the selected eBay Category.
				You can only set the values of <span style="color:red;">[Required]</span> Item Aspects and leave other fields in this section.
				To do so, either enter a custom value or get the values from Product Attributes or Custom Fields.</p>
			</th>

			<?php

			if ( ! empty( $categoryAttributes ) ) {
				$marketPlace = 'ced_ebay_required_common';
				$indexToUse  = 0;
				$productID   = 0;
				$categoryID  = '';

				$data = array();
				if ( ! empty( $profile_data ) ) {
					$data = json_decode( $profile_data['profile_data'], true );
				}

				foreach ( $categoryAttributes as $key1 => $value ) {

					$isText   = true;
					$field_id = trim( urlencode( $value['localizedAspectName'] ) );
					$default  = isset( $data[ $profile_category_id . '_' . $field_id ] ) ? $data[ $profile_category_id . '_' . $field_id ] : '';
					$default  = isset( $default['default'] ) ? $default['default'] : '';
					$required = '';

					if ( 'true' == $value['aspectConstraint']['aspectRequired'] ) {
						$required = 'required';
					}

					if ( 'no' == $this->is_setup_wizard || ( 'yes' == $this->is_setup_wizard && 'required' == $required ) ) {
						?>
								<tr class="form-field _umb_brand_field" attr="<?php echo esc_attr( $required ); ?>" > 
								<?php

									// $this->ced_ebay_default_section( $value, $value['localizedAspectName'], $field_id, $required, $profile_category_id, $productID, $marketPlace, $indexToUse, $default, true, 'prepareItemAspects' );
								if ( 'SELECTION_ONLY' == $value['aspectConstraint']['aspectMode'] ) {
									$valueForDropdown     = $value['aspectValues'];
									$tempValueForDropdown = array();
									foreach ( $valueForDropdown as $key => $_value ) {
										$tempValueForDropdown[ $_value['localizedValue'] ] = $_value['localizedValue'];
									}
									$valueForDropdown = $tempValueForDropdown;

									$this->productFieldInstance->renderDropdownHTML(
										$field_id,
										ucfirst( $value['localizedAspectName'] ),
										$valueForDropdown,
										$profile_category_id,
										$productID,
										$marketPlace,
										$indexToUse,
										array(
											'case'  => 'profile',
											'value' => $default,
										),
										$required,
										$value['aspectConstraint']['itemToAspectCardinality']
									);
									$isText = false;

								} elseif ( 'COMBO_BOX' == isset( $value['input_type'] ) ? $value['input_type'] : '' ) {
									$isText = true;

									$this->productFieldInstance->renderInputTextHTML(
										$field_id,
										ucfirst( $value['localizedAspectName'] ),
										$profile_category_id,
										$productID,
										$marketPlace,
										$indexToUse,
										array(
											'case'  => 'profile',
											'value' => $default,
										),
										$required,
										$value['aspectConstraint']['itemToAspectCardinality']
									);
								} elseif ( 'text' == isset( $value['input_type'] ) ? $value['input_type'] : '' ) {
									$isText = true;

									$this->productFieldInstance->renderInputTextHTML(
										$field_id,
										ucfirst( $value['localizedAspectName'] ),
										$profile_category_id,
										$productID,
										$marketPlace,
										$indexToUse,
										array(
											'case'  => 'profile',
											'value' => $default,
										),
										$required,
										$value['aspectConstraint']['itemToAspectCardinality']
									);
								} else {
									$isText = true;
									// $field_type = isset( $value['fields'] ) && isset( $value['fields']['type'] ) ? $value['fields']['type'] : '';
									$this->productFieldInstance->renderInputTextHTML(
										$field_id,
										ucfirst( $value['localizedAspectName'] ),
										$profile_category_id,
										$productID,
										$marketPlace,
										$indexToUse,
										array(
											'case'  => 'profile',
											'value' => $default,
										),
										$required,
										$value['aspectConstraint']['itemToAspectCardinality']
									);
								}

								?>
									<td> 
									<?php
										// echo '<pre>'; print_r($value);  echo '</pre>';
									if ( $isText ) {
										$this->adminInstance = new EBay_Integration_For_Woocommerce_Admin( 'ebay-integration-for-woocommerce', '1.0.0' );
										$this->adminInstance->ced_ebay_profile_dropdown( $profile_category_id . '_' . $field_id, $required, $data, $value, $section );
									}
									?>
									</td> 
								</tr> 
								
							<?php
					}
					// item aspects
				}
			}

				$cat_features_file = $this->wp_upload_dir . 'ebaycatfeatures_' . $profile_category_id . '.json';

			if ( file_exists( $cat_features_file ) ) {
				$contents = file_get_contents( $cat_features_file );
				if ( ! $contents || false == $contents || 'false' == $contents ) {
					$getCatFeatures = $this->ced_ebay_site_cat_features( $profile_category_id, $cat_features_file );
				} else {
					$item_aspects   = json_decode( file_get_contents( $cat_features_file ), true );
					$getCatFeatures = isset( $item_aspects['Category'] ) ? $item_aspects['Category'] : array();
				}
			} else {
				$getCatFeatures = $this->ced_ebay_site_cat_features( $profile_category_id, $cat_features_file );
			}

				// $limit                = array( 'ConditionEnabled', 'ConditionValues' );
				// $ebayCategoryInstance  = CedGetCategories::get_instance( $this->siteID, $this->token );
				// $getCatFeatures       = $ebayCategoryInstance->_getCatFeatures( $profile_category_id, array() );

				// print_r($getCatFeatures);
				// echo 'valueForDropdown00';

			if ( ! empty( $getCatFeatures ) && isset( $getCatFeatures['ConditionValues'] ) ) {

				$valueForDropdown = $getCatFeatures['ConditionValues']['Condition'];

				$tempValueForDropdown = array();

				if ( isset( $valueForDropdown[0] ) ) {
					foreach ( $valueForDropdown as $key => $value ) {
						$tempValueForDropdown[ $value['ID'] ] = $value['DisplayName'];
					}
				} else {
					$tempValueForDropdown[ $valueForDropdown['ID'] ] = $valueForDropdown['DisplayName'];
				}
				$valueForDropdown = $tempValueForDropdown;

				$profile_category_data = json_decode( $profile_data['profile_data'], true );
				$name                  = 'Condition';
				$default               = isset( $profile_category_data[ $profile_category_id . '_' . $name ] ) ? $profile_category_data[ $profile_category_id . '_' . $name ] : '';
				$default               = isset( $default['default'] ) ? $default['default'] : '';
				if ( 'Required' == $getCatFeatures['ConditionEnabled'] ) {
					$catFeatureSavingForvalidation[ $categoryID ][] = 'Condition';
				}

				?>
					<tr class="form-field _umb_brand_field condition_req">  
					<?php
						$this->productFieldInstance->renderDropdownHTML(
							'Condition',
							$name,
							$valueForDropdown,
							$profile_category_id,
							$productID,
							$marketPlace,
							$indexToUse,
							array(
								'case'  => 'profile',
								'value' => $default,
							),
							'required'
						);

					?>
					</tr> 
					<?php
			}

		}


		public function ced_ebay_site_cat_features( $profile_category_id, $cat_features_file ) {

			$ebayCategoryInstance = CedGetCategories::get_instance( $this->siteID, $this->token );
			$limit                = array( 'ConditionEnabled', 'ConditionValues' );
			$getCatFeatures       = $ebayCategoryInstance->_getCatFeatures( $profile_category_id, array() );

			if ( empty( $getCatFeatures ) || ( isset( $getCatFeatures['Ack'] ) && 'Success' !== $getCatFeatures['Ack'] ) ) {
				echo json_encode(
					array(
						'status'  => 'error',
						'message' => $getCatFeatures['message'] ? $getCatFeatures['message'] : 'Unable to fetch category',
						'title'   => 'Category Error',

					)
				);
				die;
			}

			$getCatFeatures_json = json_encode( $getCatFeatures );
			if ( file_exists( $cat_features_file ) ) {
				wp_delete_file( $cat_features_file );
			}
			file_put_contents( $cat_features_file, $getCatFeatures_json );
			$item_aspects = json_decode( file_get_contents( $cat_features_file ), true );

			return $item_aspects['Category'];

		}

		public function prepareFrameworkSpecifics( $profile_category_id, $profile_data, $section ) {
			?>

			<tr>
				<th colspan="3" class="ced_ebay_green_border" >
					<label style="font-size: 1.25rem;color: #6574cd;" ><?php esc_attr_e( 'FRAMEWORK SPECIFIC', 'ebay-integration-for-woocommerce' ); ?></label>
					<p style="font-size:16px;">Specify additional details about products listed on eBay based on the selected eBay Category.
					You can only set the values of <span style="color:red;">[Required]</span> Item Aspects and leave other fields in this section.
					To do so, either enter a custom value or get the values from Product Attributes or Custom Fields.</p>
				</th>
			</tr>

			<?php

				$marketPlace       = 'ced_ebay_required_common';
				$indexToUse        = 0;
				$productID         = 0;
				$requiredInAnyCase = array( '_umb_id_type', '_umb_id_val', '_umb_brand' );
				$categoryID        = '';

				$data = array();
			if ( ! empty( $profile_data ) ) {
				$data = json_decode( $profile_data['profile_data'], true );
			}

				$productFieldInstance = CedeBayProductsFields::get_instance();
				$fields               = $productFieldInstance->ced_ebay_get_profile_framework_specific( $profile_category_id );

			if ( ! empty( $fields ) ) {
				foreach ( $fields as $value ) {
					$isText   = false;
					$field_id = trim( $value['fields']['id'], '_' );
					if ( in_array( $value['fields']['id'], $requiredInAnyCase ) ) {
						$attributeNameToRender  = ucfirst( $value['fields']['label'] );
						$attributeNameToRender .= '<span class="ced_ebay_wal_required">' . __( '[ Required ]', 'ebay-integration-for-woocommerce' ) . '</span>';
					} else {
						$attributeNameToRender = ucfirst( $value['fields']['label'] );
					}
					$default  = isset( $data[ $value['fields']['id'] ]['default'] ) ? $data[ $value['fields']['id'] ]['default'] : '';
					$required = isset( $value['required'] ) ? $value['required'] : '';

					if ( 'no' == $this->is_setup_wizard || ( 'yes' == $this->is_setup_wizard && 'required' == $required ) ) {
						?>
							<tr class="form-field _umb_id_type_field" attr="<?php echo esc_attr( $required ); ?>" > 
							<?php
								// $this->ced_ebay_default_section( $value,  $attributeNameToRender, $field_id, $required, $categoryID, $productID, $marketPlace, $indexToUse, $default, true, 'prepareFrameworkSpecifics' );

							if ( '_select' == $value['type'] ) {
								$valueForDropdown = $value['fields']['options'];
								if ( '_umb_id_type' == $value['fields']['id'] ) {
											unset( $valueForDropdown['null'] );
								}
										$productFieldInstance->renderDropdownHTML(
											$field_id,
											$attributeNameToRender,
											$valueForDropdown,
											$categoryID,
											$productID,
											$marketPlace,
											$indexToUse,
											array(
												'case'  => 'profile',
												'value' => $default,
											),
											$required
										);
								$isText = false;
							} elseif ( '_text_input' == $value['type'] ) {
								$productFieldInstance->renderInputTextHTML(
									$field_id,
									$attributeNameToRender,
									$categoryID,
									$productID,
									$marketPlace,
									$indexToUse,
									array(
										'case'  => 'profile',
										'value' => $default,
									),
									$value['fields']['type'],
									$required
								);
								$isText = true;
							} elseif ( '_hidden' == $value['type'] ) {
								$productFieldInstance->renderInputTextHTMLhidden(
									$field_id,
									$attributeNameToRender,
									$categoryID,
									$productID,
									$marketPlace,
									$indexToUse,
									array(
										'case'  => 'profile',
										'value' => $profile_category_id,
									)
								);
								$isText = false;
							} else {
								$isText = false;
							}

							?>
								<td> 
									<?php
									if ( $isText ) {
										$adminInstance = new EBay_Integration_For_Woocommerce_Admin( 'ebay-integration-for-woocommerce', '1.0.0' );
										$adminInstance->ced_ebay_profile_dropdown( $value['fields']['id'], $required, $data, $value, $section );

									}
									?>
								</td>
							</tr>
							<?php
					}
				}
			}

		}



		public function prepareGeneralDetails( $profile_category_id, $profile_data, $section ) {
			?>

			<th colspan="3" class="ced_ebay_green_border" >
				<label style="font-size: 1.25rem;color: #6574cd;" ><?php esc_attr_e( 'GENERAL DETAILS', 'ebay-integration-for-woocommerce' ); ?></label>
			</th>
		
			<?php

				$productFieldInstance = CedeBayProductsFields::get_instance();
				$fields               = $productFieldInstance->ced_ebay_get_custom_products_fields( $profile_category_id );

				$requiredInAnyCase = array( '_umb_id_type', '_umb_id_val', '_umb_brand' );
				global $global_CED_ebay_Render_Attributes;
				$marketPlace = 'ced_ebay_required_common';
				$productID   = 0;
				$categoryID  = '';
				$indexToUse  = 0;

				$data = array();
			if ( ! empty( $profile_data ) ) {
				$data = json_decode( $profile_data['profile_data'], true );
			}

			foreach ( $fields as $value ) {
				$isText   = false;
				$field_id = trim( $value['fields']['id'], '_' );
				if ( in_array( $value['fields']['id'], $requiredInAnyCase ) ) {
					$attributeNameToRender  = ucfirst( $value['fields']['label'] );
					$attributeNameToRender .= '<span class="ced_ebay_wal_required">' . __( '[ Required ]', 'ebay-integration-for-woocommerce' ) . '</span>';
				} else {
					$attributeNameToRender = ucfirst( $value['fields']['label'] );
				}
				$default = isset( $data[ $value['fields']['id'] ]['default'] ) ? $data[ $value['fields']['id'] ]['default'] : '';
				echo '<tr class="form-field _umb_id_type_field ">';

				// $this->ced_ebay_default_section( $value,  $field_id, '', $categoryID, $productID, $marketPlace, $indexToUse, $default, false, 'prepareGeneralDetails' );

				if ( '_select' == $value['type'] ) {
					$valueForDropdown = $value['fields']['options'];
					if ( '_umb_id_type' == $value['fields']['id'] ) {
						unset( $valueForDropdown['null'] );
					}
					$productFieldInstance->renderDropdownHTML(
						$field_id,
						$attributeNameToRender,
						$valueForDropdown,
						$categoryID,
						$productID,
						$marketPlace,
						$indexToUse,
						array(
							'case'  => 'profile',
							'value' => $default,
						)
					);
					$isText = false;
				} elseif ( '_text_input' == $value['type'] ) {
					$productFieldInstance->renderInputTextHTML(
						$field_id,
						$attributeNameToRender,
						$categoryID,
						$productID,
						$marketPlace,
						$indexToUse,
						array(
							'case'  => 'profile',
							'value' => $default,
						),
						'text',
						''
					);
					$isText = true;
				} elseif ( '_hidden' == $value['type'] ) {
					$productFieldInstance->renderInputTextHTMLhidden(
						$field_id,
						$attributeNameToRender,
						$categoryID,
						$productID,
						$marketPlace,
						$indexToUse,
						array(
							'case'  => 'profile',
							'value' => $profile_category_id,
						)
					);
					$isText = false;
				} else {
					$isText = false;
				}

				echo '<td>';
				if ( $isText ) {

					$this->adminInstance = new EBay_Integration_For_Woocommerce_Admin( 'ebay-integration-for-woocommerce', '1.0.0' );
					$this->adminInstance->ced_ebay_profile_dropdown( $value['fields']['id'], '', $data, $value, $section );

					// $previousSelectedValue = 'null';
					// if ( isset( $data[ $value['fields']['id'] ]['metakey'] ) && 'null' != $data[ $value['fields']['id'] ]['metakey'] ) {
					// $previousSelectedValue = $data[ $value['fields']['id'] ]['metakey'];
					// }
					// $updatedDropdownHTML = str_replace( '{{*fieldID}}', $value['fields']['id'], $selectDropdownHTML );
					// $updatedDropdownHTML = str_replace( 'value="' . $previousSelectedValue . '"', 'value="' . $previousSelectedValue . '" selected="selected"', $updatedDropdownHTML );
					// print_r( $updatedDropdownHTML );
				}
				echo '</td>';
				echo '</tr>';
			}

		}

		public function ced_ebay_store_cat_features( $profile_category_id, $cat_features_file = '' ) {

			$ebayCategoryInstance = CedGetCategories::get_instance( $this->siteID, $this->token );
			$limit                = array( 'ConditionEnabled', 'ConditionValues' );
			$getCatFeatures       = $ebayCategoryInstance->_getCatFeatures( $profile_category_id, array() );

			$getCatFeatures_json = json_encode( $getCatFeatures );
			if ( file_exists( $cat_features_file ) ) {
				wp_delete_file( $cat_features_file );
			}
			file_put_contents( $cat_features_file, $getCatFeatures_json );
			$item_aspects = json_decode( file_get_contents( $cat_features_file ), true );
			return $item_aspects['Category'];

		}

		public function geCategoryFeatures( $profile_category_id, $profile_data = array() ) {
			?>

			<th colspan="3" class="ced_ebay_green_border" >
				<label style="font-size: 1.25rem;color: #6574cd;" ><?php esc_attr_e( 'Category Features', 'ebay-integration-for-woocommerce' ); ?></label>
			</th>	

			<?php

				$cat_features_file = $this->wp_upload_dir . 'ebaycatfeatures_' . $profile_category_id . '.json';

			if ( file_exists( $cat_features_file ) ) {
				$contents = file_get_contents( $cat_features_file );
				if ( ! $contents || false == $contents || 'false' == $contents ) {
					$getCatFeatures = $this->ced_ebay_store_cat_features( $profile_category_id, $cat_features_file );
				} else {
					$item_aspects   = json_decode( file_get_contents( $cat_features_file ), true );
					$getCatFeatures = isset( $item_aspects['Category'] ) ? $item_aspects['Category'] : array();
				}
			} else {
				$getCatFeatures = $this->ced_ebay_store_cat_features( $profile_category_id, $cat_features_file );
			}

				$cat_general_features = array(
					'VariationsEnabled',
					'BestOfferEnabled',
					'BestOfferCounterEnabled',
					'BestOfferAutoDeclineEnabled',
					'BestOfferAutoAcceptEnabled',
					'ReturnPolicyEnabled',
				);

				foreach ( $cat_general_features as $cat_general_feature ) {
					$pieces = preg_split( '/(?=[A-Z])/', $cat_general_feature );
					?>

					<tr style="height: 35px;" > 
						<td> <label><?php echo esc_attr( implode( ' ', $pieces ) ); ?> </label></td>
						<td>
							<?php
								$enabled = isset( $getCatFeatures[ $cat_general_feature ] ) ? $getCatFeatures[ $cat_general_feature ] : '';
							if ( $enabled ) {
								echo 'Yes';
							} else {
								echo 'No';
							}

							?>
							
						</td>
						<td></td>
						
					</tr>

					<?php
				}

		}


		public function prepareCustomItemAspects( $profile_category_id, $data ) {

			if ( ! empty( $custom_item_aspects ) ) {
				$json_encoded_item_aspects = json_encode( $custom_item_aspects );
				$prepared_json             = htmlspecialchars( $json_encoded_item_aspects, ENT_QUOTES, 'UTF-8' );

			} else {
				$prepared_json = '';
			}

			if ( isset( $data['custom_item_aspects'] ) && ! empty( $data['custom_item_aspects'] ) ) {
				foreach ( $data['custom_item_aspects'] as $custom_key => $custom_data ) {
					$value = isset( $custom_data['metakey'] ) ? $custom_data['metakey'] : '';
					?>

					<tr class="form-field _umb_brand_field" attr=""> 
						<input type="hidden"  >
						<td> <label> <?php echo esc_attr( str_replace( '+', ' ', $custom_key ) ); ?></label> </td>
						<td>
							<input class="short" name="custom_item_aspects[<?php echo esc_attr( $custom_key ); ?>][default]" 
								value="
								<?php
								$val = isset( $custom_data['default'] ) ? $custom_data['default'] : '';
								echo esc_attr( $val );
								?>
								" >
							<span style="padding-left:10px;font-size:18px;color:#5850ec;"><b>Or</b></span>
						</td>
						<td>
							<?php

								$this->adminInstance = new EBay_Integration_For_Woocommerce_Admin( 'ebay-integration-for-woocommerce', '1.0.0' );
								$this->adminInstance->ced_ebay_profile_dropdown( 'custom_item_aspects[' . $custom_key . '][metakey]', '', $data, $value, 'add-custom-row' );

							?>
							<i class="fa fa-times ced_ebay_remove_custom_row" aria-hidden="true"></i>
						</td>

					</tr>

					<?php
				}
			}

		}


		public function ced_ebay_default_section( $value = array(), $label = '', $field_id = '', $required = '', $profile_category_id = 0, $productID = 0, $marketPlace = '', $indexToUse = '', $default = '', $isItemAspects = false, $func = '' ) {

			if ( ( '_select' == isset( $value['type'] ) ? $value['type'] : '' ) || 'SELECTION_ONLY' == $value['aspectConstraint']['aspectMode'] ) {

				if ( 'prepareItemAspects' == $func ) {

					$valueForDropdown     = $value['aspectValues'];
					$tempValueForDropdown = array();
					foreach ( $valueForDropdown as $key => $_value ) {
						$tempValueForDropdown[ $_value['localizedValue'] ] = $_value['localizedValue'];
					}
					$valueForDropdown = $tempValueForDropdown;

				}

				if ( 'prepareFrameworkSpecifics' == $func ) {
					$valueForDropdown = $value['fields']['options'];
					if ( '_umb_id_type' == $value['fields']['id'] ) {
						unset( $valueForDropdown['null'] );
					}
				}

				$this->productFieldInstance->renderDropdownHTML(
					$field_id,
					ucfirst( $label ),
					$valueForDropdown,
					$profile_category_id,
					$productID,
					$marketPlace,
					$indexToUse,
					array(
						'case'  => 'profile',
						'value' => $default,
					),
					$required,
					$value['aspectConstraint']['itemToAspectCardinality']
				);
				$isText = false;
			} elseif ( 'COMBO_BOX' == isset( $value['input_type'] ) ? $value['input_type'] : '' ) {
				$isText = true;

				$this->productFieldInstance->renderInputTextHTML(
					$field_id,
					ucfirst( $value['localizedAspectName'] ),
					$profile_category_id,
					$productID,
					$marketPlace,
					$indexToUse,
					array(
						'case'  => 'profile',
						'value' => $default,
					),
					$required,
					$value['aspectConstraint']['itemToAspectCardinality']
				);
			} elseif ( 'text' == isset( $value['input_type'] ) ? $value['input_type'] : '' ) {
				$isText = true;

				$this->productFieldInstance->renderInputTextHTML(
					$field_id,
					ucfirst( $value['localizedAspectName'] ),
					$profile_category_id,
					$productID,
					$marketPlace,
					$indexToUse,
					array(
						'case'  => 'profile',
						'value' => $default,
					),
					$required,
					$value['aspectConstraint']['itemToAspectCardinality']
				);
			} else {
				$isText = true;

				if ( $isItemAspects ) {
					$this->productFieldInstance->renderInputTextHTML(
						$field_id,
						ucfirst( $value['localizedAspectName'] ),
						$profile_category_id,
						$productID,
						$marketPlace,
						$indexToUse,
						array(
							'case'  => 'profile',
							'value' => $default,
						),
						$required
					);

				}
			}

		}


	}
}
