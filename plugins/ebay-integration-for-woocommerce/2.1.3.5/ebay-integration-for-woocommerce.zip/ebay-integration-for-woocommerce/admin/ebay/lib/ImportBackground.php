<?php

defined( 'ABSPATH' ) || die( 'Direct access not allowed' );


class ImportBackground_Process extends WP_Background_Process {

	public function __construct() {
		parent::__construct();

	}

	protected $action = 'schedule_async_import_task';

	protected function handle() {
		// Check to see if sync is supposed to be cleared
		$clear = get_option( 'ced_ebay_clear_import_process' );

		// If we do, manually clear the options from the database
		if ( $clear ) {
			wc_get_logger()->info( wc_print_r( 'going to stop import process', true ) );
			// Get current batch and delete it
			$batch = $this->get_batch();
			$this->delete( $batch->key );

			// Clear out transient that locks the process
			$this->unlock_process();

			// Call the complete method, which will tie things up
			$this->complete();

			// Remove the "clear" flag we had manually set
			delete_option( 'ced_ebay_clear_import_process' );

			// Ensure we don't actually handle anything
			return;
		}

		parent::handle();
	}

	protected function task( $item ) {

		$logger  = wc_get_logger();
		$context = array( 'source' => 'ced_ebay_Import_background_process' );
		$Item_id = $item['item_id'];
		$user_id = $item['user_id'];
		if ( ! isset( $Item_id[0] ) ) {
			$Item_id = array(
				0 => $Item_id,
			);
		}
		$logger->info( 'User Id - ' . wc_print_r( $user_id, true ), $context );
		$logger->info( 'Processing Item ID - ' . wc_print_r( $Item_id, true ), $context );
		$store_products = get_posts(
			array(
				'numberposts'  => -1,
				'post_type'    => 'product',
				'meta_key'     => '_ced_ebay_listing_id_' . $user_id,
				'meta_value'   => $Item_id[0],
				'meta_compare' => '=',
			)
		);
		$localItemID    = wp_list_pluck( $store_products, 'ID' );
		if ( ! empty( $localItemID ) ) {
			$ID = $localItemID[0];
			$logger->info( 'Item ID already exist in store - ' . wc_print_r( $ID, true ), $context );
			return false;
		}
		$shop_data = ced_ebay_get_shop_data( $user_id );
		if ( ! empty( $shop_data ) ) {
			$siteID      = $shop_data['site_id'];
			$token       = $shop_data['access_token'];
			$getLocation = $shop_data['location'];
		}
		require_once CED_EBAY_DIRPATH . 'admin/class-woocommerce-ebay-integration-admin.php';
		$adminFileImportRequest = new EBay_Integration_For_Woocommerce_Admin( 'ebay-integration-for-woocommerce', '1.0.0' );
		$adminFileImportRequest->ced_ebay_bulk_import_to_store( $Item_id, $user_id, true );
		return false;
	}

	protected function complete() {
		wc_get_logger()->info( 'Finalized' );
		parent::complete();

	}




}

