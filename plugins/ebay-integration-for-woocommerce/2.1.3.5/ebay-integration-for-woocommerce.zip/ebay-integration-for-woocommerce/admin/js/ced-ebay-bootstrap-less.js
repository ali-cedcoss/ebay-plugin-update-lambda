var bootstrapCss = 'bootstrapCss';

if (!document.getElementById(bootstrapCss))
{
    var plugin_url = ced_ebay_plugin_properties.plugin_url;
    var bootstrapWrapper = document.createElement('link');
    bootstrapWrapper.id = bootstrapCss;
    bootstrapWrapper.rel = 'stylesheet/less';
    bootstrapWrapper.type = 'text/css';
    bootstrapWrapper.href =  plugin_url + '/ebay-integration-for-woocommerce/admin/css/ced-ebay-bootstrap-wrapper.less';
    bootstrapWrapper.media = 'all';
    document.head.appendChild(bootstrapWrapper);
    console.log(bootstrapWrapper);
    var lessjs = document.createElement('script');
    lessjs.type = 'text/javascript';
    lessjs.src = plugin_url + '/ebay-integration-for-woocommerce/admin/js/less.min.js';
    document.head.appendChild(lessjs);

    //load other stylesheets that override bootstrap styles here, using the same technique from above

    // var customStyles = document.createElement('link');
    // customStyles.id = "customStyles";
    // customStyles.rel = 'stylesheet';
    // customStyles.type = 'text/css';
    // customStyles.href = '../wp-content/plugins/myplugin/css/styles.css';
    // customStyles.media = 'all';
    // head.appendChild(customStyles);
}