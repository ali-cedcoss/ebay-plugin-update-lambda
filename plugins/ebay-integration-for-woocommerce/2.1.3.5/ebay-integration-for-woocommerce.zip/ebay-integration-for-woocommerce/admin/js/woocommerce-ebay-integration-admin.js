
(function( $ ) {
	'use strict';



	/**
	 * All of the code for your admin-facing JavaScript source
	 * should reside in this file.
	 *
	 * Note: It has been assumed you will write jQuery code here, so the
	 * $ function reference has been prepared for usage within the scope
	 * of this function.
	 *
	 * This enables you to define handlers, for when the DOM is ready:
	 *
	 * $(function() {
	 *
	 * });
	 *
	 * When the window is loaded:
	 *
	 * $( window ).load(function() {
	 *
	 * });
	 *
	 * ...and/or other possibilities.
	 *
	 * Ideally, it is not considered best practise to attach more than a
	 * single DOM-ready or window-load handler for a particular page.
	 * Although scripts in the WordPress core, Plugins and Themes may be
	 * practising this, we should strive to set a better example in our own work.
	 */

	 var ajaxUrl   = ced_ebay_admin_obj.ajax_url;
	 var ajaxNonce = ced_ebay_admin_obj.ajax_nonce;
	 var user_id   = ced_ebay_admin_obj.user_id;
	 var siteUrl   = ced_ebay_admin_obj.site_url;
	 var ebay_loader_overlay = '<div class="ced_ebay_overlay"><div class="ced_ebay_overlay__inner"><div class="ced_ebay_overlay__content"><div class="ced_ebay_page-loader-indicator ced_ebay_overlay_loader"><svg class="ced_amazon_overlay_spinner" width="65px" height="65px" viewBox="0 0 66 66" xmlns="http://www.w3.org/2000/svg"><circle class="path" fill="none" stroke-width="6" stroke-linecap="round" cx="33" cy="33" r="30"></circle></svg></div><div class="ced_ebay_page-loader-info"><p class="ced_ebay_page-loader-info-text" id="ced_ebay_progress_text">Loading...</p><p class="ced_ebay_page-loader-info-text" style="font-size:19px;" id="ced_ebay_countdown_timer"></p></div></div></div></div>';


	 $(function() {
jQuery(document).on('change', '.ced-ebay-filter-products-criteria', function(){
	
	var productFilterCriteria = jQuery(document).find('.ced-ebay-filter-products-criteria option:selected').val();
	if(productFilterCriteria == 'product_name'){
		var productFilterCriteriaPlaceholder = 'Filter by Product Name';
	} else if(productFilterCriteria == 'ebay_listing_id'){
		var productFilterCriteriaPlaceholder = 'Filter by eBay Item ID';
	} else if(productFilterCriteria == 'product_sku'){
		var productFilterCriteriaPlaceholder = 'Filter by Product SKU';
	}

	
	jQuery('.ced-ebay-filter-products').selectWoo({
		allowClear: true,
		placeholder: productFilterCriteriaPlaceholder,
		dropdownPosition: 'below',
	  dropdownAutoWidth : true,
	  language: {
		  inputTooShort: function (args) {

			  return "Please enter 3 or more words.";
		  },
		  noResults: function () {
			  return "Not Found.";
		  },
		  searching: function () {
			  return "Searching...";
		  }
	  },
	  minimumInputLength: 3,
	  ajax : {
		  url: ajaxUrl,
		  delay: 250,
		  data: function (term) {
            return {
                search_term: term.term,
				ajax_nonce: ajaxNonce,
				action: 'ced_ebay_filter_products',
				filter_criteria: productFilterCriteria,
				user_id: user_id
            };
        },
		processResults: function (data) {
			return {
				results: $.map(data, function(obj) {
					if(obj.id!=0){
					return { id: obj.post_id, text: obj.post_title };
				}
									})
			};

		}
	  }
	});
})

jQuery('.ced-ebay-filter-products').selectWoo(
	{
	allowClear: true,
	  placeholder: "Filter by Product Name",
	  dropdownPosition: 'below',
	  dropdownAutoWidth : true,
	  language: {
		  inputTooShort: function (args) {

			  return "Please enter 3 or more words.";
		  },
		  noResults: function () {
			  return "Not Found.";
		  },
		  searching: function () {
			  return "Searching...";
		  }
	  },
	  minimumInputLength: 3,
	  ajax : {
		  url: ajaxUrl,
		  delay: 250,
		  data: function (term) {
            return {
                search_term: term.term,
				ajax_nonce: ajaxNonce,
				action: 'ced_ebay_filter_products',
				filter_criteria: 'product_name',
				user_id: user_id
            };
        },
		processResults: function (data) {
			return {
				results: $.map(data, function(obj) {
					if(obj.id!=0){
					return { id: obj.post_id, text: obj.post_title };
				}
									})
			};

		}
	  }
	}
  );


  jQuery(".ced_ebay_cst_prf_ebay_cat").selectWoo({
	width: '100%',
placeholder: {
	id: "",
	placeholder: "Choose."
},
language: {
	inputTooShort: function (args) {

		return "Please enter 3 or more words.";
	},
	noResults: function () {
		return "Not Found.";
	},
	searching: function () {
		return "Searching...";
	}
},
minimumInputLength: 3,
// ajax : {
// 	url: ajaxUrl,
// 	delay: 250,
// 	data: function (term) {
// 	  return {
// 		  search_term: term.term,
// 		  ajax_nonce: ajaxNonce,
// 		  action: 'ced_ebay_get_categories_for_category_mapping',
// 		  user_id: user_id
// 	  };
//   },
//   processResults: function (data) {
// 	  return {
// 		  results: $.map(data, function(obj) {
// 			  if(obj.id!=0){
// 			  return { id: obj.category_id, text: obj.category_title };
// 		  }
// 							  })
// 	  };

//   }
// }
});

	$('.ced-searchbox').keyup(function(e){
		var search_value = $(this).val();
		if(search_value.length <= 3) {
			return;
		}
		e.preventDefault();
		var data = {
			paged: parseInt( $('input[name=paged]').val() ) || '1',
			order: $('input[name=order]').val() || 'asc',
			orderby: $('input[name=orderby]').val() || 'title',
			s : search_value,
		};

		setParams('s', search_value);
		setParams('paged', data['paged']);
		setParams('order', data['order']);
		setParams('orderby', data['orderby']);
		list.update( data );

	});

	const list = {
		update: function( data ) {
			$(document).find('.ced-ebay-products').append(ebay_loader_overlay);
			$.ajax({
				url: ajaxUrl,
				type: 'post',
				data: $.extend(
					{
						ajax_nonce : ajaxNonce,

						action: 'ced_ebay_ajax_fetch_custom_list',
					},
					data
				),

				success: function( response ) {
					jQuery('.ced-ebay-products .ced_ebay_overlay').remove();
					var response = $.parseJSON( response );
					// Add the requested rows
					if ( response.rows.length )
						$('#the-list').html( response.rows );
					// Update column headers for sorting
					if ( response.column_headers.length )
						$('thead tr, tfoot tr').html( response.column_headers );
					// Update pagination for navigation
					if ( response.pagination.bottom.length )
						$('.tablenav.top .tablenav-pages').html( $(response.pagination.top).html() );
					if ( response.pagination.top.length )
						$('.tablenav.bottom .tablenav-pages').html( $(response.pagination.bottom).html() );

						ced_popover_update_data();

						$('#ced-wp-table-list .wp-list-table.ced-products').removeClass('ced-table-loader');
					// Init back our event handlers
					list.init();
				}
			});
		}
	}
		  });


		  
	jQuery( document ).on(
		'click',
		"#ced_ebay_submit_order_fulfillment",
		function(event){
			event.preventDefault();
			var order_id          = $( this ).data( 'order_id' );
			var trackingNumber  = $( '#umb_ebay_tracking_number' ).val();
			var shippingService = $('#ced_ebay_shipping_service_selected option:selected').val();
			if(shippingService == -1){
				alert('Please select a shipping service');
				return;
			}
			jQuery('#wpbody-content').append(ebay_loader_overlay);
			jQuery("#ced_ebay_progress_text").html("Fulfilling eBay Order");
			var data = {
				'action':'ced_ebay_fulfill_order',
				ajax_nonce : ajaxNonce,
				userid : user_id,
				order_id: order_id,
				tracking_number: trackingNumber,
				shipping_service: shippingService
			};
			jQuery.post(
				ajaxUrl,
				data,
				function(response){
					jQuery('#wpbody-content .ced_ebay_overlay').remove();
					alert(response.message);
				}
			);
		}
	);



	jQuery( document ).on(
		"click",
		".ced_ebay_site_add_shipping_template_button",
		function(){
			jQuery( document ).find( "#ced-ebay-popup.overlay" ).css( 'visibility','visible' );
			jQuery( document ).find( "#ced-ebay-popup.overlay" ).css( 'opacity',1 );
		}
	);
	window.addEventListener(
		'keydown',
		function (event) {
			if (event.key === 'Escape') {
				  jQuery( document ).find( "#ced-ebay-popup.overlay" ).css( 'visibility','hidden' );

				  jQuery( document ).find( "#ced-ebay-popup.overlay" ).css( 'opacity',0 );
			}
		}
	);
	jQuery( document ).on(
		"click",
		".ced_ebay_site_shipping_template_close",
		function(){
			jQuery(document).find('.notice-empty-field-description-template').remove();
			jQuery( document ).find( "#ced-ebay-popup.overlay" ).hide();
			var windowUrl = siteUrl + '/wp-admin/admin.php?page=ced_ebay&section=accounts-view&part=shipping&user_id=' + user_id;
			window.location.href = windowUrl;
		}
	);


	$( document ).on(
		"click",
		".ced_ebay_site_add_shipping_template_button",
		function(){

			$( document ).find( ".ced_ebay_site_new_shipping_template_wrapper" ).show();

		}
	);


	$( document ).on(
		'change',
		'.ced_ebay_select_store_category_checkbox',
		function(){
			var store_category_id = $( this ).attr( 'data-categoryID' );
			if ( $( this ).is( ':checked' ) ) {
				$( '#ced_ebay_categories_' + store_category_id ).show( 'slow' );
				$( '#ced_ebay_secondary_categories_' + store_category_id ).show( 'slow' );
				$( '#ced_ebay_store_custom_categories_' + store_category_id ).show( 'slow' );
				$( '#ced_ebay_store_custom_categories_' + store_category_id ).attr('style', 'display:table-row' );
				$( '#ced_ebay_store_secondary_categories_' + store_category_id ).show( 'slow' );
				$( '#ced_ebay_store_secondary_categories_' + store_category_id ).attr('style', 'display:table-row' );
				$( '#ced_ebay_secondary_categories_' + store_category_id ).attr('style', 'display:table-row' );


			} else {
				$( '#ced_ebay_categories_' + store_category_id ).hide( 'slow' );
				$( '#ced_ebay_store_custom_categories_' + store_category_id ).hide( 'slow' );
				$( '#ced_ebay_store_secondary_categories_' + store_category_id ).hide( 'slow' );
				$( '#ced_ebay_secondary_categories_' + store_category_id ).hide( 'slow' );

			}
		}
	);

	jQuery( document ).on(
		'click',
		'.ced_ebay_add_domestic_shipping_service_row',
		function(){
			var repeatable = jQuery( this ).parents( 'tr' ).clone();
			jQuery( repeatable ).insertAfter( jQuery( this ).parents( 'tr' ) );
			jQuery( this ).parent( 'td' ).remove();
			jQuery( repeatable ).find( 'input[type=text]' ).val( "" );
		}
	);

	jQuery( document ).on(
		'click',
		'.ced_ebay_add_intl_shipping_service_row',
		function(){
			var key        = jQuery( this ).attr( 'data-add' );
			key            = parseInt( key, 10 ) + 1;
			var repeatable = jQuery( this ).parents( 'tr' ).clone();
			jQuery( repeatable ).insertAfter( jQuery( this ).parents( 'tr' ) );
			jQuery( this ).parent( 'td' ).remove();
			jQuery( repeatable ).find( 'input[type=text]' ).val( "" );
			jQuery( repeatable ).find( '.select_location' ).attr( 'name' , 'shippingdetails[internationalShippingService][locations][' + key + '][]' );
			key = key.toString();
			jQuery( repeatable ).find( '.ced_ebay_add_intl_shipping_service_row').attr('data-add', key);
		}
	);


	$( document ).on(
		'click',
		'.ced_ebay_save_bulk_category_mapping_btn',
		function(){
			var  store_category_array = [];
			jQuery.each(jQuery("input[class='ced_ebay_select_store_category_checkbox']:checked"), function (index, item) {
				store_category_array.push(jQuery(item).attr('data-categoryid'));
	});

	var selected_ebay_category = $( '#ced_ebay_select_bulk_map_ebay_categories' ).find( "select:last" ).val();
	var selected_ebay_category_name = '';
	$('.ced_ebay_bulk_select_ebay_category > option:selected').each(function(index, item) {
		selected_ebay_category_name += (jQuery(item).text() + ' --> ');

	  });
	  var name_len = selected_ebay_category_name.length;
	  selected_ebay_category_name = selected_ebay_category_name.substring(0, name_len - 5);
	  selected_ebay_category_name = selected_ebay_category_name.trim();
	var ebay_store_id         = $( this ).attr( 'data-ebaystoreid' );
			$( '.ced_ebay_loader' ).show();
			$.ajax(
				{
					url : ajaxUrl,
					data : {
						ajax_nonce : ajaxNonce,
						action : 'ced_ebay_map_bulk_category_selection_to_store',
						selected_ebay_category : selected_ebay_category,
						store_category_array : store_category_array,
						selected_ebay_category_name : selected_ebay_category_name,
						ebay_store_id : ebay_store_id,
					},
					type : 'POST',
					success: function(response)
				{
						$( '.ced_ebay_loader' ).hide();
						var html="<div class='notice notice-success'><p>Profile Created Successfully</p></div>";
						 $("#profile_create_message").html(html);
						window.setTimeout(function(){window.location.reload();}, 3000)

					}
				}
			);

		}
	);


	$( document ).on(
		'change',
		'.ced_ebay_bulk_select_ebay_category',
		function(){

			var ebay_store_id               = $( this ).attr( 'data-ebayStoreId' );
			var selected_ebay_category_id   = $( this ).val();
			var selected_ebay_category_name = $( this ).find( "option:selected" ).text();
			var level                       = $( this ).attr( 'data-level' );

			if ( level != '8' ) {
				$( '.ced_ebay_loader' ).show();
				$.ajax(
					{
						url : ajaxUrl,
						data : {
							ajax_nonce : ajaxNonce,
							action : 'ced_ebay_fetch_next_level_category',
							level : level,
							name : selected_ebay_category_name,
							id : selected_ebay_category_id,
							ebay_store_id : ebay_store_id,
						},
						type : 'POST',
						success: function(response)
					{
							response = jQuery.parseJSON( response );
							$( '.ced_ebay_loader' ).hide();
							if ( response != 'No-Sublevel' ) {
								for (var i = 1; i < 8; i++) {
									$('.ced_ebay_save_bulk_category_mapping_div').remove();
									$('.ced_ebay_save_bulk_category_mapping_btn').remove();
									$( '#ced_ebay_select_bulk_map_ebay_categories'  ).find( '.ced_ebay_level' + (parseInt( level ) + i) + '_category' ).closest( "select" ).remove();
								}
								if (response != 0) {
									$('.ced_ebay_save_bulk_category_mapping_div').remove();
									$('.ced_ebay_save_bulk_category_mapping_btn').remove();
									$( '#ced_ebay_select_bulk_map_ebay_categories' ).append( response );
								} else {
									$('.ced_ebay_save_bulk_category_mapping_div').remove();
									$('.ced_ebay_save_bulk_category_mapping_btn').remove();
									$( '#ced_ebay_select_bulk_map_ebay_categories' ).append( '<div class="admin-custom-action-show-button-outer ced_ebay_save_bulk_category_mapping_div" style="padding: 0px 10px;"><button type="button"  class="button btn-normal-sbc ced_ebay_save_bulk_category_mapping_btn" data-ebayStoreID = '+ebay_store_id+'><span>Save Mapping</span></div>' );
								}
							} else {
								$( '#ced_ebay_select_bulk_map_ebay_categories' ).find( '.ced_ebay_level' + (parseInt( level ) + 1) + '_category' ).remove();
							}
						}
					}
				);
			}

		}
	);


	$( document ).on(
		'change',
		'.ced_ebay_select_category',
		function(){

			var store_category_id           = $( this ).attr( 'data-storeCategoryID' );
			var ebay_store_id               = $( this ).attr( 'data-ebayStoreId' );
			var selected_ebay_category_id   = $( this ).val();
			var selected_ebay_category_name = $( this ).find( "option:selected" ).text();
			var level                       = $( this ).attr( 'data-level' );

			if ( level != '8' ) {
				$( '.ced_ebay_loader' ).show();
				$.ajax(
					{
						url : ajaxUrl,
						data : {
							ajax_nonce : ajaxNonce,
							action : 'ced_ebay_fetch_next_level_category',
							level : level,
							name : selected_ebay_category_name,
							id : selected_ebay_category_id,
							store_id : store_category_id,
							ebay_store_id : ebay_store_id,
							type: 'primary'

						},
						type : 'POST',
						success: function(response)
					{
							response = jQuery.parseJSON( response );
							$( '.ced_ebay_loader' ).hide();
							if ( response != 'No-Sublevel' ) {
								for (var i = 1; i < 8; i++) {
									$( '#ced_ebay_categories_' + store_category_id ).find( '.ced_ebay_level' + (parseInt( level ) + i) + '_category' ).closest( "td" ).remove();
								}
								if (response != 0) {
									$( '#ced_ebay_categories_' + store_category_id ).append( response );
								}
							} else {
								$( '#ced_ebay_categories_' + store_category_id ).find( '.ced_ebay_level' + (parseInt( level ) + 1) + '_category' ).remove();
							}
						}
					}
				);
			}

		}
	);


	$( document ).on(
		'change',
		'.ced_ebay_select_secondary_category',
		function(){

			var store_category_id           = $( this ).attr( 'data-storeCategoryID-secondary' );
			var ebay_store_id               = $( this ).attr( 'data-ebayStoreId-secondary' );
			var selected_ebay_category_id   = $( this ).val();
			var selected_ebay_category_name = $( this ).find( "option:selected" ).text();
			var level                       = $( this ).attr( 'data-level-secondary' );

			if ( level != '8' ) {
				$( '.ced_ebay_loader' ).show();
				$.ajax(
					{
						url : ajaxUrl,
						data : {
							ajax_nonce : ajaxNonce,
							action : 'ced_ebay_fetch_next_level_category',
							level : level,
							name : selected_ebay_category_name,
							id : selected_ebay_category_id,
							store_id : store_category_id,
							ebay_store_id : ebay_store_id,
							type: 'secondary'
						},
						type : 'POST',
						success: function(response)
					{
							response = jQuery.parseJSON( response );
							$( '.ced_ebay_loader' ).hide();
							if ( response != 'No-Sublevel' ) {
								for (var i = 1; i < 8; i++) {
									$( '#ced_ebay_secondary_categories_' + store_category_id ).find( '.ced_ebay_level' + (parseInt( level ) + i) + '_secondary_category' ).closest( "td" ).remove();

								}
								if (response != 0) {
									$( '#ced_ebay_secondary_categories_' + store_category_id ).append( response );

								}
							} else {
								$( '#ced_ebay_secondary_categories_' + store_category_id ).find( '.ced_ebay_level' + (parseInt( level ) + 1) + '_secondary_category' ).remove();

							}
						}
					}
				);
			}

		}
	);


	$( document ).on(
		'click',
		'#ced_ebay_category_refresh_button',
		function(e){
			jQuery('#wpbody-content').append(ebay_loader_overlay);
			var levels_arr = [1,2,3,4,5,6,7,8];
			performCategoryRefresh( levels_arr );
		}
	);

	function performCategoryRefresh(levels_arr){

		if (levels_arr == '') {
			var notice = "";
			notice    += "<div class='notice notice-error'><p>Categories not found.</p></div>";
			$( ".success-admin-notices" ).html( notice );
		}
				$.ajax(
			{
				url: ajaxUrl,
				data: {
					ajax_nonce : ajaxNonce,
					action : 'ced_ebay_category_refresh_button',
					userid:user_id,
					levels: levels_arr
				},
				type: 'POST',
				success: function(response){
					response = jQuery.parseJSON( response );
					var category_level = response.level;
					if(response.status == 'error'){
						jQuery('#ced_ebay_progress_text').html(response.message);
					} else {
						notice             = "Imported " + category_level + " out of 8 Category Files Successfully";
						jQuery('#ced_ebay_progress_text').html(notice);
						var remaining_levels_arr = levels_arr.splice( 1 );
						if (remaining_levels_arr != '') {
							performCategoryRefresh( remaining_levels_arr );
						} else {
							jQuery('#ced_ebay_progress_text').html('All Category Files Imported Successfully');
							window.setTimeout( function(){window.location.reload()}, 2000 );
	
						}
					}
				
				}
			}
		)

	}

	$( document ).on(
		'click',
		'#ced_ebay_save_bulk_category_mapping_btn',
		function(){

			var  ebay_category_array  = [];
			var  store_category_array = [];
			var  ebay_category_name   = [];
			var ebay_store_id         = $( this ).attr( 'data-ebayStoreID' );
			var map_child_cat_array = [];

			jQuery( '.ced_ebay_select_store_category_checkbox' ).each(
				function(key) {

					if ( jQuery( this ).is( ':checked' ) ) {
						var store_category_id = $( this ).attr( 'data-categoryid' );
						var cat_level         = $( '#ced_ebay_categories_' + store_category_id ).find( "td:last" ).attr( 'data-catlevel' );

						var selected_ebay_category_id = $( '#ced_ebay_categories_' + store_category_id ).find( '.ced_ebay_level' + cat_level + '_category' ).val();

						if ( selected_ebay_category_id == '' || selected_ebay_category_id == null ) {
							selected_ebay_category_id = $( '#ced_ebay_categories_' + store_category_id ).find( '.ced_ebay_level' + (parseInt( cat_level ) - 1) + '_category' ).val();
						}
						var category_name = '';
						$( '#ced_ebay_categories_' + store_category_id ).find( 'select' ).each(
							function(key1){
								category_name += $( this ).find( "option:selected" ).text() + ' --> ';
							}
						);
						$( '#ced_ebay_select_child_category_' + store_category_id ).find( '.ced_ebay_select_child_category_checkbox:checkbox:checked' ).each(
							function(key1){
								map_child_cat_array.push($( this ).attr('data-categoryID'));
							}
						);
						var name_len = 0;
						if ( selected_ebay_category_id != '' && selected_ebay_category_id != null ) {
							ebay_category_array.push( selected_ebay_category_id );
							store_category_array.push( store_category_id );

							name_len      = category_name.length;
							category_name = category_name.substring( 0, name_len - 5 );
							category_name = category_name.trim();
							name_len      = category_name.length;
							if ( category_name.lastIndexOf( '--Select--' ) > 0 ) {
								category_name = category_name.trim();
								category_name = category_name.replace( '--Select--', '' );
								name_len      = category_name.length;
								category_name = category_name.substring( 0, name_len - 5 );
							}
							name_len = category_name.length;

							ebay_category_name.push( category_name );
						}
					}
				}
			);
			$( '.ced_ebay_loader' ).show();
			$.ajax(
				{
					url : ajaxUrl,
					data : {
						ajax_nonce : ajaxNonce,
						action : 'ced_ebay_map_categories_to_store',
						ebay_category_array : ebay_category_array,
						store_category_array : store_category_array,
						ebay_category_name : ebay_category_name,
						ebay_store_id : ebay_store_id,
						map_child_cat_array: map_child_cat_array
					},
					type : 'POST',
					success: function(response)
				{
						$( '.ced_ebay_loader' ).hide();
						var html="<div class='notice notice-success'><p>Profile Created Successfully</p></div>";
						 $("#profile_create_message").html(html);
						window.setTimeout(function(){window.location.reload();}, 3000)

					}
				}
			);

		}
	);

	$( document ).on(
		'click',
		'#ced_ebay_save_category_button',
		function(){

			var  ebay_category_array  = [];
			var  ebay_secondary_category_array  = [];
			var  store_category_array = [];
			var  ebay_category_name   = [];
			var  ebay_secondary_category_name   = [];
			var ebay_store_custom_category_array = [];
			var ebay_store_secondary_category_array = [];
			var ebay_store_id         = $( this ).attr( 'data-ebayStoreID' );
			let valid = true;
			jQuery( '.ced_ebay_select_store_category_checkbox' ).each(
				function(key) {

					if ( jQuery( this ).is( ':checked' ) ) {

						let cat_id = $(this).data('categoryid');
						console.log('aaaaaaaaa', this)
						console.log(cat_id);
						jQuery('#ced_ebay_categories_' + cat_id ).find('.ced_ebay_select_category').each( function(){

							console.log('gfhdhd');
							let va = $(this).val();
                            if( '' == va ){
								
								$( '.ced_ebay_store_categories_listing_table' ).css('border-collapse', 'collapse' );
								$( '#ced_ebay_categories_' + cat_id  ).css('border','3px solid red');
								let notice  = "<div class='notice notice-error'><p>Selected eBay categories are incomplete. Please make sure that you select all the way to the last dropdown.</p></div>";
							    $( ".success-admin-notices" ).append( notice );
								valid = false;
								return;
							}

						})

						var store_category_id = $( this ).attr( 'data-categoryid' );
						var ebay_store_custom_category = $('#ced_ebay_store_custom_categories_'+ store_category_id).find( "option:selected" ).val();
						var ebay_store_secondary_category = $('#ced_ebay_store_secondary_categories_'+ store_category_id).find( "option:selected" ).val();
						var cat_level         = $( '#ced_ebay_categories_' + store_category_id ).find( "td:last" ).attr( 'data-catlevel' );
						var cat_level_secondary         = $( '#ced_ebay_secondary_categories_' + store_category_id ).find( "td:last" ).attr( 'data-catlevel-secondary' );
						var selected_ebay_category_id = $( '#ced_ebay_categories_' + store_category_id ).find( '.ced_ebay_level' + cat_level + '_category' ).val();
						var selected_ebay_secondary_category_id = $( '#ced_ebay_secondary_categories_' + store_category_id ).find( '.ced_ebay_level' + cat_level_secondary + '_secondary_category' ).val();

						if ( selected_ebay_category_id == '' || selected_ebay_category_id == null ) {
							selected_ebay_category_id = $( '#ced_ebay_categories_' + store_category_id ).find( '.ced_ebay_level' + (parseInt( cat_level ) - 1) + '_category' ).val();
						}

						if ( selected_ebay_secondary_category_id == '' || selected_ebay_secondary_category_id == null ) {
							selected_ebay_secondary_category_id = $( '#ced_ebay_secondary_categories_' + store_category_id ).find( '.ced_ebay_level' + (parseInt( cat_level_secondary ) - 1) + '_secondary_category' ).val();
						}
						var category_name = '';
						var secondary_category_name = '';
						$( '#ced_ebay_categories_' + store_category_id ).find( 'select' ).each(
							function(key1){
								category_name += $( this ).find( "option:selected" ).text() + ' --> ';
							}
						);
						$( '#ced_ebay_secondary_categories_' + store_category_id ).find( 'select' ).each(
							function(key1){
								secondary_category_name += $( this ).find( "option:selected" ).text() + ' --> ';
							}
						);
						var name_len = 0;
						if ( selected_ebay_category_id != '' && selected_ebay_category_id != null ) {
							ebay_category_array.push( selected_ebay_category_id );
							store_category_array.push( store_category_id );
							ebay_store_custom_category_array.push(ebay_store_custom_category);
							ebay_store_secondary_category_array.push(ebay_store_secondary_category);
							name_len      = category_name.length;
							category_name = category_name.substring( 0, name_len - 5 );
							category_name = category_name.trim();
							name_len      = category_name.length;
							if ( category_name.lastIndexOf( '--Select--' ) > 0 ) {
								category_name = category_name.trim();
								category_name = category_name.replace( '--Select--', '' );
								name_len      = category_name.length;
								category_name = category_name.substring( 0, name_len - 5 );
							}
							name_len = category_name.length;

							ebay_category_name.push( category_name );
						}
						var secondary_name_len = 0;
						if ( selected_ebay_secondary_category_id != '' && selected_ebay_secondary_category_id != null ) {
							ebay_secondary_category_array.push( selected_ebay_secondary_category_id );
							secondary_name_len      = secondary_category_name.length;
							secondary_category_name = secondary_category_name.substring( 0, secondary_name_len - 5 );
							secondary_category_name = secondary_category_name.trim();
							secondary_name_len      = secondary_category_name.length;
							if ( secondary_category_name.lastIndexOf( '--Select--' ) > 0 ) {
								secondary_category_name = secondary_category_name.trim();
								secondary_category_name = secondary_category_name.replace( '--Select--', '' );
								secondary_name_len      = secondary_category_name.length;
								secondary_category_name = secondary_category_name.substring( 0, secondary_name_len - 5 );
							}
							secondary_name_len = secondary_category_name.length;

							ebay_secondary_category_name.push( secondary_category_name );
						}
					}
				}
			);

			if( !valid ){
				return;
			}
			jQuery('#wpbody-content').append(ebay_loader_overlay);
			jQuery("#ced_ebay_progress_text").html("Creating eBay listing profiles...<br><br><p style='font-size:16px;'>If you are getting error while trying to create profile or you are stuck at infinte loading screen please contact support using the live chat button on the bottom right!</p>");
			$.ajax(
				{
					url : ajaxUrl,
					data : {
						ajax_nonce : ajaxNonce,
						action : 'ced_ebay_map_categories_to_store',
						ebay_category_array : ebay_category_array,
						ebay_secondary_category_array : ebay_secondary_category_array,
						store_category_array : store_category_array,
						ebay_store_custom_category_array : ebay_store_custom_category_array,
						ebay_store_secondary_category_array: ebay_store_secondary_category_array,
						ebay_category_name : ebay_category_name,
						ebay_secondary_category_name : ebay_secondary_category_name,
						ebay_store_id : ebay_store_id,
					},
					type : 'POST',
					success: function(response)
				{
					jQuery('#wpbody-content .ced_ebay_overlay').remove();
					var html="<div class='notice notice-success'><p>Profile Created Successfully</p></div>";
						 $("#profile_create_message").html(html);
						window.setTimeout(function(){window.location.reload();}, 3000)

					}
				}
			);

		}
	);


$(document).on('click','#ced_ebay_remove_category_mapping',function(e){
		e.preventDefault();
		var term_id = $(this).attr('data-termid');
		var mapping_type = $(this).attr('data-mappingType');
		var user_id = $(this).attr('data-userId');
		$( '.ced_ebay_loader' ).show();
		jQuery.ajax({
			url: ajaxUrl,
			type: 'POST',
			data: {
				ajax_nonce: ajaxNonce,
				action: 'ced_ebay_remove_category_mapping',
				term_id: term_id,
				user_id:user_id,
				mapping_type:mapping_type,
			},
			success: function(response){
				$( '.ced_ebay_loader' ).hide();
				alert('Mapping removed successfully!');
			}

					});
	});



	$( document ).on(
		'click',
		'#ced_ebay_fetch_orders',
		function(event)
		{
			   event.preventDefault();
			   var store_id = $( this ).attr( 'data-id' );
			   $('#wpbody-content').block({
				message: null,
				overlayCSS: {
					background: '#fff',
					opacity: 0.6
				}
			});			
			$.ajax(
				{
					url : ajaxUrl,
					data : {
						ajax_nonce : ajaxNonce,
						action : 'ced_ebay_get_orders',
						userid:store_id
					},
					type : 'POST',
					success: function(response)
				{
						 $('#wpbody-content').unblock();
						 var response  = jQuery.parseJSON( response );
						 var response1 = jQuery.trim( response.message );
						if (response1 == "Shop is Not Active") {
							var notice = "";
							notice    += "<div class='notice notice-error'><p>Currently Shop is not Active . Please activate your Shop in order to fetch orders.</p></div>";
							$( ".success-admin-notices" ).append( notice );
							return;
						} else if(response.status == 'success'){
							var notice = "";
							notice    += "<div class='notice notice-error'><p>Orders Fetched Successfully. Please reload the page to see your orders.</p></div>";
							$(document).find( ".success-admin-notices" ).append( notice );
						} else if(response.status == 'No Results'){
                            var notice = "";
							notice    += "<div class='notice notice-error'><p>We can\'t see your orders. If you think this is an error, please contact support.</p></div>";
							$(document).find( ".success-admin-notices" ).append( notice );
                        }

					}
				}
			);
		}
	);
	$(document). on ('click', '#ced_ebay_profile_bulk_operation', function(e){
		e.preventDefault();
		var operation = $( ".bulk-action-selector" ).val();
		if (operation <= 0 ) {
			var notice = "";
			notice    += "<div class='notice notice-error'><p>Please Select Operation To Be Performed</p></div>";
			$( ".success-admin-notices" ).append( notice );
		} else {
			var operation        = $( ".bulk-action-selector" ).val();
			var profile_ids = new Array();
			$( '.ebay_profile_ids:checked' ).each(
				function(){
					profile_ids.push( $( this ).val() );
				}
			);
			performProfileBulkAction( profile_ids, operation );
		}

	});

	function performProfileBulkAction(profile_ids, operation)
	{
		if (profile_ids == "") {
			var notice = "";
			notice    += "<div class='notice notice-error is-dismissiable'><p>No Profiles Selected</p><button type='button' class='notice-dismiss'><span class='screen-reader-text'>Dismiss this notice.</span></button></div>";
			$( ".success-admin-notices" ).append( notice );
		}
		$( '.ced_ebay_loader' ).show();
		$.ajax({
			url : ajaxUrl,
			data : {
				ajax_nonce : ajaxNonce,
				action : 'ced_ebay_process_profile_bulk_action',
				operation_to_be_performed : operation,
				profile_ids : profile_ids,
				user_id:user_id
				},
				type : 'POST',
				success: function(response){
				response = jQuery.parseJSON(response);
				jQuery( '.ced_ebay_loader' ).hide();
				Swal.fire({
						  title:response.title,
						  text: response.message,
						  icon: response.status,
					}).then(() => {window.location.reload();});
				}
		});
	}

	// $(document).on(
	// 	'click',
	// 	'#ced_ebay_modify_listing_button',
	// 	function(e){
	// 		e.preventDefault();
	// 		var productId = $(this).attr('data-prod-id');
	// 		$(document).find("#ced_ebay_save_modified_product_data_button").attr("data-prod-id", '');
	// 		$(document).find("#ced_ebay_modify_product_description_button").attr("data-prod-id", '');
	// 		$( '.ced_ebay_loader' ).show();
	// 		$.ajax({
	// 			type:'post',
	// 			url: ajaxUrl,
	// 			data: {
	// 				ajax_nonce: ajaxNonce,
	// 				user_id: user_id,
	// 				productId: productId,
	// 				action: 'ced_ebay_get_modifed_product_details',
	// 			},
	// 			success: function(response){
	// 				response = jQuery.parseJSON(response);
	// 				if(response.status == 'success'){
	// 					$( '.ced_ebay_loader' ).hide();
	// 					$( '.modify-listing-wrapper' ).show();
	// 					$(document).find("#ced_ebay_new_prod_title_input").val(response.data);
	// 					$(document).find("#ced_ebay_save_modified_product_data_button").attr("data-prod-id", productId);
	// 					$(document).find("#ced_ebay_modify_product_description_button").attr("data-prod-id", productId);
	// 					$( '.ced-ebay-bulk-create-ads-trigger' ).click(
	// 						function() {
	// 							$( '.modify-listing-wrapper' ).hide();
	// 						}
	// 					);
	// 					return;
	// 				} else {
	// 					$( '.ced_ebay_loader' ).hide();
	// 					$( '.modify-listing-wrapper' ).show();
	// 					$(document).find("#ced_ebay_new_prod_title_input").val('');
	// 					$(document).find("#ced_ebay_save_modified_product_data_button").attr("data-prod-id", productId);
	// 					$(document).find("#ced_ebay_modify_product_description_button").attr("data-prod-id", productId);
	// 					$( '.ced-ebay-bulk-create-ads-trigger' ).click(
	// 						function() {
	// 							$( '.modify-listing-wrapper' ).hide();
	// 						}
	// 					);
	// 					return;

	// 				}
	// 			}
	// 		})

	// 	}
	// )

	$(document).on('click', '#ced_ebay_save_modified_product_data_button', function(e){
		e.preventDefault();
		var productId = $(this).attr('data-prod-id');
		var prodTitle = $("#ced_ebay_new_prod_title_input").val();
		var storeCategoryValue = $("#ced_ebay_select_store_categories").find(":selected").val();
		var storeCategoryName = $("#ced_ebay_select_store_categories").find("option:selected").attr("name");
		$( '.ced_ebay_loader' ).show();
		$.ajax({
			type:'post',
			url : ajaxUrl,
			data : {
				ajax_nonce: ajaxNonce,
				user_id: user_id,
				productId:  productId,
				prodTitle:  prodTitle,
				store_category_value: storeCategoryValue,
				store_category_name: storeCategoryName,
				action: 'ced_ebay_modify_product_data_for_upload'
			},
			success: function(response){
				response = jQuery.parseJSON(response);
				if(response.status == 'success'){
					jQuery('.ced_ebay_loader').hide();
					swal({
						title:'Success',
						text: response.message,
						icon: response.status,
				  });
				} else {
					jQuery('.ced_ebay_loader').hide();
					swal({
						title:'Error',
						text: response.message,
						icon: response.status,
				  });
				}
							}
		})
	});

	$( document ).on(
		'click',
		'#ced_ebay_bulk_operation',
		function(e){
			e.preventDefault();
			var operation = $( ".ced_ebay_select_ebay_product_action" ).val();
			if (operation <= 0 ) {
				var notice = "";
				notice    += "<div class='notice notice-error'><p>Please Select Operation To Be Performed</p></div>";
				$( ".success-admin-notices" ).append( notice );
			} else {
				if (operation == 'create_ads') {
					$( '.ced-ebay-bulk-create-ads-modal-wrapper' ).show();
					$( '.ced-ebay-bulk-create-ads-trigger' ).click(
						function() {
							$( '.ced-ebay-bulk-create-ads-modal-wrapper' ).hide();
						}
					);
					return;

				}
				var operation        = $( ".ced_ebay_select_ebay_product_action" ).val();
				var ebay_products_id = new Array();
				$( '.ebay_products_id:checked' ).each(
					function(){
						ebay_products_id.push( $( this ).val() );
					}
				);
				performBulkAction( ebay_products_id,operation );
			}

		}
	);
	$( document ).on(
		'change',
		'#ced_ebay_scheduler_info',
		function(){

			if (this.checked) {
				$( ".ced_ebay_scheduler_info" ).css( 'display','contents' );


			} else {
				$( ".ced_ebay_scheduler_info" ).css( 'display','none' );

			}
		}
	);
	function performBulkAction(ebay_products_id,operation)
		{
		if (ebay_products_id == "") {
			var notice = "";
			notice    += "<div class='notice notice-error is-dismissiable' style='margin-left:0px;margin-top:15px;'><p>No Products Selected</p><button type='button' class='notice-dismiss'><span class='screen-reader-text'>Dismiss this notice.</span></button></div>";
			$( ".ced-ebay-products-view-notice" ).append( notice );
			return;
		}
		jQuery("#wpbody-content").append(ebay_loader_overlay);
		jQuery("#ced_ebay_progress_text").html("Processing Action...<br><br><p style='font-size:16px;'>If you are getting error while trying to upload/update products please contact support using the live chat button on the bottom right!</p>");
		$.ajax(
			{
				url : ajaxUrl,
				data : {
					ajax_nonce : ajaxNonce,
					action : 'ced_ebay_process_bulk_action',
					operation_to_be_performed : operation,
					id : ebay_products_id,
					userid:user_id
				},
				type : 'POST',
				success: function(response)
				{
					jQuery("#wpbody-content .ced_ebay_overlay").remove();
					var response  = jQuery.parseJSON( response );
					var response1 = jQuery.trim( response.message );
					if (response.status == 200) {
						var id               = response.prodid;
						var Response_message = jQuery.trim( response.message );
						var product_title    = jQuery.trim(response.title);
						var notice           = "";

							notice              += "<div class='notice notice-success' style='margin-left:0px;margin-top:15px;'><p><b>"+response.title + "</b> >> " + response.message + ". Please refresh the page!</p></div>";

						$( ".ced-ebay-products-view-notice" ).append( notice );
						if (Response_message == 'Product Deleted Successfully') {
							$( "#" + id + "" ).html( '<b class="not_completed">Not Uploaded</b>' );
							$( "." + id + "" ).remove();
						} else {
							$( "#" + id + "" ).html( '<b class="success_upload_on_ebay">Uploaded</b>' );
						}

						var remainig_products_id = ebay_products_id.splice( 1 );
						if (remainig_products_id == "") {
							return;
						} else {
							performBulkAction( remainig_products_id,operation );
						}

					} else if (response.status == 400) {
						var notice = "";
						notice    += "<div class='notice notice-error' style='margin-left:0px;margin-top:15px;'><p><b>"+response.title + "</b> >> " + response.message + "</p></div>";
						$( ".ced-ebay-products-view-notice" ).append( notice );
						var remainig_products_id = ebay_products_id.splice( 1 );
						if (remainig_products_id == "") {
							return;
						} else {
							performBulkAction( remainig_products_id,operation );
						}

					}
				}
			}
		);
	}


	$( document ).on(
		'click',
		'#ced_ebay_bulk_import',
		function(e){
			e.preventDefault();
			var operation = $( ".bulk-action-selector" ).val();
			if (operation <= 0 ) {
				var notice = "";
				notice    += "<div class='notice notice-error'><p>Please Select Operation To Be Performed</p></div>";
				$( ".success-admin-notices" ).append( notice );
			} else {
				var operation        = $( ".bulk-action-selector" ).val();
				var ebay_products_id = new Array();
				$( '.ebay_products_id:checked' ).each(
					function(){
						ebay_products_id.push( $( this ).val() );
					}
				);

				performBulkImportAction( ebay_products_id,operation );
			}

		}
	);

	function performBulkImportAction(ebay_products_id,operation)
		{
		if (ebay_products_id == "") {
			var notice = "";
			notice    += "<div class='notice notice-error is-dismissiable'><p>No Products Selected</p><button type='button' class='notice-dismiss'><span class='screen-reader-text'>Dismiss this notice.</span></button></div>";
			$( "#wpbody" ).prepend( notice );
			return;
		}
		jQuery('#wpbody-content').append(ebay_loader_overlay);
			jQuery('#ced_ebay_progress_text').html('Importing selected eBay listings...<br><br><p style="font-size:16px;">If you are stuck at this loading screen please contact support using the live chat button on the bottom right!</p>');

		$.ajax(
			{
				url : ajaxUrl,
				data : {
					ajax_nonce : ajaxNonce,
					action : 'ced_ebay_bulk_import_to_store',
					operation_to_be_performed : operation,
					products_id : ebay_products_id,
					userid:user_id
				},
				type : 'POST',
				success: function(response)
				{
					jQuery('#wpbody-content .ced_ebay_overlay').remove();
					if (response.status == 'Bulk Import Successful') {
						var notice = "";
						notice    += '<div class="notice notice-success is-dismissible"><p>' + response.title + ' Imported Successfully</p><button type="button" class="notice-dismiss"><span class="screen-reader-text">Dismiss this notice.</span></button></div>';
						$( ".success-admin-notices" ).append( notice );
						var remainig_products_id = ebay_products_id.splice( 1 );
						if (remainig_products_id == "") {
							return;
						} else {
							performBulkImportAction( remainig_products_id,operation );
						}

					} else if(response.status == 'Bulk Import Error'){
						var notice = "";
						notice    += '<div class="notice notice-success is-dismissible"><p>' + response.title + '</p><button type="button" class="notice-dismiss"><span class="screen-reader-text">Dismiss this notice.</span></button></div>';
						$( ".success-admin-notices" ).append( notice );
						return;
					}

					else {
						var notice = "";
						notice    += "<div class='notice notice-success is-dismissible inline'><p>" + response.title + " Imported Successfully</p></div>";
						$( ".success-admin-notices" ).append( notice );
						var remainig_products_id = ebay_products_id.splice( 1 );
						if (remainig_products_id == "") {
							return;
							location.reload();
						} else {
							performBulkImportAction( remainig_products_id,operation );
						}

					}

				}
				}
		);
	}
	jQuery( document ).on(
		"click",
		".ced_ebay_site_add_description_template_button",
		function(event) {
			event.preventDefault();
			jQuery(document).find('.notice-empty-field-description-template').remove();
			jQuery( document ).find( '.description-template-name' ).val( "" );
			jQuery( document ).find( '#dt_css_textarea' ).val( "" );
			jQuery( '#ced_umb_ebay_description_template_ifr' ).contents().find( '#tinymce' ).html( "" );
			jQuery( document ).find( "#ced-ebay-popup.overlay" ).css( 'visibility','visible' );
			jQuery( document ).find( "#ced-ebay-popup.overlay" ).css( 'opacity',1 );
		}
	);



	jQuery(document).on("click", "#ced_ebay_marketing_do_login", function(event){
		event.preventDefault();
		var user_id_parameter = jQuery(this).attr('data-user-id');
		var loginMode = jQuery(this).attr('data-login-mode');
		var ebay_site_id = jQuery('#ced_ebay_login_select_site option:selected').val();
		if(ebay_site_id == -1){
			alert('Please select your eBay Account Region, from the dropdown, before login!');
			return;
		}
		if(ebay_site_id === undefined || ebay_site_id === null){
			ebay_site_id = jQuery(this).attr('data-site-id');
		}
		jQuery('#wpbody-content').append(ebay_loader_overlay);
		jQuery('#ced_ebay_progress_text').html('Please wait while we connect your eBay Account');
		jQuery.ajax({
			url: ajaxUrl,
			type: 'post',
			data: {
				ajax_nonce: ajaxNonce,
				action: 'ced_ebay_oauth_authorization',
				site_id: ebay_site_id,
				login_mode : loginMode,
			},
			success: function(response) {
				var response = jQuery.parseJSON( response );
				jQuery( '.ced_ebay_loader' ).hide();
				if(response != ''){
					window.location.replace(response);
				} else {
					alert('Failed to fetch Authorization URL! Please contact support.');
					return;
				}

			}
		})
	});


	jQuery(document).on("click", "#get_marketing_campaigns", function(event){
		event.preventDefault();
		jQuery( '.ced_ebay_loader' ).show();
		jQuery.ajax({
			url: ajaxUrl,
			type: 'post',
			data: {
				ajax_nonce: ajaxNonce,
				userid: user_id,
				action: 'ced_ebay_get_marketing_ad_campaigns'
			},
			success: function(response){
				response = jQuery.parseJSON(response);
				jQuery( '.ced_ebay_loader' ).hide();

				Swal.fire({
						  title:response.title,
						  text: response.message,
						  icon: response.status,
					}).then(() => {window.location.reload();});
			}
		})
	});


	jQuery(document).on("click", "#ced_ebay_submit_listing_ad_rate", function(event){
		event.preventDefault();
		var campaign_id = jQuery( this ).data( 'campaign-id' );
		var listing_id = jQuery(this).data('listing-id');
		var ad_rate = jQuery("#enter_campaign_listing_ad_rate").val();
		jQuery.ajax({
			url: ajaxUrl,
			type: 'post',
			data: {
				ajax_nonce: ajaxNonce,
				userid: user_id,
				campaignId: campaign_id,
				adRate: ad_rate,
				listingId: listing_id,
				action: 'ced_ebay_submit_ad_rate_for_product_listing'
			},
			success: function (response){
				console.log('success');
			}
		})
	});

	jQuery(document).on("click", "#ced_ebay_fetch_marketplace_promotions", function(event){
		event.preventDefault();
		jQuery( '.ced_ebay_loader' ).show();
		jQuery.ajax({
			type: 'post',
			url: ajaxUrl,
			data: {
				userid:user_id,
				ajax_nonce: ajaxNonce,
				action: 'ced_ebay_get_marketplace_promotions'
			},
			success: function(response){
				response = jQuery.parseJSON(response);
				jQuery( '.ced_ebay_loader' ).hide();
				swal({
						  title:response.title,
						  text: response.message,
						  icon: response.status,
					}).then(() => {window.location.reload();});
			}
		})
	});

	jQuery(document).on("click", "#ced_ebay_delete_campaign_ad_button", function(event){
		event.preventDefault();
		var campaign_id = jQuery(this).data('campaign-id');
		var ad_id = jQuery(this).data('listing-ad-id');
		swal({
			text: "Are you sure you want to delete this Ad?",
			icon: "warning",
			buttons: true,
			dangerMode: true,
		  }).then((willDelete)=>{
			  if(willDelete){
				jQuery('.ced_ebay_loader').show();
					jQuery.ajax({
						type:'post',
						url: ajaxUrl,
						data: {
							userid: user_id,
							ajax_nonce: ajaxNonce,
							campaignId: campaign_id,
							adId: ad_id,
							action: 'ced_ebay_delete_campaign_ad'
						},
						success: function(response){
						response = jQuery.parseJSON(response);
						jQuery('.ced_ebay_loader').hide();
						swal({
							title:response.title,
							text: response.message,
							icon: response.status,
					  });
						}
					})
			  }
			});
	});


	jQuery(document).on("click", "#save_marketing_campaign_global_settings", function(event){
		event.preventDefault();
		jQuery( '.ced_ebay_loader' ).show();
		var campaign_id = jQuery('#ced_ebay_select_marketing_campaign option:selected').val();
		var campaign_bid_percentage = jQuery('#ced_ebay_campaign_bid_percentage').val();
		var rounded_campaign_ad_rate = campaign_bid_percentage.split('.')[1] ? (Math.round(parseFloat(campaign_bid_percentage) * 10)/10).toFixed(1) : campaign_bid_percentage;
		jQuery('#ced_ebay_campaign_bid_percentage').val(rounded_campaign_ad_rate);
		jQuery.ajax({
			type:'post',
			url:ajaxUrl,
			data: {
				userid: user_id,
				ajax_nonce: ajaxNonce,
				campaignID: campaign_id,
				bid_percentage: rounded_campaign_ad_rate,
				action: 'ced_ebay_save_marketing_campaign_global_settings'
			},
			success: function(response){
				response = jQuery.parseJSON(response);
				jQuery( '.ced_ebay_loader' ).hide();
				swal({
						  title:response.title,
						  text: response.message,
						  icon: response.status,
					});
			}
		})

	});


	

	jQuery(document).on('click', '#ced_ebay_show_ext_cron_url_btn', function(e){
		e.preventDefault();		
			$( this ).WCBackboneModal({
			template: 'wc-ced-ebay-show-ext-cron-urls-modal'
			});
		});
	

	jQuery(document).on('click', '#ced_ebay_toggle_bulk_update_btn', function(e){
		e.preventDefault();
		
		var action = jQuery(this).attr('data-action');
		if('turn_on' == action){

			$( this ).WCBackboneModal({
			template: 'wc-ced-ebay-bulk-update-modal'
			});
			}
		});
		
	jQuery(document).on('click', '#ced_ebay_modify_listing_button', function(e){

	var productId = $(this).attr('data-prod-id');
	jQuery('#wpbody-content').append(ebay_loader_overlay);
	jQuery('#ced_ebay_progress_text').html('Please wait while we are fetching the product\'s data');
	e.preventDefault();
	var detailsBtn = jQuery(this);
	if(detailsBtn.data('cedEbayProductsData')){
		jQuery('#wpbody-content .ced_ebay_overlay').remove();
	jQuery( this ).WCBackboneModal({
	template: 'wc-ced-ebay-modify-product-modal',
	variable: detailsBtn.data('cedEbayProductsData')
	});
	} else {	
	jQuery.ajax({
	url: ajaxUrl,
	type: 'POST',
	data:{
	ajax_nonce: ajaxNonce,
	user_id: user_id,
	action: 'ced_ebay_get_product_details',
	product_id: productId
	},
	success: function(response){
	e.preventDefault();
	if(response.success == true){
	console.log(response);
	detailsBtn.data('cedEbayProductsData', response.data);
	jQuery('#wpbody-content .ced_ebay_overlay').remove();
	jQuery( this ).WCBackboneModal({
	template: 'wc-ced-ebay-modify-product-modal',
	variable: response.data
	});
	}
	
	}
	})
	
	}
	
	
	});

	jQuery( function() {
		jQuery( "#accordion" ).accordion({
		  heightStyle: "content"
		});
	  });
	  var campaignStartDate, campaignEndDate;
	jQuery(function(){
		var modalToTarget = document.getElementById('ced_ebay_clone_campaign_dialog');
		flatpickr("#ced_ebay_clone_campaign_start_date", {
			dateFormat: 'Z',
			enableTime: true,
			minDate: 'today',
			static: true,

			onChange: function(selectedDates) {
				campaignStartDate = selectedDates.map(date => date.toISOString());
			}

		  });
		 flatpickr("#ced_ebay_clone_campaign_end_date", {
			minDate:'today',
			maxDate:new Date().fp_incr(365),
			dateFormat: 'Z',
			static: true,
			enableTime: true,
			onChange: function(selectedDates) {
				campaignEndDate = selectedDates.map(date => date.toISOString());
			}
		  });

	});

	jQuery(function(){
		var dialog, form,
		campaign_name = jQuery("#ced_ebay_clone_campaign_name"),
		campaign_ad_rate = jQuery("#ced_ebay_clone_campaign_ad_rate"),
		allFields = jQuery([]).add(campaign_name).add(campaign_ad_rate),
		tips = jQuery(".validateTips");



		function checkRegexp( o, regexp, n ) {
			if ( !( regexp.test( o.val() ) ) ) {
			  o.addClass( "ui-state-error" );
			  updateTips( n );
			  return false;
			} else {
			  return true;
			}
		  }
		  function updateTips( t ) {
			tips
			  .text( t )
			  .addClass( "ui-state-highlight" );
			setTimeout(function() {
			  tips.removeClass( "ui-state-highlight", 1500 );
			}, 500 );
		  }

		  function checkAdRate( o, min, max ) {
			if ( o.val() > max || o.val() < min ) {
			o.addClass( "ui-state-error" );
			updateTips( "Ad Rate must be between " +
				min + " and " + max + "." );
			  return false;
			} else {
				return true;
			}
		  }

		  function roundAdRate(val){
			var t=val;
			var rounded = t.split('.')[1] ? (Math.round(parseFloat(t) * 10)/10).toFixed(1) : t;
			return rounded;
		  }

		  function checkCampaignNameLength(o, min) {
			if ( o.val().length < min ) {
				o.addClass( "ui-state-error" );
				updateTips( "Campaign name can't be empty." );
				return false;
			  } else {
				return true;
			  }
		  }


		  function cloneCampaign(campaignID,campaignOperation, campaignStartDate, campaignEndDate){
			var valid = true;
			allFields.removeClass('ui-state-error');
			valid = valid && checkRegexp(campaign_name, /^[a-zA-Z0-9_ ]*$/, "Campaign name may only consist of alphabets and numbers.");
			valid = valid && checkAdRate(campaign_ad_rate, 1, 100);
			valid = valid && checkCampaignNameLength(campaign_name, 1);
			if(valid){
				var new_campaign_ad_rate = roundAdRate(campaign_ad_rate.val());
				$('.ced_ebay_loader').show();
				$.ajax({
					type: 'post',
					url:ajaxUrl,
					data: {
						userid: user_id,
						ajax_nonce:ajaxNonce,
						campaign_id: campaignID,
						campaign_start_date: campaignStartDate[0],
						campaign_end_date: campaignEndDate[0],
						campaignName: campaign_name.val(),
						campaignAdRate: new_campaign_ad_rate,
						process_action: campaignOperation,
						action: 'ced_ebay_perform_ad_campaign_operations'
					},
					success: function(response){
						response = jQuery.parseJSON(response);
						dialog.dialog("close");
						jQuery('.ced_ebay_loader').hide();
						swal({
							title:response.title,
							text: response.message,
							icon: response.status,
					  });
					}
				});
			}
			return valid;
		  }


		dialog = jQuery( "#ced_ebay_clone_campaign_form" ).dialog({
			autoOpen: false,
			height: 750,
			width: 650,
			modal: true,
			buttons: {
			  "Clone": function(){
				var campaignID = $(this).data('campaignID');
				var campaignOperation = $(this).data('campaignOperation');
				cloneCampaign(campaignID, campaignOperation, campaignStartDate, campaignEndDate);
			},
			  Cancel: function() {
				dialog.dialog( "close" );
			  }
			},
			close: function() {
				$("#ced_ebay_clone_campaign_form").trigger("reset");
				allFields.removeClass( "ui-state-error" );
			  }
		  });

		  form = dialog.find( "#ced_ebay_clone_campaign_form" ).on( "submit", function( event ) {
			event.preventDefault();
			cloneCampaign();
		  });


		  jQuery(document).on("click", "#ced_ebay_clone_campaign_action_button", function(){
			var campaign_id = jQuery(this).attr('data-campaign-id');
			var performAction = jQuery(this).attr('data-campaign-action');
			dialog.data('campaignID', campaign_id);
			dialog.data('campaignOperation', performAction);
			dialog.dialog("open");

		})

	});

	jQuery(document).on("click", "#ced_ebay_delete_campaign_action_button", function(event){
		event.preventDefault();
		var campaignID = jQuery(this).attr('data-campaign-id');
		var performAction = jQuery(this).attr('data-campaign-action');
		swal({
			text: "Are you sure you want to delete this campaign?",
			icon: "warning",
			buttons: true,
			dangerMode: true,
		  }).then((willDelete)=>{
			  if(willDelete){
				jQuery('.ced_ebay_loader').show();
				$.ajax({
					type: 'post',
					url:ajaxUrl,
					data: {
						ajax_nonce:ajaxNonce,
						campaign_id: campaignID,
						userid: user_id,
						process_action: performAction,
						action: 'ced_ebay_perform_ad_campaign_operations'
					},
					success: function(response){
						response = jQuery.parseJSON(response);
						jQuery('.ced_ebay_loader').hide();
						swal({
							title:response.title,
							text: response.message,
							icon: response.status,
					  });
					}

				});
			  } else {
				window.location.reload();
			  }
		  })


	});



	jQuery(document).on("click", "#ced_ebay_end_campaign_action_button", function(event){
		event.preventDefault();
		var campaignID = jQuery(this).attr('data-campaign-id');
		var performAction = jQuery(this).attr('data-campaign-action');
		swal({
			text: "Are you sure you want to end this campaign?",
			icon: "warning",
			buttons: true,
			dangerMode: true,
		  }).then((willEnd)=>{
			  if(willEnd){
				jQuery('.ced_ebay_loader').show();
				$.ajax({
					type: 'post',
					url:ajaxUrl,
					data: {
						ajax_nonce:ajaxNonce,
						campaign_id: campaignID,
						userid: user_id,
						process_action: performAction,
						action: 'ced_ebay_perform_ad_campaign_operations'
					},
					success: function(response){
						response = jQuery.parseJSON(response);
						jQuery('.ced_ebay_loader').hide();
						swal({
							title:response.title,
							text: response.message,
							icon: response.status,
					  });
					}

				});
			  } else {
				window.location.reload();
			  }
		  })

	});

	jQuery(document).on("click", "#ced_ebay_pause_campaign_action_button", function(event){
		event.preventDefault();
		$( '.ced_ebay_loader' ).show();
		var performAction = jQuery(this).attr('data-campaign-action');
		var campaignId = jQuery(this).attr('data-campaign-id');
		jQuery.ajax({
			type:'post',
			url: ajaxUrl,
			data: {
				ajax_nonce: ajaxNonce,
				userid: user_id,
				process_action: performAction,
				campaign_id: campaignId,
				action: 'ced_ebay_perform_ad_campaign_operations'
			},

			success: function(response){
				response = jQuery.parseJSON(response);
				jQuery('.ced_ebay_loader').hide();
				swal({
					title:response.title,
					text: response.message,
					icon: response.status,
			  });
			}
		});

	});

	jQuery(document).on("click", "#ced_ebay_resume_campaign_action_button", function(event){
		event.preventDefault();
		$( '.ced_ebay_loader' ).show();
		var performAction = jQuery(this).attr('data-campaign-action');
		var campaignId = jQuery(this).attr('data-campaign-id');
		jQuery.ajax({
			type:'post',
			url: ajaxUrl,
			data: {
				ajax_nonce: ajaxNonce,
				userid: user_id,
				process_action: performAction,
				campaign_id: campaignId,
				action: 'ced_ebay_perform_ad_campaign_operations'
			},

			success: function(response){
				response = jQuery.parseJSON(response);
				jQuery('.ced_ebay_loader').hide();
				swal({
					title:response.title,
					text: response.message,
					icon: response.status,
			  });
			}
		});

	});

	jQuery(document).on('click', '#ced_ebay_profile_edit_btn', function(event){
		event.preventDefault();
		$( '.ced_ebay_loader' ).show();
		var eBayCatId = jQuery(this).data('ebay-cat-id');
		var profileID = jQuery(this).data('profile-id');
		if(eBayCatId == '' || profileID == ''){
			$( '.ced_ebay_loader' ).hide();
			Swal.fire({
				title: "Error",
				text: 'Failed to get the eBay Category ID or profile ID',
				icon: 'error',
		  });
		}
		jQuery.ajax({
			url: ajaxUrl,
			type: 'post',
			data: {
				ajax_nonce: ajaxNonce,
				user_id: user_id,
				action: 'ced_ebay_check_if_able_to_fetch_item_aspect',
				ebay_cat_id : eBayCatId,
				profile_id: profileID
			},
			success: function (response){
				$( '.ced_ebay_loader' ).hide();
				if(response.success == false){
					Swal.fire({
						title: "Error reading data",
						text: response.data.message,
						icon: 'error',
				  });
				}
				if(response.success == true){
					window.open(response.data.url, '_blank');

				}
				
			}
		})
		
	});

	jQuery(document).on("click", "#ced_ebay_create_listing_promotion", function(event){
		event.preventDefault();
		$( '.ced_ebay_loader' ).show();
		var product_id = jQuery(this).data('product-id');
		var listing_id = jQuery(this).data('listing-id');
		var use_global_ad_campaign = jQuery(this).data('use-global-ad-campaign');
		var use_global_ad_rate = jQuery(this).data('use-global-ad-rate');
		var ad_rate = jQuery("#ced_ebay_create_ad_rate").val();
		var campaign_id = jQuery("#ced_ebay_select_ad_campaign").val();
		jQuery.ajax({
			url: ajaxUrl,
			type: 'post',
			data: {
				ajax_nonce: ajaxNonce,
				userid: user_id,
				campaignId: campaign_id,
				adRate: ad_rate,
				listingId: listing_id,
				productId: product_id,
				useGlobalAdCampaign: use_global_ad_campaign,
				useGlobalAdRate: use_global_ad_rate,
				action: 'ced_ebay_create_listing_ad_promotion'
			},
			success: function (response){
				$( '.ced_ebay_loader' ).hide();
				response = jQuery.parseJSON(response);
				if(response.status == 'error'){
					swal({
						title: "Error",
						text: response.message,
						icon: response.status,
				  });
				}
				else{
					swal({
						title: "Success",
						text: response.message,
						icon: response.status,
				  }).then(() => {window.location.reload();});
				}
			}
		})
	});





	jQuery(function(){
		var createCampaignStartDate, createCampaignEndDate;

		jQuery(document).on("click", ".ced_ebay_create_campaign_action_button", function(event){
			event.preventDefault();
			var valid=true;
			var errors = jQuery(".showCreateCampaignErrors");
			var campaign_name = jQuery("#ced_ebay_create_campaign_name_input").val();
			var regexp = /^[a-zA-Z0-9_ ]*$/;
			var regexpAdRate = /^(\d*\.)?\d+$/;
			if ( !( regexp.test( campaign_name ) ) ) {
				errors.text('Campaign name can only contain Alphabets and Numbers');
				valid=false;
			}
			if(campaign_name.length < 1){
				errors.text('Campaign name can\'t be empty');
				valid=false;
			}
			var ad_rate = jQuery("#ced_ebay_create_campaign_ad_rate_input").val();

			if ( !( regexpAdRate.test( ad_rate ) ) ) {
				errors.text('Ad Rate can only contain numbers');
				valid=false;
			}
			if(ad_rate.length < 1){
				errors.text("Ad Rate can\'t be empty");
				valid=false;
			}

			var rounded_ad_rate = ad_rate.split('.')[1] ? (Math.round(parseFloat(ad_rate) * 10)/10).toFixed(1) : ad_rate;
			var campaign_start_date = createCampaignStartDate[0];

			if(valid){
				$( '.ced_ebay_loader' ).show();
				jQuery.ajax({
					url: ajaxUrl,
					type: 'post',
					data: {
						ajax_nonce: ajaxNonce,
						userid: user_id,
						campaignName: campaign_name,
						adRate: rounded_ad_rate,
						campaignStartDate: campaign_start_date,
						action: 'ced_ebay_create_promoted_listing_campaign'
					},
					success: function(response){
						$( '.ced_ebay_loader' ).hide();
				response = jQuery.parseJSON(response);
				if(response.status == 'error'){
					swal({
						title: "Error",
						text: response.message,
						icon: response.status,
				  });
				}
				else{
					swal({
						title: "Success",
						text: response.message,
						icon: response.status,
				  });
				}
					}
				})
			}

		});

		flatpickr("#ced_ebay_create_campaign_start_date", {
			dateFormat: 'Z',
			enableTime: true,
			minDate: 'today',
			static: true,
			defaultHour:new Date().getHours(),
			defaultMinute:new Date().getMinutes(),
			onChange: function(selectedDates) {
				createCampaignStartDate = selectedDates.map(date => date.toISOString());
			}

		  });


	});

	jQuery(document).on("click", "#ced_ebay_bulk_create_ad_rate_button", function(event){
		event.preventDefault();
		var valid=true;
		var errors = jQuery(".showBulkCreateAdErrors");
		var regexpAdRate = /^(\d*\.)?\d+$/;
		var ad_rate = jQuery("#ced_ebay_bulk_create_ad_rate").val();
		if ( !( regexpAdRate.test( ad_rate ) ) ) {
			errors.text('Ad Rate can only contain numbers');
			valid=false;
		}
		if(ad_rate.length < 1){
			errors.text("Ad Rate can\'t be empty");
			valid=false;
		}
		var rounded_ad_rate = ad_rate.split('.')[1] ? (Math.round(parseFloat(ad_rate) * 10)/10).toFixed(1) : ad_rate;
		var ebay_products_id = new Array();
		$( '.ebay_products_id:checked' ).each(
			function(){
				ebay_products_id.push( $( this ).val() );
			}
		);
		var campaign_id = jQuery('#ced_ebay_select_ad_campaign_for_bulk_create_ad_rate option:selected').val();
		if(campaign_id.length<1){
			errors.text('Please select a campaign');
			valid=false;
		}
		if(valid){
			$( '.ced_ebay_loader' ).show();
				jQuery.ajax({
					url: ajaxUrl,
					type: 'post',
					data: {
						ajax_nonce: ajaxNonce,
						userid: user_id,
						campaignId: campaign_id,
						adRate: rounded_ad_rate,
						eBaySelectedProducts: ebay_products_id,
						action: 'ced_ebay_bulk_create_product_ads'
					},
					success: function(response){
						$( '.ced_ebay_loader' ).hide();
						response = jQuery.parseJSON(response);
						if(response.status == 'error'){
							swal({
								title: "Error",
								text: response.message,
								icon: response.status,
								  });
							}
				else{
					swal({
						title: "Success",
						text: response.message,
						icon: response.status,
				  });
				}
					}
				})
		}


	});


	// handling promotion actions
	jQuery(document).on("click", "#ced_ebay_pause_promotion_button", function(event){
		event.preventDefault();
		var promotionID = jQuery(this).data('promotion-id');
		$( '.ced_ebay_loader' ).show();
		jQuery.ajax({
			url:ajaxUrl,
			type:'post',
			data:{
				ajax_nonce: ajaxNonce,
				userid: user_id,
				promotion_id: promotionID,
				action: 'ced_ebay_pause_promotion_action'
			},
			success: function(response){
				$( '.ced_ebay_loader' ).hide();
						response = jQuery.parseJSON(response);
						if(response.status == 'error'){
							swal({
								title: "Error",
								text: response.message,
								icon: response.status,
								  });
							}
				else{
					swal({
						title: "Success",
						text: response.message,
						icon: response.status,
				  });
				}
			}
		})
	});

	jQuery(document).on("click", "#ced_ebay_resume_promotion_button", function(event){
		event.preventDefault();
		var promotionID = jQuery(this).data('promotion-id');
		$( '.ced_ebay_loader' ).show();
		jQuery.ajax({
			url:ajaxUrl,
			type:'post',
			data:{
				ajax_nonce: ajaxNonce,
				userid: user_id,
				promotion_id: promotionID,
				action: 'ced_ebay_resume_promotion_action'
			},
			success: function(response){
				$( '.ced_ebay_loader' ).hide();
						response = jQuery.parseJSON(response);
						if(response.status == 'error'){
							swal({
								title: "Error",
								text: response.message,
								icon: response.status,
								  });
							}
				else{
					swal({
						title: "Success",
						text: response.message,
						icon: response.status,
				  });
				}
			}
		})
	});

	jQuery(document).on("click", ".notice-dismiss", function(event){
		event.preventDefault();
		jQuery(document).find(".notice").fadeTo(100, 0, function(){
			jQuery(document).find(".notice").slideUp(100, function(){
				jQuery(document).find(".notice").remove();
			});
		});
	});

	jQuery(document).on("click", "#ced_ebay_check_job_status_button", function(event){
		event.preventDefault();
		var job_id = jQuery(this).attr('data-job-id');
		var logs_url = jQuery(this).attr('href');
		jQuery( '.ced_ebay_loader' ).show();
		jQuery.ajax({
			url: ajaxUrl,
			type: 'post',
			data: {
				ajax_nonce : ajaxNonce,
				action: 'ced_ebay_status_feed_check_job_status_action',
				job_id: job_id,
				userid: user_id,
			},
			success(response){
				jQuery( '.ced_ebay_loader' ).hide();
				response = jQuery.parseJSON(response);
				if(response.status == 'success'){
					swal({
						title:'Job Status',
						text: response.message,
						icon: response.status,
				  });
				}
				if(response.status == 'finished'){
					swal({
						title:'Job Status',
						text: response.message,
						icon: 'success',
						buttons: {
							cancel: 'Ok',
							view_log : 'View Log',
						}
				  }).then((value) => {
					switch(value){
					  case 'view_log' :
						  var win = window.open(logs_url, '_blank');
						  if(win){
							  win.focus();
						  } else {
							  alert('Please allow popups to view logs');
						  }
						  break;
					}
				});
				}
				if(response.status == 'error'){
					swal({
						title:'Job Error',
						text: response.message,
						icon: 'error'
				  });
				}

			}
		})
	});

	

	jQuery(document).on(
		"click",
		"#ced_ebay_prod_error_log_button",
		function(event){
			event.preventDefault();
			var product_id = jQuery(this).data('product-id');
			var $modal = $('#ced_ebay_pro_errors_modal');
			jQuery( '.ced_ebay_loader' ).show();
			jQuery.ajax({
				url:ajaxUrl,
				type:'post',
				data:{
					ajax_nonce: ajaxNonce,
					user_id: user_id,
					product_id: product_id,
					action: 'ced_ebay_show_profile_bulk_upload_product_errors'
				},
				success: function(response){
					response = jQuery.parseJSON(response);
					if(response.status == 'success'){
						var error_html = '<ul>';
						jQuery( '.ced_ebay_loader' ).hide();
						jQuery.each(response.data, function(i, error){
								error_html = error_html + '<li>' + error + '</li>';
						});
						error_html = error_html + '</ul>';
						jQuery(document).find(".ced_ebay_pro_errors_modal-inner").html(error_html);
						cedEbayErrorLogOpenModal($modal);
					} else if(response.status == 'error'){
						jQuery( '.ced_ebay_loader' ).hide();
						error_html = '<h3>Failed to fetch Error Log</h3>';
						jQuery(document).find(".ced_ebay_pro_errors_modal-inner").html(error_html);
						cedEbayErrorLogOpenModal($modal);
					}
				}
			})
		}
	)

	function cedEbayErrorLogOpenModal($modal) {
		var scrollBarWidth = window.innerWidth - document.body.offsetWidth;
		$('body')
		  .css('margin-right', scrollBarWidth)
		  .addClass('showing-error-modal');
		$modal.show();
	  };



	jQuery(document).on('click', '#ced_ebay_disconnect_account_btn', function(e){
		e.preventDefault();
		Swal.fire({
			text: "Are you sure you want to disconnect your account? Disconnecting your account will stop all the automation. Your configuration will not be deleted.",
			icon: "warning",
			showCancelButton: true,
  			confirmButtonColor: '#3085d6',
  			cancelButtonColor: '#d33',
			confirmButtonText: 'Yes, do it!'
		}).then((willRemoveAccount) => {
			if(willRemoveAccount.isConfirmed){
				jQuery('.ced_ebay_loader').show();
				jQuery.ajax({
					type:'post',
					url: ajaxUrl,
					data: {
						userid: user_id,
						ajax_nonce: ajaxNonce,
						action: 'ced_ebay_remove_account_from_integration'
					},
					success: function(response){
						jQuery('.ced_ebay_loader').hide();
						Swal.fire({
							title:response.title,
							text: response.message,
							icon: response.status,
					  }).then(()=>{
						window.location.reload();
					  });
					}
				})
			}
	  });
	});

	jQuery(document).on('click', '#ced_ebay_remove_all_profiles_btn', function(e){
		e.preventDefault();
		Swal.fire({
			text: "Are you sure you want to Remove all the profiles? This action is irreversible. Your category mappings will also be removed.",
			icon: "warning",
			showCancelButton: true,
  			confirmButtonColor: '#3085d6',
  			cancelButtonColor: '#d33',
			confirmButtonText: 'Yes, do it!'
		}).then((willRemoveProfiles) => {
			if(willRemoveProfiles.isConfirmed){
				jQuery('.ced_ebay_loader').show();
				jQuery.ajax({
					type:'post',
					url: ajaxUrl,
					data: {
						userid: user_id,
						ajax_nonce: ajaxNonce,
						action: 'ced_ebay_remove_all_profiles'
					},
					success: function(response){
						jQuery('.ced_ebay_loader').hide();
						Swal.fire({
							title:response.title,
							text: response.message,
							icon: response.status,
					  }).then(()=>{
						window.location.reload();
					  });
					}
				})
			}
	  });
	});

	jQuery(document).on('click', '#ced_ebay_reset_item_aspects_btn', function(e){
		e.preventDefault();
		Swal.fire({
			text: "Are you sure you want to Remove the category item specifcs? This action will remove all the eBay category item specifics and will fetch them again when you will edit the profile.",
			icon: "warning",
			showCancelButton: true,
  			confirmButtonColor: '#3085d6',
  			cancelButtonColor: '#d33',
			confirmButtonText: 'Yes, do it!'
		}).then((willRemoveProfiles) => {
			if(willRemoveProfiles.isConfirmed){
				jQuery('.ced_ebay_loader').show();
				jQuery.ajax({
					type:'post',
					url: ajaxUrl,
					data: {
						userid: user_id,
						ajax_nonce: ajaxNonce,
						action: 'ced_ebay_reset_category_item_specifics'
					},
					success: function(response){
						jQuery('.ced_ebay_loader').hide();
						Swal.fire({
							title:response.title,
							text: response.message,
							icon: response.status,
					  }).then(()=>{
						window.location.reload();
					  });
					}
				})
			}
	  });
	});


	jQuery(document).on('click', '#ced_ebay_remove_term_from_profile_btn', function(e){
		e.preventDefault();
		var termID = jQuery(this).attr('data-term-id');
		var profileID = jQuery(this).attr('data-profile-id');
		Swal.fire({
			text: "Are you sure you want to remove the WooCommerce category from this profile?",
			icon: "warning",
			showCancelButton: true,
  			confirmButtonColor: '#3085d6',
  			cancelButtonColor: '#d33',
			confirmButtonText: 'Yes, do it!'
		}).then((willRemoveProfiles) => {
			if(willRemoveProfiles.isConfirmed){
				jQuery('.ced_ebay_loader').show();
				jQuery.ajax({
					type:'post',
					url: ajaxUrl,
					data: {
						userid: user_id,
						term_id: termID,
						profile_id : profileID,
						ajax_nonce: ajaxNonce,
						action: 'ced_ebay_remove_term_from_profile'
					},
					success: function(response){
						jQuery('.ced_ebay_loader').hide();
						Swal.fire({
							title:response.title,
							text: response.message,
							icon: response.status,
					  })
					  .then(()=>{
						window.location.reload();
					});
					}
				});
			}
	  });
	});



	// jQuery(document).on('click', '#ced_ebay_toggle_bulk_update_btn', function(e){
	// 	e.preventDefault();
	// 	var action = jQuery(this).attr('data-action');
	// 	if(action == 'turn_on'){
	// 		Swal.fire({
	// 			icon: "warning",
	// 			showCancelButton: true,
  	// 			confirmButtonColor: '#3085d6',
  	// 			cancelButtonColor: '#d33',
	// 			confirmButtonText: 'Yes, let\'s go!',
	// 			html: 
    // '<select id="my-select2">' +
    //   '<option value="AL">Alabama</option>' +
    //   '<option value="WY">Wyoming</option>' +
    // '</select>',
	// 			didOpen: function (){
	// 				$("#swal2-html-container #my-select2").selectWoo({
	// 					dropdownPosition: 'below',
	// 				});
	// 			}
	// 		}).then((willBulkUpdate) => {
	// 			if(willBulkUpdate.isConfirmed){
	// 				// jQuery('#wpbody-content').append(ebay_loader_overlay);
	// 				// jQuery("#ced_ebay_progress_text").html("Gathering the required data for Bulk Upload...");
	// 				jQuery.ajax({
	// 					type:'post',
	// 					url: ajaxUrl,
	// 					data: {
	// 						userid: user_id,
	// 						ajax_nonce: ajaxNonce,
	// 						toggle_action: action,
	// 						action: 'ced_ebay_toggle_bulk_upload_action'
	// 					},
	// 					success: function(response){
	// 						jQuery('#wpbody-content .ced_ebay_overlay').remove();
	// 						response = jQuery.parseJSON(response);
	// 						Swal.fire({
	// 							title:response.title,
	// 							html: response.message,
	// 							icon: response.status,
	// 					  }).then(()=>{
	// 						window.location.reload();
	// 					  });
	// 					}
	// 				})
	// 			}
	// 	  });
	// 	}
	// });


	jQuery(document).on('click', '#ced_ebay_toggle_bulk_upload_btn', function(e){
		e.preventDefault();
		var action = jQuery(this).attr('data-action');
		if(action == 'turn_on'){
			Swal.fire({
				text: "Are you sure you want to Upload all your products to eBay? We will fetch all the profiles and send the Product data for upload. Please make sure that you have mapped the categories and setup the profiles. You can view the status of Bulk Upload by clicking on the Feed Management link above.",
				icon: "warning",
				showCancelButton: true,
  				confirmButtonColor: '#3085d6',
  				cancelButtonColor: '#d33',
				confirmButtonText: 'Yes, let\'s go!'
			}).then((willBulkUpload) => {
				if(willBulkUpload.isConfirmed){
					jQuery('#wpbody-content').append(ebay_loader_overlay);
					jQuery("#ced_ebay_progress_text").html("Gathering the required data for Bulk Upload...");
					jQuery.ajax({
						type:'post',
						url: ajaxUrl,
						data: {
							userid: user_id,
							ajax_nonce: ajaxNonce,
							toggle_action: action,
							action: 'ced_ebay_toggle_bulk_upload_action'
						},
						success: function(response){
							jQuery('#wpbody-content .ced_ebay_overlay').remove();
							response = jQuery.parseJSON(response);
							Swal.fire({
								title:response.title,
								html: response.message,
								icon: response.status,
						  }).then(()=>{
							window.location.reload();
						  });
						}
					})
				}
		  });
		} else if(action == 'turn_off'){
			Swal.fire({
				text: "Are you sure you want to turn off Bulk Upload? This action will clear current products queue. Any products already uploaded won\'t be affected!",
				icon: "warning",
				showCancelButton: true,
  				confirmButtonColor: '#3085d6',
  				cancelButtonColor: '#d33',
				confirmButtonText: 'Yes, do it!'
			}).then((willBulkUpload) => {
				if(willBulkUpload.isConfirmed){
					jQuery('.ced_ebay_loader').show();
						jQuery.ajax({
						type:'post',
						url: ajaxUrl,
						data: {
							userid: user_id,
							ajax_nonce: ajaxNonce,
							toggle_action: action,
							action: 'ced_ebay_toggle_bulk_upload_action'
						},
						success: function(response){
							jQuery('.ced_ebay_loader').hide();
							response = jQuery.parseJSON(response);
							Swal.fire({
								title:response.title,
								text: response.message,
								icon: response.status,
						  }).then(()=>{
							window.location.reload();
						  });
						}
					})
				}
		  });
		}
	});

	jQuery(document).on('click', '#ced_ebay_del_blk_upld_logs_btn', function(e){
		e.preventDefault();
		jQuery('#wpbody-content').append(ebay_loader_overlay);
		jQuery("#ced_ebay_progress_text").html("Clearing logs...");
		jQuery.ajax({
			type:'post',
			url: ajaxUrl,
			data: {
				userid: user_id,
				ajax_nonce: ajaxNonce,
				action: 'ced_ebay_delete_bulk_upload_logs_action'
			},
			success: function(response){
				jQuery('#wpbody-content .ced_ebay_overlay').remove();
				response = jQuery.parseJSON(response);
				Swal.fire({
					title:response.title,
					text: response.message,
					icon: response.status,
			  }).then(()=>{
				window.location.reload();
			  });
			}
		})

	});

	jQuery(document).on('click', '#ced_ebay_toggle_bulk_inventory_btn', function(e){
		e.preventDefault();
		var action = jQuery(this).attr('data-action');
		if(action == 'turn_on'){
			Swal.fire({
				text: "Are you sure you want to update inventory for all your products on eBay? To sync price as well, turn on the price synchronisation option in the General Settings of our plugin.",
				icon: "warning",
				showCancelButton: true,
  				confirmButtonColor: '#3085d6',
  				cancelButtonColor: '#d33',
				confirmButtonText: 'Turn On'
			}).then((willBulkUpdateInventory) => {
				if(willBulkUpdateInventory.isConfirmed){
					jQuery('.ced_ebay_loader').show();
					jQuery.ajax({
						type:'post',
						url: ajaxUrl,
						data: {
							userid: user_id,
							ajax_nonce: ajaxNonce,
							toggle_action: action,
							action: 'ced_ebay_toggle_bulk_inventory_action'
						},
						success: function(response){
							jQuery('.ced_ebay_loader').hide();
							Swal.fire({
								title:response.title,
								text: response.message,
								icon: response.status,
						  }).then(()=>{
							window.location.reload();
						  });
						}
					})
				}
		  });
		} else if(action == 'turn_off'){
			Swal.fire({
				text: "Are you sure you want to turn off Bulk Inventory Update?",
				icon: "warning",
				showCancelButton: true,
  				confirmButtonColor: '#3085d6',
  				cancelButtonColor: '#d33',
				confirmButtonText: 'Turn Off'
			}).then((willBulkUpdateInventory) => {
				if(willBulkUpdateInventory.isConfirmed){
					jQuery('.ced_ebay_loader').show();
					jQuery.ajax({
						type:'post',
						url: ajaxUrl,
						data: {
							userid: user_id,
							ajax_nonce: ajaxNonce,
							toggle_action: action,
							action: 'ced_ebay_toggle_bulk_inventory_action'
						},
						success: function(response){
							jQuery('.ced_ebay_loader').hide();
							Swal.fire({
								title:response.title,
								text: response.message,
								icon: response.status,
						  }).then(()=>{
							window.location.reload();
						  });
						}
					})
				}
		  });
		}
	});

	jQuery(document).on('click', '#ced_ebay_fetch_single_order_btn', function(e){
		e.preventDefault();
		var order_id = jQuery(document).find("#ced_ebay_fetch_single_order_input").val();
		if(order_id == ''){
			alert('Please enter a valid eBay Order ID');
			return;
		}

		jQuery('.ced_ebay_loader').show();
		jQuery.ajax({
			type:'post',
			url: ajaxUrl,
			data: {
				userid: user_id,
				ajax_nonce: ajaxNonce,
				order_id: order_id,
				action: 'ced_ebay_fetch_order_using_order_id'
			},
			success: function(response){
				jQuery('.ced_ebay_loader').hide();
				response = jQuery.parseJSON(response);
				if(response.status == 'success'){
					var notice = "";
					notice    += "<div class='notice notice-error'><p>Order " + order_id + " Fetched Successfully</p></div>";
					$(document).find( ".success-admin-notices" ).append( notice );
					window.location.reload();
				} else if(response.status == 'No Results'){
					var notice = "";
					notice    += "<div class='notice notice-error'><p>We can\'t fetch Order " +order_id+ ". It might have been that you may have entered an Invalid Order ID. If the issue still persists, please contact support.</p></div>";
					$(document).find( ".success-admin-notices" ).append( notice );
				}
			}
		})
	});

	jQuery(document).on('click', '#ced_ebay_toggle_import_orders_btn', function(e){
		e.preventDefault();
		var action = jQuery(this).attr('data-action');
		if(action == 'turn_on'){
			Swal.fire({
				text: "Are you sure you want to start importing of last 3 days orders from eBay to WooCommerce ? If we are unable to find the ordered Product, on eBay, in your WooCommerce store on the basis of SKU we will skip importing that particular eBay Order.",
				icon: "warning",
				showCancelButton: true,
  				confirmButtonColor: '#3085d6',
  				cancelButtonColor: '#d33',
				confirmButtonText: 'Turn On'
			}).then((willImportOrder) => {
				if(willImportOrder.isConfirmed){
					jQuery('.ced_ebay_loader').show();
					jQuery.ajax({
						type:'post',
						url: ajaxUrl,
						data: {
							userid: user_id,
							ajax_nonce: ajaxNonce,
							toggle_action: action,
							action: 'ced_ebay_toggle_import_orders_scheduler'
						},
						success: function(response){
							jQuery('.ced_ebay_loader').hide();
							Swal.fire({
								title:response.title,
								text: response.message,
								icon: response.status,
						  }).then(()=>{
							window.location.reload();
						  });
						}
					})
				}
		  });
		} else if(action == 'turn_off'){
			Swal.fire({
				text: "Are you sure you want to turn off Order Sync?",
				icon: "warning",
				showCancelButton: true,
  				confirmButtonColor: '#3085d6',
  				cancelButtonColor: '#d33',
				confirmButtonText: 'Turn Off'
			}).then((willBulkUpdate) => {
				if(willBulkUpdate.isConfirmed){
					jQuery('.ced_ebay_loader').show();
					jQuery.ajax({
						type:'post',
						url: ajaxUrl,
						data: {
							userid: user_id,
							ajax_nonce: ajaxNonce,
							toggle_action: action,
							action: 'ced_ebay_toggle_import_orders_scheduler'
						},
						success: function(response){
							jQuery('.ced_ebay_loader').hide();
							Swal.fire({
								title:response.title,
								text: response.message,
								icon: response.status,
						  }).then(()=>{
							window.location.reload();
						  });
						}
					})
				}
		  });
		}
	});

	jQuery(document).on("click","#ced_ebay_toggle_import_products_filters", function(e){
		e.preventDefault();
		jQuery('.custom-actions-info-div').toggle();
	});



    function setParams(key, value){
        const params = new URLSearchParams(window.location.search);
		params.set(key, value);
		window.history.replaceState({}, "", decodeURIComponent(`${window.location.pathname}?${params}`));
    }




	$(document).on('change','input[name="ced_ebay_global_settings[ced_ebay_import_ebay_categories]"]', function(){
		if ( jQuery( 'input[name="ced_ebay_global_settings[ced_ebay_import_ebay_categories]"]:checked' ).val() == 'Enabled') {
			jQuery('#ced_ebay_select_categories_type_to_import').show();
		} else if( jQuery( 'input[name="ced_ebay_global_settings[ced_ebay_import_ebay_categories]"]:checked' ).val() == 'Disabled') {
			jQuery('#ced_ebay_select_categories_type_to_import').hide();

		}
	});

	$(document).on('change','input[name="ced_ebay_global_settings[ced_ebay_set_default_listing_profile]"]', function(){
		if ( jQuery( 'input[name="ced_ebay_global_settings[ced_ebay_set_default_listing_profile]"]:checked' ).val() == 'Enabled') {
			jQuery('#ced_ebay_select_categories_type_to_import').show();
		} else if( jQuery( 'input[name="ced_ebay_global_settings[ced_ebay_set_default_listing_profile]"]:checked' ).val() == 'Disabled') {
			jQuery('#ced_ebay_select_categories_type_to_import').hide();

		}
	});


	$(document).on('click', '#ced_ebay_begin_auto_update_button', function(e){
       e.preventDefault();
	   var selected_properties = [];
	   $('#ced_ebay_auto_update_selection_container input:checked').each(function() {
		selected_properties.push($(this).val());
	});
	if($.isArray(selected_properties) && selected_properties.length !== 0){
		// console.log(selected_properties);
		
	}
	});

	$(document).on('click', '#ced_ebay_set_as_default_profile_btn', function(e){
		var $this = $(this);
		var profileID = $(this).attr('data-profile-id');
		var btnAction = $(this).attr('data-action');
		$(this).prop("disabled", true);
		// add spinner to button
		$(this).html(
			`<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>
			Loading...`
		);
		if(profileID != null){
			jQuery.ajax({
				type:'post',
				url: ajaxUrl,
				data: {
					userid: user_id,
					ajax_nonce: ajaxNonce,
					set_or_remove: btnAction,
					profile_id: profileID,
					action: 'ced_ebay_set_a_default_listing_profile_action'
				},
				success: function(response){
					$this.prop("disabled", false);
					if('set' == btnAction){
						$this.removeClass("btn-primary");
					} else if('remove' == btnAction){
						$this.removeClass("btn-danger");										
					}
					if(response.status == 'success'){
					$this.addClass("btn-success");
					$this.html(
						`Success`
					);
					} else {
						$this.addClass("btn-danger");
					$this.html(
						`Error!`
					);
					}
					window.location.reload()
				}
			})
		}


	});
	

	$(document).on('click', '#ced_ebay_create_logs_zip', function(e){
		e.preventDefault();
		jQuery('#wpbody-content').append(ebay_loader_overlay);
		jQuery('#ced_ebay_progress_text').html('Please wait while we are creating a zip of the log files...');
		jQuery.ajax({
			type:'post',
			url: ajaxUrl,
			data: {
				userid: user_id,
				ajax_nonce: ajaxNonce,
				action: 'ced_ebay_create_logs_zip_action'
			},
			success: function(response){
				jQuery('#wpbody-content .ced_ebay_overlay').remove();
				if(response.success == true){
					Swal.fire({
						title:'Compress logs',
						text: response.data.message,
						icon: 'success',
				  });
				} else if(response.success == false){
					Swal.fire({
						title:'Compress logs',
						text: response.data.message,
						icon: 'error',
				  });
				}
			}
		})
		
	});


	$( document ).on( 'click', '.ced_ebay_add_custom_item_aspects', function(e){

		e.preventDefault();
		e.stopPropagation();

		let title = $( '.ced_ebay_add_custom_item_aspect_title' ).val();
		let existing_custom_item_aspects_json;
		// title = title.replace( " ", "+e");
		let existing_custom_item_aspects_string = $( '.ced_ebay_add_custom_item_aspect_heading' ).attr( 'data-attr' );
		existing_custom_item_aspects_string     = existing_custom_item_aspects_string.replaceAll( "+", " " );
		if ( existing_custom_item_aspects_string !== '' ) {
			
			existing_custom_item_aspects_json = JSON.parse( existing_custom_item_aspects_string );

			if ( existing_custom_item_aspects_json.hasOwnProperty( title ) ) {
				let html = '<tr class="ced_ebay_add_custom_item_aspect_error" ><td colspan="3">Please enter another custom title. Same custom title has already been used.</td></tr>'
				$( '.ced_ebay_add_custom_item_aspect_row' ).before( html );

				setTimeout(() => {
					$( '.ced_ebay_add_custom_item_aspect_error' ).remove();
				},3000 )
				return;
			}

		}
		
		if ( title.length <= 0  ) {
			let html = '<tr class="ced_ebay_add_custom_item_aspect_error" ><td colspan="3">Please enter custom item aspects title.</td></tr>'
			$( '.ced_ebay_add_custom_item_aspect_row' ).before( html );

			setTimeout( () => {
				$( '.ced_ebay_add_custom_item_aspect_error' ).remove();
			},3000)

		} else {

			if ( existing_custom_item_aspects_string == '' ) {
				existing_custom_item_aspects_json        = {};
				existing_custom_item_aspects_json[title] = title;
			} else {
				existing_custom_item_aspects_json        = JSON.parse( existing_custom_item_aspects_string );
				existing_custom_item_aspects_json[title] = title;
			}

			$( '.ced_ebay_add_custom_item_aspect_heading' ).attr( 'data-attr' , JSON.stringify( existing_custom_item_aspects_json ) )

			jQuery( '#wpbody-content' ).append( ebay_loader_overlay );

			jQuery.ajax(
				{
					type:'post',
					url: ajaxUrl,
					dataType: 'html',
					data: {
						user_id: user_id,
						ajax_nonce: ajaxNonce,
						title: title,
						action: 'ced_ebay_add_custom_item_aspects_row'
					},
					success: function(response){

						jQuery( '#wpbody-content .ced_ebay_overlay' ).remove();
						$( '.ced_ebay_add_custom_item_aspect_heading' ).after( response );
						$( '.ced_ebay_add_custom_item_aspect_title' ).val( '' );
						$( '.ced_ebay_item_specifics_options' ).selectWoo({width: '90%'});
						$( '.ced_ebay_search_item_sepcifics_mapping' ).selectWoo({width: '90%'});
						

					}
				}
			)
			
		}

	}
)


$(function() {
	$(document).on('keyup','.ced_ebay_type_custom_value', function(e){
		if( $(this).val().length == 0 ){
			let name = $(this).attr('name');
			if($(this).val()=='')showOptions(name)

		}

	});
});	
	
$(".ced_ebay_type_custom_value").change(function(){
	if( $(this).val().length == 0 ){
		let name = $(this).attr('name');
		if($(this).val()=='')showOptions(name)
	}
});

$(document).on('change','.ced_ebay_fill_custom_value', function(e){

	let name = $(this).attr('name');
	if($(this).val()=='customOption')
		showCustomInput(name)

})

$(document).on('blur','.ced_ebay_type_custom_value', function(e){

	let name = $(this).attr('name');
	console.log(name)
	if($(this).val()=='')showOptions(name)

})

function toggle( toBeHidden, toBeShown) {
	toBeHidden.hide().prop('disabled', true);
	toBeShown.show().prop('disabled', false).focus();
}
	
function showOptions(inputName) {
	let select = $(`select[name="${inputName}"]`);
	toggle($(`input[name="${inputName}"]`), select);
	select.val(null);
}


function showCustomInput(inputName) {
	toggle( $(`select[name="${inputName}"]`), $(`input[name="${inputName}"]`));
}
	

})( jQuery );
