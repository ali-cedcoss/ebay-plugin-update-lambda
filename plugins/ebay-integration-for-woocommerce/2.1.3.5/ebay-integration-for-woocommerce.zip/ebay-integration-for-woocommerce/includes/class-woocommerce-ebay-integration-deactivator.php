<?php

/**
 * Fired during plugin deactivation
 *
 * @link       https://cedcommerce.com
 * @since      1.0.0
 *
 * @package    EBay_Integration_For_Woocommerce
 * @subpackage EBay_Integration_For_Woocommerce/includes
 */

/**
 * Fired during plugin deactivation.
 *
 * This class defines all code necessary to run during the plugin's deactivation.
 *
 * @since      1.0.0
 * @package    EBay_Integration_For_Woocommerce
 * @subpackage EBay_Integration_For_Woocommerce/includes
 */
class EBay_Integration_For_Woocommerce_Deactivator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function deactivate() {

		if ( ! empty( get_option( 'ced_ebay_user_access_token' ) ) ) {
			$ebay_data = get_option( 'ced_ebay_user_access_token', true );
			foreach ( $ebay_data as $key => $value ) {
				$user_id = $key;
				if ( ! empty( $user_id ) ) {
					if ( wp_next_scheduled( 'ced_ebay_existing_products_sync_job_' . $user_id ) ) {
						wp_clear_scheduled_hook( 'ced_ebay_existing_products_sync_job_' . $user_id );
					}
					if ( wp_next_scheduled( 'ced_ebay_import_products_job_' . $user_id ) ) {
						wp_clear_scheduled_hook( 'ced_ebay_import_products_job_' . $user_id );
					}
					if ( function_exists( 'as_has_scheduled_action' ) && function_exists( 'as_unschedule_all_actions' ) ) {
						if ( as_has_scheduled_action( 'ced_ebay_refresh_access_token_schedule' ) ) {
							as_unschedule_all_actions( 'ced_ebay_refresh_access_token_schedule' );
						}
						if ( as_has_scheduled_action( 'ced_ebay_inventory_scheduler_job_' . $user_id ) ) {
							as_unschedule_all_actions( 'ced_ebay_inventory_scheduler_job_' . $user_id );
							$renderDataOnGlobalSettings = get_option( 'ced_ebay_global_settings', false );
							if ( ! empty( $renderDataOnGlobalSettings ) && is_array( $renderDataOnGlobalSettings ) ) {
								if ( ! empty( $renderDataOnGlobalSettings ) && is_array( $renderDataOnGlobalSettings ) ) {
									$global_settings      = array();
									$temp_global_settings = array();
									foreach ( $renderDataOnGlobalSettings as $key => $global_setting ) {
										if ( $user_id == $key ) {
											$temp_global_settings                                     = $global_setting;
											$temp_global_settings['ced_ebay_inventory_schedule_info'] = '0';
											$global_settings[ $user_id ]                              = $temp_global_settings;
											continue;
										}
										$global_settings[ $key ] = $global_setting;
									}
									update_option( 'ced_ebay_global_settings', $global_settings );
								}
							}
						}
						if ( as_has_scheduled_action( 'ced_ebay_order_scheduler_job_' . $user_id ) ) {
							as_unschedule_all_actions( 'ced_ebay_order_scheduler_job_' . $user_id );
							$renderDataOnGlobalSettings = get_option( 'ced_ebay_global_settings', false );
							if ( ! empty( $renderDataOnGlobalSettings ) && is_array( $renderDataOnGlobalSettings ) ) {
								if ( ! empty( $renderDataOnGlobalSettings ) && is_array( $renderDataOnGlobalSettings ) ) {
									$global_settings      = array();
									$temp_global_settings = array();
									foreach ( $renderDataOnGlobalSettings as $key => $global_setting ) {
										if ( $user_id == $key ) {
											$temp_global_settings                                 = $global_setting;
											$temp_global_settings['ced_ebay_order_schedule_info'] = '0';
											$global_settings[ $user_id ]                          = $temp_global_settings;
											continue;
										}
										$global_settings[ $key ] = $global_setting;
									}
									update_option( 'ced_ebay_global_settings', $global_settings );
								}
							}
						}
						$recurring_bulk_upload = false;
						$has_action            = array();
						if ( as_has_scheduled_action( 'ced_ebay_recurring_bulk_upload_' . $user_id ) ) {
							$recurring_bulk_upload = true;
							as_unschedule_all_actions( 'ced_ebay_recurring_bulk_upload_' . $user_id );
						}

						if ( function_exists( 'as_get_scheduled_actions' ) ) {
							$has_action = as_get_scheduled_actions(
								array(
									'group'  => 'ced_ebay_bulk_upload_' . $user_id,
									'status' => ActionScheduler_Store::STATUS_PENDING,
								),
								'ARRAY_A'
							);

							if ( ( ! empty( $has_action ) && is_array( $has_action ) ) || $recurring_bulk_upload ) {
								$unschedule_actions = as_unschedule_all_actions( null, null, 'ced_ebay_bulk_upload_' . $user_id );
							}
						}
					}

					if ( class_exists( 'WC_Webhook' ) ) {
						$get_webhook_id = ! empty( get_option( 'ced_ebay_prduct_update_webhook_id_' . $user_id, true ) ) ? get_option( 'ced_ebay_prduct_update_webhook_id_' . $user_id, true ) : false;
						if ( $get_webhook_id ) {
							$webhook        = new WC_Webhook( $get_webhook_id );
							$webhook_status = $webhook->get_status();
							if ( 'active' == $webhook_status ) {
								$webhook->set_status( 'paused' );
								$webhook->save();
							}
						}
					}

					// Remove the seller data fetched using GetUser request upon deactivation
					$wp_folder     = wp_upload_dir();
					$wp_upload_dir = $wp_folder['basedir'];
					$wp_upload_dir = $wp_upload_dir . '/ced-ebay/logs/';
					$log_file      = $wp_upload_dir . 'user.txt';
					if ( file_exists( $log_file ) ) {
						wp_delete_file( $log_file );
					}
				}
			}
		}

	}
}


