<?php

/**
 * Fired during plugin activation
 *
 * @link       https://cedcommerce.com
 * @since      1.0.0
 *
 * @package    EBay_Integration_For_Woocommerce
 * @subpackage EBay_Integration_For_Woocommerce/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    EBay_Integration_For_Woocommerce
 * @subpackage EBay_Integration_For_Woocommerce/includes
 */
class EBay_Integration_For_Woocommerce_Activator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function activate() {
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		$tableName = $wpdb->prefix . 'ced_ebay_profiles';

		$create_profile_table =
			"CREATE TABLE $tableName (
			id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
			profile_name VARCHAR(255) NOT NULL,
			profile_status VARCHAR(255) NOT NULL,
			user_id VARCHAR(255) DEFAULT NULL,
			profile_data TEXT DEFAULT NULL,
			woo_categories TEXT DEFAULT NULL,
			PRIMARY KEY (id)
		);";
		dbDelta( $create_profile_table );

		$tableName = $wpdb->prefix . 'ced_ebay_shipping';

		$create_shipping_table =
			"CREATE TABLE $tableName (
			id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
			shipping_name VARCHAR(255) NOT NULL,
			weight_range VARCHAR(255) NOT NULL,
			user_id VARCHAR(255) DEFAULT NULL,
			shipping_data TEXT DEFAULT NULL,
			PRIMARY KEY (id)
		);";
		dbDelta( $create_shipping_table );

		$tableName = $wpdb->prefix . 'ced_ebay_bulk_upload';

		$create_bulk_upload_table =
				"CREATE TABLE $tableName (
        id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
		profile_id INT NOT NULL,
        product_id INT NOT NULL,
		bulk_action_type  VARCHAR(255) NOT NULL,
        operation_status  VARCHAR(255) NOT NULL,
        error  LONGTEXT,
        user_id VARCHAR(255) NOT NULL,
		scheduled_time VARCHAR(255) NOT NULL,
        PRIMARY KEY (id)
        );";

		dbDelta( $create_bulk_upload_table );

	}

}
