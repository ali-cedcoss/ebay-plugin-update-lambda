<?php

/**
 * The plugin bootstrap file
 *
 * This file is read by WordPress to generate the plugin information in the plugin
 * admin area. This file also includes all of the dependencies used by the plugin,
 * registers the activation and deactivation functions, and defines a function
 * that starts the plugin.
 *
 * @link              https://cedcommerce.com
 * @since             1.0.0
 * @package           EBay_Integration_For_Woocommerce
 *
 * @wordpress-plugin
 * Plugin Name:       eBay Integration for Woocommerce
 * Plugin URI:        https://cedcommerce.com
 * Description:       The eBay Integration for WooCommerce allows merchants to list their products on the eBay marketplace and manage the orders & stock levels between their eBay & WooCommerce stores.
 * Version:           2.1.3.5
 * Author:            CedCommerce
 * Author URI:        https://cedcommerce.com
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       ebay-integration-for-woocommerce
 * Domain Path:       /languages
 *
 * Woo: 6911957:a54c731085ba6d10500fe6187b86a38b
 * WC requires at least: 3.0
 * WC tested up to: 7.5.1

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * Currently plugin version.
 * Start at version 1.0.0 and use SemVer - https://semver.org
 * Rename this for your plugin and update it as you release new versions.
 */
if ( is_admin() ) {
	if ( ! function_exists( 'get_plugin_data' ) ) {
		require_once ABSPATH . 'wp-admin/includes/plugin.php';
	}
	$plugin_data = get_plugin_data( __FILE__ );

	if ( is_array( $plugin_data ) && ! empty( $plugin_data['Version'] ) ) {
		$plugin_version = $plugin_data['Version'];
		define( 'EBAY_INTEGRATION_FOR_WOOCOMMERCE_VERSION', $plugin_version );
	}
}
if ( ! function_exists( 'is_plugin_active' ) ) {
	require_once ABSPATH . '/wp-admin/includes/plugin.php';
}

/* DEFINE CONSTANTS */
define( 'CED_EBAY_VERSION', '2.0.1' );
define( 'CED_EBAY_PREFIX', 'ced_ebay' );
define( 'CED_EBAY_DIRPATH', plugin_dir_path( __FILE__ ) );
define( 'CED_EBAY_URL', plugin_dir_url( __FILE__ ) );
define( 'CED_EBAY_ABSPATH', untrailingslashit( plugin_dir_path( dirname( __FILE__ ) ) ) );
define( 'CED_EBAY_PLUGIN_BASENAME', plugin_basename( __FILE__ ) );

// if ( ! is_plugin_active( 'woocommerce/woocommerce.php' ) ) {
// function require_woocommerce_plugin_during_activation(){

// wp_die( __( 'eBay Integration for WooCommerce requires WooCommerce plugin to be installed and activated.', 'ebay-integration-for-woocommerce' ) );

// @trigger_error( esc_html_e( 'This plugin requires WooCommerce plugin to be installed and activated.', 'cln' ), E_USER_ERROR );
// }

// add_action( 'admin_notices', 'require_woocommerce_plugin_during_activation' );
// register_activation_hook( __FILE__, 'require_woocommerce_plugin_during_activation' );
// }


function ced_ebay_check_woocommerce_active() {
	if ( in_array( 'woocommerce/woocommerce.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ) {
		return true;
	}
	return false;
}

if ( ced_ebay_check_woocommerce_active() ) {
	run_EBay_Integration_For_Woocommerce();
	register_activation_hook( __FILE__, 'activate_EBay_Integration_For_Woocommerce' );
	add_action( 'admin_notices', 'ced_ebay_admin_notice_activation' );
} else {
	add_action( 'admin_init', 'deactivate_ced_ebay_woo' );
}

function deactivate_ced_ebay_woo() {
	deactivate_plugins( CED_EBAY_PLUGIN_BASENAME );
	add_action( 'admin_notices', 'ced_ebay_woo_missing_notice' );
	if ( isset( $_GET['activate'] ) ) {
		unset( $_GET['activate'] );
	}
}

function ced_ebay_woo_missing_notice() {
	// translators: %s: search term !!
	echo '<div class="notice notice-error is-dismissible"><p>' . sprintf( esc_html( __( 'eBay Integration for Woocommerce requires WooCommerce to be installed and active. You can download %s from here.', 'shopify-connector-for-woocommerce' ) ), '<a href="https://wordpress.org/plugins/woocommerce/" target="_blank">WooCommerce</a>' ) . '</p></div>';
}


/**
 * The code that runs during plugin activation.
 * This action is documented in includes/class-woocommerce-ebay-integration-activator.php
 */
function activate_EBay_Integration_For_Woocommerce() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-woocommerce-ebay-integration-activator.php';
	EBay_Integration_For_Woocommerce_Activator::activate();
}


/**
 * The code that runs during plugin deactivation.
 * This action is documented in includes/class-woocommerce-ebay-integration-deactivator.php
 */
function deactivate_EBay_Integration_For_Woocommerce() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-woocommerce-ebay-integration-deactivator.php';
	EBay_Integration_For_Woocommerce_Deactivator::deactivate();
}

register_deactivation_hook( __FILE__, 'deactivate_EBay_Integration_For_Woocommerce' );




/**
* This file includes core functions to be used globally in plugin.
 *
* @link  http://www.cedcommerce.com/
*/
require_once plugin_dir_path( __FILE__ ) . 'includes/ced-ebay-core-functions.php';

/**
 * Begins execution of the plugin.
 *
 * Since everything within the plugin is registered via hooks,
 * then kicking off the plugin from this point in the file does
 * not affect the page life cycle.
 *
 * @since    1.0.0
 */
function run_EBay_Integration_For_Woocommerce() {
	/**
	 * The core plugin class that is used to define internationalization,
	 * admin-specific hooks, and public-facing site hooks.
	 */
	require plugin_dir_path( __FILE__ ) . 'includes/class-woocommerce-ebay-integration.php';
	$plugin = new EBay_Integration_For_Woocommerce();
	$plugin->run();

}


/* Register activation hook. */
register_activation_hook( __FILE__, 'ced_admin_notice_example_activation_hook_ced_ebay' );

/**
 * Runs only when the plugin is activated.
 *
 * @since 1.0.0
 */
function ced_admin_notice_example_activation_hook_ced_ebay() {

	/* Create transient data */
	set_transient( 'ced-ebay-admin-notice', true, 5 );
}

/*Admin admin notice */


/**
 * Admin Notice on Activation.
 *
 * @since 0.1.0
 */


function ced_ebay_admin_notice_activation() {

	/* Check transient, if available display notice */
	if ( get_transient( 'ced-ebay-admin-notice' ) ) {
		?>
		<div class="updated notice is-dismissible">
		  <p>Welcome to eBay Integration for Woocommerce. Start listing, syncing, managing, & automating your WooCommerce and eBay Stores to boost sales.</p>
		  <a href="admin.php?page=ced_ebay" class ="ced_configuration_plugin_main">Connect to eBay</a>
		</div>
		<?php
		/* Delete transient, only display this notice once. */
		delete_transient( 'ced-ebay-admin-notice' );
	}
}
